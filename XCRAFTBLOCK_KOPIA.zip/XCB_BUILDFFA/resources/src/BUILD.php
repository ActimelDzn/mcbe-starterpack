<?php

declare(strict_types=1);

namespace BUILD;

use BUILD\API\ScoreAPI;
use BUILD\Blocks\BreakBlock;
use BUILD\Blocks\GiveBlock;
use BUILD\Blocks\Sandstone1Task;
use BUILD\Blocks\SandstoneTask;
use BUILD\Blocks\SB;
use BUILD\Entity\BuildEntity;
use BUILD\Entity\Bob;
use BUILD\Entity\EntityManager;
use BUILD\Form\FormUI;
use BUILD\Task\EntityTask;
use BUILD\Task\ScoreTask;
use BUILD\Task\RespawnTask;
use pocketmine\entity\Entity;
use pocketmine\network\mcpe\protocol\{LevelSoundEventPacket, InventoryTransactionPacket};
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\inventory\Inventory;
use pocketmine\inventory\PlayerInventory;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;
use pocketmine\item\ItemFactory;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\scheduler\Task;
use pocketmine\scheduler\PluginTask;
use pocketmine\math\Vector3;
use pocketmine\math\Vector2;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\Utils;
use pocketmine\utils\Config;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use onebone\economyapi\EconomyAPI;
use pocketmine\block\Sandstone;
use pocketmine\entity\Effect;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\item\ItemBlock;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\utils\TextFormat as Color;

class BUILD extends PluginBase implements Listener {
	
	private static $instance = null;
	private static $scoreboard = null;
	
	public function onEnable() : void {
	  $this->getServer()->getPluginManager()->registerEvents($this, $this);
	  $this->getLogger()->info("Enabled");
	  $this->getScheduler()->scheduleRepeatingTask(new ScoreTask($this), 10);
	  $this->getScheduler()->scheduleRepeatingTask(new EntityTask($this), 10);
	  $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
	  if(!$config->get("level")) {
	  $this->getLogger()->info("[ERROR] No Hay Mapa de BuildFFa");
	  }else{
  	$this->getServer()->loadLevel($config->get("level"));
	  }
	  $this->saveResource("config.yml");
	  $this->saveResource("kills.yml");
	  $this->loadEntitys();
	}
	
	public function onLoad() {
	  BUILD::$instance = $this;
	  BUILD::$scoreboard = new ScoreAPI($this);
	}
	
	public static function getScoreboard() : ScoreAPI {
	  return BUILD::$scoreboard;
	}
	
	public static function getInstance() : BUILD {
	  return self::$instance;
	}
	
	public function loadEntitys() : void {
	  $values = [BuildEntity::class, Bob::class];
	  foreach ($values as $entitys){
	    Entity::registerEntity($entitys, true);
	    }
	    unset($values);
	}
	
	public function getPlayerMoney(Player $player){
	  /** @var EconomyAPI $economyAPI */
	  $economyAPI = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
	  if($economyAPI instanceof EconomyAPI){
	    return $economyAPI->myMoney($player);
	  }else{
	    return "0";
	  }
	}
	
	public static function getConfigs(string $value) {
	  return new Config(self::getInstance()->getDataFolder() . "{$value}.yml", Config::YAML);
	}
	
	public function onDamageEntity(EntityDamageByEntityEvent $event){
	  if($event->getEntity() instanceof BuildEntity){
	    $player = $event->getDamager();
	    if($player instanceof Player){
	      $event->setCancelled(true);
	      $this->getGame($player);
	    }
	  }
	  if($event->getEntity() instanceof Bob){
	    $player = $event->getDamager();
	    if($player instanceof Player){
	      $event->setCancelled(true);
	      $this->getKit($player);
	    }
	  }
	}
	
	public function onDeath(PlayerDeathEvent $e){
	  $e->setDeathMessage("");
	  $e->setDrops([]);
	}
	
	public function onDamage(EntityDamageEvent $event){
	    $player = $event->getEntity();
	    $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
       $kills = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
	    
	if ($config->get('level') != null) {
	    if($player instanceof Player and $player->getHealth() - $event->getBaseDamage() <= 0) {
            if ($player->getLevel() === Server::getInstance()->getLevelByName($config->get('level'))) {
                $causa = $event->getEntity()->getLastDamageCause();
                if ($causa instanceof EntityDamageByEntityEvent) {
                    $damager = $causa->getDamager();
                    $damager->setHealth(20);
                    $damager->getLevel()->broadcastLevelSoundEvent($damager, LevelSoundEventPacket::SOUND_BLOCK_TURTLE_EGG_HATCH);
                	EconomyAPI::getInstance()->addMoney($damager, 1);
                  $damager->sendTip("§2ZABOJSTWO | +10$");
                  $matador = $damager->getName();
                    $kills = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
                        $kills->set($damager->getName(), $kills->get($damager->getName()) + 1);
                        $kills->save();
                        foreach ($damager->getLevel()->getPlayers() as $players) {
                        	$m = $damager->getName();
                            $player = $event->getEntity();
                            $p = $player->getName();
                           
                            }
                            }
	        $player->addTitle("§c§lZGINALES");
	        $player->setHealth(20);
	        $player->setFood(20);
	        $player->getInventory()->clearAll();
	        $player->getArmorInventory()->clearAll();
	        $player->getCursorInventory()->clearAll();
	        $player->removeAllEffects();
	        $player->setGamemode(3);
	        $this->getScheduler()->scheduleRepeatingTask(new RespawnTask($this, $player->getName()), 20);
	    }
	}
	}
	}
	
	public function onChange(EntityLevelChangeEvent $event){
		$player = $event->getEntity();
		$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
		if ($config->get('level') != null) {
            if ($player->getLevel() === Server::getInstance()->getLevelByName($config->get('level'))) {
                if ($player instanceof Player) {
                    $api = BUILD::getScoreboard();
   	              	$api->remove($player);
                    $player->removeAllEffects();
                    $player->setGamemode(2);
                    $player->setHealth(20);
                    $player->setFood(20);
                    $player->removeAllEffects();
                    $player->getInventory()->clearAll();
                    $player->getArmorInventory()->clearAll();
		}
		}
		}
		}
		
		public function onDrop(PlayerDropItemEvent $event) {
        $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
        $player = $event->getPlayer();
        if ($config->get('level') != null) {
            if ($player->getLevel() === Server::getInstance()->getLevelByName($config->get('level'))) {
                $event->setCancelled(true);
                $player->sendMessage("§cERROR§7»!");
            }
        }
    }
    
    public function onBlockPlace(BlockPlaceEvent $event){
		$config = new Config($this->getDataFolder() . "config.yml", Config::YAML);
		if ($event->getPlayer()->getLevel()->getName() == $config->get("level")) {
			$block = $event->getBlock();
			$player = $event->getPlayer();
			$id = $event->getBlock()->getId();
			if($config->get("level") != null){
			if( $player->getLevel() === Server::getInstance()->getLevelByName($config->get("level"))){
			if ($id === 179) {
				$this->getScheduler()->scheduleDelayedTask(new SandstoneTask($this, $block, $player), 100);
				$this->getScheduler()->scheduleDelayedTask(new GiveBlock($this, $player), 100);
				$this->getScheduler()->scheduleDelayedTask(new Sandstone1Task($this, $block), 50);
				$event->setCancelled(false);
			} elseif ($id === 30) {
				$this->getScheduler()->scheduleDelayedTask(new SB($this, $block), 120);
				$event->setCancelled(false);
			} else {
				$event->setCancelled(true);
			}
		}
			}
		}
    }
    
	public function onBlockBreak(BlockBreakEvent $event){
			$block = $event->getBlock()->getDamage();
			$player = $event->getPlayer();
			$id = $event->getBlock()->getId();
			$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
			
			if($config->get("level") != null){
			if( $player->getLevel() === Server::getInstance()->getLevelByName($config->get("level"))){
			 $event->setCancelled(true);
			if ($id === 179) {
			  $player->sendMessage("BLAD");
				$event->setCancelled(false);
			} else {
			  $player->sendMessage("§cERROR§7");
				$event->setCancelled(true);
			}
	}
			}
	}
    
    use FormUI;
    public function getGame(Player $player){
      $form = $this->createSimpleFor(function(Player $player, ?int $data){
        if( !is_null($data)){
          switch($data){
          case 0:
          $player->setFood(20);
  	 			$player->setHealth(20);
  				$player->getInventory()->clearAll();
   				$player->removeAllEffects();
  				$player->getInventory()->clearAll();
          $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
          $w = $config->get("level");
          $x = $config->get("x");
          $y = $config->get("y");
          $z = $config->get("z");
          if($config->get("level")){
          $player->setGamemode(0);
		      $player->setAllowFlight(false);
		      $player->setFlying(false);
          $player->teleport(new Position($x, $y, $z, $this->getServer()->getLevelByName($w)));
          $player->getInventory()->setItem(4, Item::get(322, 0, 20));
          $player->getInventory()->setItem(2, Item::get(179, 0, 64));
          $player->getInventory()->setItem(3, Item::get(179, 0, 64));
          $player->getInventory()->setItem(5, Item::get(Item::STEAK, 0, 64));
          $player->getInventory()->setItem(6, Item::get(Item::ARROW, 0, 64));
          $player->getInventory()->setItem(7, Item::get(Item::ARROW, 0, 64));
          $player->getInventory()->setItem(8, Item::get(Item::ARROW, 0, 64));
          $armor = $player->getArmorInventory();
          $item = $player->getInventory();
          $proteccion = Enchantment::getEnchantment(Enchantment::PROTECTION, 2);
          $filo = Enchantment::getEnchantment(Enchantment::SHARPNESS);
          $irrompibilidad = Enchantment::getEnchantment(Enchantment::UNBREAKING, 2);
          $poder = Enchantment::getEnchantment(Enchantment::POWER, 2);
          $casco = Item::get(Item::DIAMOND_HELMET, 0, 1);
          $casco->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $casco->addEnchantment(new EnchantmentInstance($proteccion));
          $pechera = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
          $pechera->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $pechera->addEnchantment(new EnchantmentInstance($proteccion));
          $pantalon = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
          $pantalon->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $pantalon->addEnchantment(new EnchantmentInstance($proteccion));
          $botas = Item::get(Item::DIAMOND_BOOTS, 0, 1);
          $botas->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $botas->addEnchantment(new EnchantmentInstance($proteccion));
          $espada = Item::get(Item::DIAMOND_SWORD, 0, 1);
          $espada->addEnchantment(new EnchantmentInstance($filo));
          $espada->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $arco = Item::get(Item::BOW, 0, 1);
          $arco->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $arco->addEnchantment(new EnchantmentInstance($poder));
          $armor->setHelmet($casco);
          $armor->setChestplate($pechera);
          $armor->setLeggings($pantalon);
          $armor->setBoots($botas);
          $item->setItem(0, $espada);
          $item->setItem(1, $arco);
          }
          break;
          }
        }
      });
     $form->setTitle("§l§7» §r§l§6KNOCK§eF§6F§eA §l§7«");
     $form->addButton("§l§gDOLACZ",0,"textures/blocks/red_sandstone_bottom");
     $form->sendToPlayer($player);
    }
    
    public function getKit(Player $player){
      $form = $this->createSimpleFor(function(Player $player, ?int $data){
        if( !is_null($data)){
          switch($data){
          case 0:
          $this->buyKits($player);
          break;
          case 1:
          $this->myKits($player);
          break;
          }
        }
      });
      $form->setTitle("§l§7» §r§6KITY §l§7«");
      $form->addButton("SOON",0,"textures/ui/icon_minecoin_9x9");
      $form->addButton("SOON",0,"textures/ui/icon_blackfriday");
      $form->sendToPlayer($player);
    }
	
	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args) : bool {
		switch($cmd->getName()){
			case "knock":
			if(empty($args[0])) {
		    $player->sendMessage("§cERROR§7» §6Uzyj: /knock pomoc");
			} else {
			if($args[0]=="pomoc") { 
			$b1 = "§6KNOCK§7§l»§r";
			$b2 = "§eKNOCK§7§l»§r";
			$player->sendMessage($b1 . "§7=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
			$player->sendMessage($b2 . "§3/knock pomoc");
			$player->sendMessage($b2 . "§3/knock create");
			$player->sendMessage($b1 . "§3/knock spawn");
			$player->sendMessage($b2 . "§3/knock npc");
			$player->sendMessage($b2 . "§3/knok join");
			$player->sendMessage($b1 . "§7=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
			} else if($args[0]=="author") {
			$player->sendMessage("§g§l     KNOCK§eF§6F§eA     ");
			$player->sendMessage("§cVersja: §f1.0.0");
			$player->sendMessage("§cStatus: §fPrivate");
			$player->sendMessage("§cAuthor: §fActimel");
			} else if($args[0]=="create") {
			if($player->isOp()) {
			$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
			$config->set("level", $player->getLevel()->getFolderName());
			$config->save();
			$player->sendMessage("§gKNOCK§7» §bKomena wykonana pomyślnie!");
			}else{
			$player->sendMessage("§gKNOCK§7» §6Brak permisji");
			}
			} else if($args[0]=="spawn") {
			if($player->isOp()) {
			$config = new Config($this->getDataFolder() . "config.yml", Config::YAML);
			$config->set("x",$player->getX());
			$config->set("y",$player->getY());
			$config->set("z",$player->getZ());
			$config->save();
			$player->sendMessage("§gKNOCK§7» §bKomena wykonana pomyślnie!");
			}else{
			$player->sendMessage("§gKNOCK§7» §6Brak permisji");
			}
			} else if($args[0]=="npc") {
			if($player->isOp()) {
			$entity = new EntityManager();
			$entity->setGame($player);
			$player->sendMessage("§gKNOCK§7» §bKomena wykonana pomyślnie!");
			}else{
			$player->sendMessage("§cERROR§7» ");
			}
			} else if($args[0]=="kit") {
			$this->getKit($player);
			} else if($args[0]=="join") {
			          $player->setFood(20);
  	 			$player->setHealth(20);
  				$player->getInventory()->clearAll();
   				$player->removeAllEffects();
  				$player->getInventory()->clearAll();
          $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
          $w = $config->get("level");
          $x = $config->get("x");
          $y = $config->get("y");
          $z = $config->get("z");
          if($config->get("level")){
          $player->setGamemode(0);
		      $player->setAllowFlight(false);
		      $player->setFlying(false);
          $player->teleport(new Position($x, $y, $z, $this->getServer()->getLevelByName($w)));
          $player->sendMessage("§eAVISE§7» §bPuedes Adquirir Mas Kits con BOB");
          $player->getInventory()->setItem(4, Item::get(322, 0, 20));
          $player->getInventory()->setItem(2, Item::get(179, 0, 64));
          $player->getInventory()->setItem(3, Item::get(179, 0, 64));
          $player->getInventory()->setItem(5, Item::get(Item::STEAK, 0, 64));
          $player->getInventory()->setItem(6, Item::get(Item::ARROW, 0, 64));
          $player->getInventory()->setItem(7, Item::get(Item::ARROW, 0, 64));
          $player->getInventory()->setItem(8, Item::get(Item::ARROW, 0, 64));
          $armor = $player->getArmorInventory();
          $item = $player->getInventory();
          $proteccion = Enchantment::getEnchantment(Enchantment::PROTECTION, 2);
          $filo = Enchantment::getEnchantment(Enchantment::SHARPNESS);
          $irrompibilidad = Enchantment::getEnchantment(Enchantment::UNBREAKING, 2);
          $poder = Enchantment::getEnchantment(Enchantment::POWER, 2);
          $casco = Item::get(Item::DIAMOND_HELMET, 0, 1);
          $casco->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $casco->addEnchantment(new EnchantmentInstance($proteccion));
          $pechera = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
          $pechera->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $pechera->addEnchantment(new EnchantmentInstance($proteccion));
          $pantalon = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
          $pantalon->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $pantalon->addEnchantment(new EnchantmentInstance($proteccion));
          $botas = Item::get(Item::DIAMOND_BOOTS, 0, 1);
          $botas->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $botas->addEnchantment(new EnchantmentInstance($proteccion));
          $espada = Item::get(Item::DIAMOND_SWORD, 0, 1);
          $espada->addEnchantment(new EnchantmentInstance($filo));
          $espada->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $arco = Item::get(Item::BOW, 0, 1);
          $arco->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $arco->addEnchantment(new EnchantmentInstance($poder));
          $armor->setHelmet($casco);
          $armor->setChestplate($pechera);
          $armor->setLeggings($pantalon);
          $armor->setBoots($botas);
          $item->setItem(0, $espada);
          $item->setItem(1, $arco);
          }
			} else if($args[0]=="remove") {
			if($player->isOp()) {
			foreach ($player->getLevel()->getEntities() as $entity) {
      if ($entity instanceof BuildEntity) {
      $entity->kill();
			$player->sendMessage("§aOKAY§7» §bEntidad Removida Correctamente");
			}
			}
			}else{
			$player->sendMessage("§cERROR§7» §6No Tienes Permisos");
			}
			} else if($args[0]=="bob") {
			if($player->isOp()) {
		  $entity = new EntityManager();
		  $entity->setBob($player);
		  $player->sendMessage("§aOKAY§7» §bBob Puesto Correctamente");
			}
			}else{
			$player->sendMessage("§cERROR§7» §6No Tienes Permisos");
			}
			break;
			}
		}
		return true;
	}
	
	public function onDisable() : void {
	  $this->getLogger()->info("Disabled");
	}
}