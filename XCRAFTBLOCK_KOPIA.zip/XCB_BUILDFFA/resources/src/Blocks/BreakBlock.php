<?php

namespace BUILD\Blocks;

class BreakBlock {

}