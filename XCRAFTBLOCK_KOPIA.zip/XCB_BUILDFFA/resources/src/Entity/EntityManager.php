<?php

namespace BUILD\Entity;

use BUILD\Entity\BuildEntity;
use BUILD\Entity\Bob;
use pocketmine\utils\Config;
use pocketmine\level\Position;
use pocketmine\{Server, Player, utils\TextFormat, level\Level, entity\Skin, entity\Entity, math\Vector3};

class EntityManager {
	
	public function setGame(Player $player) {
		$nbt = Entity::createBaseNBT(new Vector3((float)$player->getX(), (float)$player->getY(), (float)$player->getZ()));
		$nbt->setTag($player->namedtag->getCompoundTag('Skin'));
		$human = new BuildEntity($player->getLevel(), $nbt);
		$human->setNameTag('');
		$human->setNameTagVisible(true);
		$human->setNameTagAlwaysVisible(true);
		$human->yaw = $player->getYaw();
		$human->pitch = $player->getPitch();
		$human->spawnToAll();
	}
	
	public function setBob(Player $player) {
	  $nbt = Entity::createBaseNBT(new Vector3((float)$player->getX(), (float)$player->getY(), (float)$player->getZ()));
	  $nbt->setTag($player->namedtag->getCompoundTag('Skin'));
	  $human = new Bob($player->getLevel(), $nbt);
	  $human->setNameTag('');
	  $human->setNameTagVisible(true);
	  $human->setNameTagAlwaysVisible(true);
	  $human->yaw = $player->getYaw();
	  $human->pitch = $player->getPitch();
	  $human->spawnToAll();
	}
}