<?php

declare(strict_types=1);

namespace BUILD\Entity;

use pocketmine\entity\Human;

class Bob extends Human {
  
  public function getName(): string {
    return '';
  }
}