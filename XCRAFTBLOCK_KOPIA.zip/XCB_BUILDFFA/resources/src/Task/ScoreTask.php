<?php

namespace BUILD\Task;

use BUILD\BUILD;
use BUILD\API\ScoreAPI;
use pocketmine\{Server, Player, utils\TextFormat as Color, level\Level, scheduler\Task};

class ScoreTask extends Task {
	    /** @var Loader */
    protected $plugin;

    /**
     * Scoreboard Constructor
     * @param Loader $plugin
     */
    public function __construct(BUILD $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @param Int $currentTick
     */

    public function onRun(int $currentTick) {
    	$config = $this->plugin->getConfigs('config');
        $mapa = $config->get("level");
        $arena = $this->plugin->getServer()->getLevelByName($mapa);
        $kills = BUILD::getConfigs('kills');
            if ($arena !== null) {
                foreach($arena->getPlayers() as $player){
                    $api = BUILD::getScoreboard();
                    $players = count($arena->getPlayers());
                    $money = $this->plugin->getPlayerMoney($player);
                    $api->new($player, $player->getName(), '§lXCB §8>> §gKNOCK');
                    $api->setLine($player, 1, '§r');
                    $api->setLine($player, 2, '§7§l» §gNICK: §r§e'.$player->getName());
                    $api->setLine($player, 3, '§a');
                    $api->setLine($player, 4, '§7§l» §6gPING: §r§e'.$this->getPing($player));
                    $api->setLine($player, 5, '§7§l» §gZABOJSTWA: §r§e'.$kills->get($player->getName()));
                    $api->setLine($player, 6, '§7§l» §gSALDO: §r§e'.$money);
                    $api->setLine($player, 7, '§c');
                    $api->setLine($player, 8, '§7xcraftblock.pl');
                    $api->getObjectiveName($player);
                }
            }
        }
        
        public function getPing(Player $player) : string {
		$ping = $player->getPing();
		$pin = $ping <  150 ? "§aDOBRY" : "§cSLABY";
		return $pin;
		}
    }