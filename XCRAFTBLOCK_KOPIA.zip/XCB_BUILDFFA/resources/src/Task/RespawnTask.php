<?php

namespace BUILD\Task;

use BUILD\BUILD;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\level\Position;
use pocketmine\level\Level;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;
use pocketmine\item\ItemFactory;
use pocketmine\network\mcpe\protocol\{LevelSoundEventPacket, InventoryTransactionPacket};
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};

class RespawnTask extends Task {

	public $timer = 5;
	private $main;
	private $playerName;

	public function __construct(BUILD $main, $playerName){
		$this->main = $main;
		$this->playerName = $playerName;
	}

	public function onRun($tick) {
		  $player = $this->main->getServer()->getPlayerExact($this->playerName);
		  if($player instanceof Player){
		  	if($this->timer == 5){
			$player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_ITEM_FIZZ);
			$player->addTitle("§l§cRESPAWN ZA", "§r§f5");
			}
			if($this->timer == 4){
			$player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_ITEM_FIZZ);
			$player->addTitle("§l§cRESPAWN ZA", "§r§f4");
			}
			if($this->timer == 3){
			$player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_ITEM_FIZZ);
			$player->addTitle("§l§cRESPAWN ZA", "§r§f3");
			}
			if($this->timer == 2){
			$player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_ITEM_FIZZ);
			$player->addTitle("§l§cRESPAWN ZA", "§r§f2");
			}
			if($this->timer == 1){
			$player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_ITEM_FIZZ);
			$player->addTitle("§l§cRESPAWN ZA", "§r§f1");
			}
			if($this->timer == 0){
				$player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_BOTTLE_DRAGONBREATH);
			    $player->addTitle("§l§aZYJESZ", "XD");
			    $config = $this->main->getConfigs('config');
			    $w = $config->get("level");
	            $x = $config->get("x");
	            $y = $config->get("y");
	            $z = $config->get("z");
			    $player->teleport(new Position($x, $y, $z, Server::getInstance()->getLevelByName($w)));
			    $player->setGamemode(0);
			    $player->setHealth(20);
			    $player->setFood(20);
			    $player->setFood(20);
  	 			$player->setHealth(20);
  				$player->getInventory()->clearAll();
   				$player->removeAllEffects();
  				$player->getInventory()->clearAll();
          $config = $this->main->getConfigs('config');
          $w = $config->get("level");
          $x = $config->get("x");
          $y = $config->get("y");
          $z = $config->get("z");
          if($config->get("level")){
          $player->setGamemode(0);
		      $player->setAllowFlight(false);
		      $player->setFlying(false);
          $player->teleport(new Position($x, $y, $z, Server::getInstance()->getLevelByName($w)));
          $player->getInventory()->setItem(4, Item::get(322, 0, 20));
          $player->getInventory()->setItem(2, Item::get(179, 0, 64));
          $player->getInventory()->setItem(3, Item::get(179, 0, 64));
          $player->getInventory()->setItem(5, Item::get(Item::STEAK, 0, 64));
          $player->getInventory()->setItem(6, Item::get(Item::ARROW, 0, 64));
          $player->getInventory()->setItem(7, Item::get(Item::ARROW, 0, 64));
          $player->getInventory()->setItem(8, Item::get(Item::ARROW, 0, 64));
          $armor = $player->getArmorInventory();
          $item = $player->getInventory();
          $proteccion = Enchantment::getEnchantment(Enchantment::PROTECTION, 2);
          $filo = Enchantment::getEnchantment(Enchantment::SHARPNESS);
          $irrompibilidad = Enchantment::getEnchantment(Enchantment::UNBREAKING, 2);
          $poder = Enchantment::getEnchantment(Enchantment::POWER, 2);
          $casco = Item::get(Item::DIAMOND_HELMET, 0, 1);
          $casco->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $casco->addEnchantment(new EnchantmentInstance($proteccion));
          $pechera = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
          $pechera->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $pechera->addEnchantment(new EnchantmentInstance($proteccion));
          $pantalon = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
          $pantalon->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $pantalon->addEnchantment(new EnchantmentInstance($proteccion));
          $botas = Item::get(Item::DIAMOND_BOOTS, 0, 1);
          $botas->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $botas->addEnchantment(new EnchantmentInstance($proteccion));
          $espada = Item::get(Item::DIAMOND_SWORD, 0, 1);
          $espada->addEnchantment(new EnchantmentInstance($filo));
          $espada->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $arco = Item::get(Item::BOW, 0, 1);
          $arco->addEnchantment(new EnchantmentInstance($irrompibilidad));
          $arco->addEnchantment(new EnchantmentInstance($poder));
          $armor->setHelmet($casco);
          $armor->setChestplate($pechera);
          $armor->setLeggings($pantalon);
          $armor->setBoots($botas);
          $item->setItem(0, $espada);
          $item->setItem(1, $arco);
          }
			}
          $this->timer--;
      } else {
      	$this->main->getScheduler()->cancelTask($this->getTaskId());
    	}
	}
}