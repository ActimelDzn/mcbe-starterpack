<?php

declare(strict_types=1);

namespace BUILD\Task;

use BUILD\{BUILD, Entity\BuildEntity, Entity\Bob};
use pocketmine\{Server, Player, utils\TextFormat as Color, math\Vector2, entity\Effect, entity\EffectInstance, scheduler\Task};
use pocketmine\network\mcpe\protocol\{MovePlayerPacket};
use pocketmine\level\Level;

class EntityTask extends Task {
	
	protected $plugin;
	
	public function __construct(BUILD $plugin){
        $this->plugin = $plugin;
    }

	public function onRun(int $currentTick) {
	  $config = BUILD::getConfigs('config');
		foreach (Server::getInstance()->getDefaultLevel()->getEntities() as $entity) {
			if ($entity instanceof BuildEntity) {
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 999));
				$entity->setNameTag(self::setName());
				$entity->setNameTagAlwaysVisible(true);
				$entity->setScale(1.8);
				}
		}
	}
	
		public static function getPlayers() : int {
		$config = BUILD::getConfigs('config');
		if ($config->get('level') != null) {
			return count(Server::getInstance()->getLevelByName($config->get('level'))->getPlayers());
		} else {
			return 0;
		}
	}
	
	public static function setName() : string {
		$colors = [Color::AQUA . 'TAP TO JOIN', Color::YELLOW . 'TAP TO JOIN', Color::GOLD . 'TAP TO JOIN', Color::GREEN . 'TAP TO JOIN', Color::RED . 'TAP TO JOIN'];
		$random = [Color::AQUA . '[NEW_GAME]', Color::AQUA . '[§21.0.0]', Color::AQUA . ['§7BETA'];
		$title = Color::GRAY . Color::BOLD . ' ' . $colors[array_rand($colors)] . Color::GRAY . '' . "\n";
		$subtitle1 = Color::BOLD . '§gKNOCK ' . Color::RESET . $random[array_rand($random)] . "\n";
		$subtitle2 = Color::GOLD . 'W grze ' . Color::GREEN . self::getPlayers() . '';
		return $title . $subtitle1 . $subtitle2;
	}
	
	public static function setBobName() : string {
	  $random = [Color::GOLD . '[20% OFF]', Color::AQUA . '[KITS]', Color::GREEN . '[BUY]'];
	  $kit = [Color::AQUA . 'KITS SHOP', Color::GOLD . 'KITS SHOP', Color::GREEN . 'YOUR KITS', Color::RED . 'YOUR KITS'];
	  $title = Color::BOLD . Color::GRAY . '» ' . $kit[array_rand($kit)] . Color::GRAY . ' «' . "\n";
	  $subtitle1 = Color::BOLD . '§6KITS BUILD§eF§6F§eA ' . Color::RESET . $random[array_rand($random)] . "\n";
	  $subtitle2 = Color::YELLOW . 'SELECT A KIT';
	  return $title . $subtitle1 . $subtitle2;
	}
}