<?php

namespace LordArrow9\ClearChatTutorial;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class ClearChatTutorial extends PluginBase{

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool{

        switch ($command->getName()){

            case "clearchat":
                if(!$sender instanceof Player){
                    $sender->sendMessage("Du kannst diesen Befehl nur Ingame verwenden!");
                    return false;
                }
                if(!$sender->hasPermission("clearchat.command")){
                    $sender->sendMessage("§cBLAD, POTRZEBUJESZ PERMISJI §a(clearchat.command) !");
                    return false;
                }
                $i = 0;
                while ($i < 100){
                    $this->getServer()->broadcastMessage(" ");
                    $i++;
                }
                $this->getServer()->broadcastMessage("           §gRUSTPE.PL\n\n§8§l» §r§7Chat zostal wyczyszczony przez §g" . $sender->getName() . "§c!");
                break;
        }
        return true;
    }
}