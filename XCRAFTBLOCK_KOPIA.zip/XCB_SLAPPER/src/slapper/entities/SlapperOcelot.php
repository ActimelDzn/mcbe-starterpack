<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperOcelot extends SlapperEntity {

    const TYPE_ID = 22;
    const HEIGHT = 0.7;

}
