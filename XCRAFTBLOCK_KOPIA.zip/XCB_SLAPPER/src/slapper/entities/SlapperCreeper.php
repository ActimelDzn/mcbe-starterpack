<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperCreeper extends SlapperEntity {

    const TYPE_ID = 33;
    const HEIGHT = 1.7;

}
