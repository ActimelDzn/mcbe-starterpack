This package provides the JDBC specific functionality.  You will also need to download the
ormlite-core package as well.  Android users should download the ormlite-android package instead of
this JDBC one.

For more information, see the online documentation on the home page:

   http://ormlite.com/

Sources can be found online via Github:

   https://github.com/j256/ormlite-jdbc

Enjoy,
Gray Watson
