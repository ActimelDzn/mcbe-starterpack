package pl.vertty.arivi.drop.data;

public interface DataExecutor
{
    void save();
    
    void load();

    void clear();

    void check();
}
