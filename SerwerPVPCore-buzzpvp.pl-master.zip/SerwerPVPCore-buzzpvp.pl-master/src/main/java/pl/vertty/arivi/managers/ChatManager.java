
package pl.vertty.arivi.managers;

public class ChatManager
{
    public static boolean enable;
    public static boolean vipChat;
    
    static {
        ChatManager.enable = true;
        ChatManager.vipChat = false;
    }
}
