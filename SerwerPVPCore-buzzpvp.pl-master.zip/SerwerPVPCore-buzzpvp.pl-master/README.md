# ServerPVPCore - BuzzHC.pl
Pełny core z serwera buzzpvp.pl na wersje 1.19 nukkit

## Robisz builda odpalasz serwer i cyk, wszystko działa możesz odpalić na tym edycje.

Kod nie jest najgorszy ani najlepszy.

## Lista funkcji
- zobacz w src bo jest tam w chuj nasrane wszystkiego


## Jeżeli znajdziesz błąd napisz na dc: VerttyPL#7533
