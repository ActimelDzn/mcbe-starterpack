<?php

namespace AntyCheat\Tasks;

use AntyCheat\AntyCheat;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class AntyCheatClicksTask extends Task
{

    public $plugin;
    public $player;

    public function __construct(AntyCheat $plugin, Player $player)
    {
        $this->plugin = $plugin;
        $this->player = $player;
    }

    public function onRun($currentTick)
    {
        if ($this->getServer()->getPlayer($this->getPlayer()->getName()) instanceof Player) {
            $this->getPlugin()->cps[$this->getPlayer()->getName()] = $this->getPlugin()->clicks[$this->getPlayer()->getName()];
            $this->getPlugin()->clicks[$this->getPlayer()->getName()] = 0;
        } else {
            $this->getHandler()->cancel();
        }
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }

    public function getPlayer()
    {
        return $this->player;
    }

    public function getPlugin()
    {
        return $this->plugin;
    }
}