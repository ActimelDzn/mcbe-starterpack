<?php

namespace SystemPunktow;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use SQLite3;

class SystemPunktow extends PluginBase implements Listener
{

    /* Player Functions */
    public $attacker = [];
    public $assister = [];
    public $address_ip = [];
    /* Top Functions */
    public $TopPoints = array(11);
    public $TopKills = array(11);
    public $TopDeaths = array(11);
    public $TopAssists = array(11);
    public $getLevelInTop = array(9999);
    /* Other */
    public $statsCommand;
    public $db;


    public function onEnable()
    {
        /* Register functions and Commands */
        $this->getServer()->getPluginManager()->registerEvents(new SystemEventListener($this), $this);
        $this->statsCommand = new SystemCommands($this);
        /* Files */
        @mkdir($this->getDataFolder());
        $this->db = new SQLite3($this->getDataFolder() . "Files.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS stats(player TEXT PRIMARY KEY, points INT, kills INT, deaths INT, assists INT);");
        $this->saveDefaultConfig();
        /* Other */
        date_default_timezone_set('Europe/Warsaw');
    }

    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args): bool
    {
        $this->statsCommand->onCommand($sender, $cmd, $label, $args);
        return true;
    }

    public function fakeDeath(Player $player)
    {
        $killer = $this->getAttacker($player->getName());
        $assister = $this->getAssister($player->getName());
        $player2 = $this->getServer()->getPlayer($killer);
        #$player3 = $this->getServer()->getPlayer($assister);
        $kill = explode(",", $this->getConfig()->get("Kill"), 2);
        $rand = rand($kill[0], $kill[1]);
        $death = explode(",", $this->getConfig()->get("Death"), 2);
        $rand2 = rand($death[0], $death[1]);
        $assist = explode(",", $this->getConfig()->get("Assist"), 2);
        $rand3 = rand($assist[0], $assist[1]);
        $core = $this->api("cloudCore");
        if ($this->getAddress_ip($killer) != $player->getAddress() or $this->getAddress_ip($killer) == false) {
            if ($this->getAttacker($player->getName()) == false && $this->getAssister($player->getName()) == false) {
                $this->addDeaths($player->getName(), 1);
                $this->reducePoints($player->getName(), $rand2);
                $player->sendMessage($this->formatMessage("Tracisz§b " . $rand2 . " §7punktow przez smierc", true));
            }
            if (!$this->getAttacker($player->getName()) == false && $this->getAssister($player->getName()) == false) {
                foreach ($this->getServer()->getOnlinePlayers() as $p) {
                    $p->sendMessage($this->formatMessage("Gracz§b " . $core->getFactionAsString($killer, $p->getName()) . "§b" . $killer . " §8[§a+" . $rand . "§8] §7zabil " . $core->getFactionAsString($player->getName(), $p->getName()) . "§b" . $player->getName() . " §8[§b-" . $rand2 . "§8]", true));
                }
                $this->addKills($killer, 1);
                $this->addKills($killer, 1);
                $this->addPoints($killer, $rand);
                $this->addDeaths($player->getName(), 1);
                $this->reducePoints($player->getName(), $rand2);
                $player->sendMessage($this->formatMessage("Tracisz§b " . $rand2 . " §7punktow przez smierc od§b " . $killer, true));
                $player2->sendMessage($this->formatMessage("Otrzymujesz§b " . $rand . " §7punktow za zabicie§b " . $player->getName(), true));
                $inventory = $player->getInventory();
                if ($this->getConfig()->get("ItemsDrop") == false) {
                    foreach ($inventory->getContents() as $items) {
                        if ($player2->getInventory()->canAddItem($items)) {
                            $player2->getInventory()->addItem($items);
                        } else {
                            $x = $player->getX();
                            $y = $player->getY();
                            $z = $player->getZ();
                            $player->getLevel()->dropItem(new Vector3($x, $y, $z), $items);
                        }
                    }
                }
                $this->setAddress_ip($killer, $player);
                $this->setAttacker($player->getName(), false);
            }
            if (!$this->getAttacker($player->getName()) == false && !$this->getAssister($player->getName()) == false) {
                foreach ($this->getServer()->getOnlinePlayers() as $p) {
                    $p->sendMessage($this->formatMessage("Gracz§b " . $core->getFactionAsString($killer, $p->getName()) . "§b" . $killer . " §8[§a+" . $rand . "§8] §7zabil" . $core->getFactionAsString($player->getName(), $p->getName()) . "§b" . $player->getName() . " §8[§b-" . $rand2 . "§8] §7z asysta gracza " . $core->getFactionAsString($assister, $p->getName()) . " §b" . $assister . " §8[§a+" . $rand3 . "§8]", true));
                }
                $this->addAssist($assister, 1);
                $this->addKills($killer, 1);
                $this->addPoints($killer, $rand);
                $this->addPoints($assister, $rand3);
                $this->addDeaths($player->getName(), 1);
                $this->reducePoints($player->getName(), $rand2);
                $player->sendMessage($this->formatMessage("Tracisz§b " . $rand2 . " §7punktow przez smierc od§b " . $killer . " §7oraz§b " . $assister . "", true));
                $player2->sendMessage($this->formatMessage("Otrzymujesz§b " . $rand . " §7punktow za zabicie§b " . $player->getName() . " §7z pomoca§b " . $assister . "", true));
                $inventory = $player->getInventory();
                if ($this->getConfig()->get("ItemsDrop") == false) {
                    foreach ($inventory->getContents() as $items) {
                        if ($player2->getInventory()->canAddItem($items)) {
                            $player2->getInventory()->addItem($items);
                        } else {
                            $x = $player->getX();
                            $y = $player->getY();
                            $z = $player->getZ();
                            $player->getLevel()->dropItem(new Vector3($x, $y, $z), $items);
                        }
                    }
                }
                $this->setAddress_ip($killer, $player);
                $this->setAttacker($player->getName(), false);
                $this->setAssister($player->getName(), false);
            }
        } else {
            $player2->sendMessage($this->formatMessage("Wykryto ten sam adres ip co u poprzedniej ofiary, punkty nie zostana dodane!", false));
            foreach ($this->getServer()->getOnlinePlayers() as $p) {
                $p->sendMessage($this->formatMessage("Gracz§b " . $core->getFactionAsString($killer, $p->getName()) . " §b" . $killer . " §8[§a+0§8] §7zabil" . $core->getFactionAsString($player->getName(), $p->getName()) . "§b" . $player->getName() . " §8[§b-" . $rand2 . "§8]", true));
            }
            $this->addDeaths($player->getName(), 1);
            $this->reducePoints($player->getName(), $rand2);
            $inventory = $player->getInventory();
            if ($this->getConfig()->get("ItemsDrop") == false) {
                foreach ($inventory->getContents() as $items) {
                    if ($player2->getInventory()->canAddItem($items)) {
                        $player2->getInventory()->addItem($items);
                    } else {
                        $x = $player->getX();
                        $y = $player->getY();
                        $z = $player->getZ();
                        $player->getLevel()->dropItem(new Vector3($x, $y, $z), $items);
                    }
                }
            }
            $player->sendMessage($this->formatMessage("Tracisz§b " . $rand2 . " §7punktow przez smierc od§b " . $killer, true));
        }
    }

    public function getAttacker(String $player)
    {
        if (isset($this->attacker[$player])) {
            return $this->attacker[$player];
        } else {
            $this->attacker[$player] = false;
        }
    }

    public function setAttacker(String $player, String $attacker)
    {
        $this->attacker[$player] = $attacker;
    }

    public function getAssister(String $player)
    {
        if (isset($this->assister[$player])) {
            return $this->assister[$player];
        } else {
            $this->assister[$player] = false;
        }
    }

    public function setAssister(String $player, String $assister)
    {
        $this->assister[$player] = $assister;
    }

    public function api(String $plugin)
    {
        return $this->getServer()->getPluginManager()->getPlugin($plugin);
    }

    public function getAddress_ip(String $player)
    {
        if (isset($this->address_ip[$player])) {
            return $this->address_ip[$player];
        } else {
            $this->address_ip[$player] = false;
        }
    }

    public function setAddress_ip(String $player, Player $player2)
    {
        $this->address_ip[$player] = $player2->getAddress();
    }

    public function addDeaths(String $player, int $amount)
    {
        $this->db->query("UPDATE stats SET deaths = deaths + '$amount' WHERE player='$player';");
    }

    public function reducePoints(String $player, int $amount)
    {
        $this->db->query("UPDATE stats SET points = points + '-$amount' WHERE player='$player';");
    }

    public function formatMessage(String $string, $confirm = false)
    {
        $success = $this->getConfig()->get("PrefixSuccess");
        $failure = $this->getConfig()->get("PrefixFailure");
        if ($confirm) {
            return str_replace('{STRING}', $string, $success);
        } else {
            return str_replace('{STRING}', $string, $failure);
        }
    }

    public function addKills(String $player, int $amount)
    {
        $this->db->query("UPDATE stats SET kills = kills + '$amount' WHERE player='$player';");
    }

    public function addPoints(String $player, int $amount)
    {
        $this->db->query("UPDATE stats SET points = points + '$amount' WHERE player='$player';");
    }

    public function addAssist(String $player, int $amount)
    {
        $this->db->query("UPDATE stats SET assists = assists + '$amount' WHERE player='$player';");
    }

    public function addPlayer(String $player)
    {
        $defaultPoints = $this->getConfig()->get("StartingPoints");
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO stats (player, points, kills, deaths, assists) VALUES (:player, :points, :kills, :deaths, :assists);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":points", $defaultPoints);
        $stmt->bindValue(":kills", 0);
        $stmt->bindValue(":deaths", 0);
        $stmt->bindValue(":assists", 0);
        $result = $stmt->execute();
    }

    public function playerExists(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM stats WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        if (!empty($stmt)) {
            return true;
        } else {
            return false;
        }
    }

    public function setPoints(String $player, int $amount)
    {
        $this->db->query("UPDATE stats SET points='$amount' WHERE player='$player';");
    }

    public function getKD(String $player)
    {
        $kills = $this->getKills($player);
        $deaths = $this->getDeaths($player);
        if ($kills == $deaths or $deaths == 0) {
            return $kills . ".00";
        } else {
            return str_replace(array('NAN', 'INF'), '0.00', round($kills / $deaths, 2));
        }
    }

    public function getKills(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM stats WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['kills'];
    }

    public function getDeaths(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM stats WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['deaths'];
    }

    public function getPointsTop()
    {
        $players = $this->db->query("SELECT * FROM stats ORDER BY points DESC LIMIT 10");
        $this->TopPoints[11] = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $this->TopPoints[11]++;
            $this->TopPoints[$this->TopPoints[11]] = "§b" . $row[0] . "§7 - §8(§7Punkty§b " . $row[1] . "§8)";
        }
    }

    public function getKillsTop()
    {
        $players = $this->db->query("SELECT * FROM stats ORDER BY kills DESC LIMIT 10");
        $this->TopKills[11] = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $this->TopKills[11]++;
            $this->TopKills[$this->TopKills[11]] = "§b" . $row[0] . "§7 - §8(§7Zabojstwa§b " . $row[2] . "§8)";
        }
    }

    public function getAssistsTop()
    {
        $players = $this->db->query("SELECT * FROM stats ORDER BY assists DESC LIMIT 10");
        $this->TopAssists[11] = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $this->TopAssists[11]++;
            $this->TopAssists[$this->TopAssists[11]] = "§b" . $row[0] . "§7 - §8(§7Asysty§b " . $row[2] . "§8)";
        }
    }

    public function getDeathsTop()
    {
        $players = $this->db->query("SELECT * FROM stats ORDER BY deaths DESC LIMIT 10");
        $this->TopDeaths[11] = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $this->TopDeaths[11]++;
            $this->TopDeaths[$this->TopDeaths[11]] = "§b" . $row[0] . "§7 - §8(§7Smierci§b " . $row[3] . "§8)";
        }
    }

    public function openStats(String $sender, String $name)
    {
        if ($this->getServer()->getPlayer($sender) instanceof Player) {
            $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly();
            $core = $this->api("cloudCore");
            $menuname = $core->getFactionAsString($name, $sender) . "§b" . $name;
            $money = $core->getMoney($name);
            $koxy = $core->getEnchantedGolden($name);
            $refy = $core->getGolden($name);
            $perly = $core->getPearl($name);
            $premium = $core->getPremium($name);
            $wydane = $core->getSpendMoney($name);
            $menu->setName("§l§8» §b" . $menuname);

            $inv = $menu->getInventory();
            $inv->clearAll(false);

            $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
            $item->setCustomName("§l§8» §7Zabojstwa: §b" . $this->getKills($name));
            $inv->setItem(20, $item);

            $item = Item::get(Item::MOB_HEAD, 0, 1);
            $item->setCustomName("§l§8» §7Smierci: §b" . $this->getDeaths($name));
            $inv->setItem(23, $item);

            $item = Item::get(Item::MOB_HEAD, 3, 1);
            $item->setCustomName("§l§8» §7Punkty: §b" . $this->getPoints($name) . " §8[§b" . $this->getTopLevel($name) . "§8]");
            $inv->setItem(21, $item);

            $item = Item::get(Item::MOB_HEAD, 2, 1);
            $item->setCustomName("§l§8» §7Asysty: §b" . $this->getAssists($name));
            $inv->setItem(22, $item);
            $menu->send($this->getServer()->getPlayer($sender));

            $item = Item::get(Item::DIAMOND_AXE, 0, 1);
            $item->setCustomName("§l§8» §7Monety:§b $money");
            $inv->setItem(24, $item);

            $item = Item::get(Item::CHEST, 0, 1);
            $item->setCustomName("§l§8» §7Otworzone Premium Case'y:§b $premium");
            $inv->setItem(29, $item);

            $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
            $item->setCustomName("§l§8» §7Zjedzone refile:§b $refy");
            $inv->setItem(30, $item);

            $item = Item::get(Item::ENDER_PEARL, 0, 1);
            $item->setCustomName("§l§8» §7Rzucone perly:§b $perly");
            $inv->setItem(31, $item);

            $item = Item::get(466, 0, 1);
            $item->setCustomName("§l§8» §7Zjedzone koxy:§b $koxy");
            $inv->setItem(32, $item);

            $item = Item::get(Item::DIAMOND_SHOVEL, 0, 1);
            $item->setCustomName("§l§8» §7Wydane Monety:§b $wydane");
            $inv->setItem(33, $item);

        } else {
            $this->getLogger()->info("Wystapil blad podczas otwierania ekiwpunku ze statystykami gracza...");
        }
    }

    public function getPoints(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM stats WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['points'];
    }

    public function getTopLevel($player)
    {
        $players = $this->db->query("SELECT * FROM stats ORDER BY points DESC LIMIT 9999");
        $this->getLevelInTop[9999] = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $this->getLevelInTop[9999]++;
            $this->getLevelInTop[$this->getLevelInTop[9999]] = $row[0];
        }
        for ($i = 1; $i < 9999; $i++) {
            if ($this->getLevelInTop[$i] == $player) {
                return $i;
            }
        }
    }

    /*
     * Both params are strings.
     */

    public function getAssists(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM stats WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['assists'];
    }
}