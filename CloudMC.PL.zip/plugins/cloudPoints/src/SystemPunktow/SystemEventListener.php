<?php

namespace SystemPunktow;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\math\Vector3;
use pocketmine\Player;

class SystemEventListener implements Listener
{

    public $plugin;

    public function __construct(SystemPunktow $pg)
    {
        $this->plugin = $pg;
    }

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();

        if ($this->plugin->playerExists($player->getName()) == false) {
            $this->plugin->addPlayer($player->getName());
        }

        $this->plugin->setAttacker($player->getName(), false);
        $this->plugin->setAssister($player->getName(), false);
    }

    public function EntityDamageEvent(EntityDamageEvent $event)
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            if ($event->getEntity() instanceof Player and $event->getDamager() instanceof Player) {
                if (!($event->isCancelled())) {
                    $player1 = $event->getEntity()->getPlayer()->getName();
                    $player2 = $event->getDamager()->getPlayer()->getName();
                    $faction1 = $this->plugin->api("cloudGuilds")->getPlayerFaction($player1);
                    $faction2 = $this->plugin->api("cloudGuilds")->getPlayerFaction($player2);
                    if (!($this->plugin->getAttacker($player1) == $player2)) {
                        $this->plugin->setAssister($player1, $this->plugin->getAttacker($player1));
                        $this->plugin->setAttacker($player1, $player2);
                    }
                    if (!($this->plugin->getAttacker($player2) == $player1)) {
                        $this->plugin->setAssister($player2, $this->plugin->getAttacker($player2));
                        $this->plugin->setAttacker($player2, $player1);
                    }
                }
            }
        }
    }

    public function onDeath(PlayerDeathEvent $event)
    {
        $event->setDeathMessage("");
        $player = $event->getPlayer();
        $killer = $this->plugin->getAttacker($player->getName());
        $assister = $this->plugin->getAssister($player->getName());
        $player2 = $this->plugin->getServer()->getPlayer($killer);
        $kill = explode(",", $this->plugin->getConfig()->get("Kill"), 2);
        $rand = rand($kill[0], $kill[1]);
        $death = explode(",", $this->plugin->getConfig()->get("Death"), 2);
        $rand2 = rand($death[0], $death[1]);
        $assist = explode(",", $this->plugin->getConfig()->get("Assist"), 2);
        $rand3 = rand($assist[0], $assist[1]);
        $core = $this->plugin->api("cloudCore");
        if ($this->plugin->getAddress_ip($killer) != $player->getAddress() or $this->plugin->getAddress_ip($killer) == false) {
            if ($this->plugin->getAttacker($player->getName()) == false && $this->plugin->getAssister($player->getName()) == false) {
                $this->plugin->addDeaths($player->getName(), 1);
                $this->plugin->reducePoints($player->getName(), $rand2);
                $player->sendMessage($this->plugin->formatMessage("Tracisz§b " . $rand2 . " §7punktow przez smierc", true));
            }
            if (!$this->plugin->getAttacker($player->getName()) == false && $this->plugin->getAssister($player->getName()) == false) {
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                    $p->sendMessage($this->plugin->formatMessage("Gracz§b " . $core->getFactionAsString($killer, $p->getName()) . "§b" . $killer . " §8[§a+" . $rand . "§8] §7zabil " . $core->getFactionAsString($player->getName(), $p->getName()) . "§b" . $player->getName() . " §8[§b-" . $rand2 . "§8]", true));
                }
                $this->plugin->addKills($killer, 1);
                $this->plugin->addPoints($killer, $rand);
                $this->plugin->addDeaths($player->getName(), 1);
                $this->plugin->reducePoints($player->getName(), $rand2);
                $player->sendMessage($this->plugin->formatMessage("Tracisz§b " . $rand2 . " §7punktow przez smierc od§b " . $killer, true));

                $inventory = $player->getInventory();
                if ($this->plugin->getConfig()->get("ItemsDrop") == false) {
                    foreach ($inventory->getContents() as $items) {
                        if ($player2->getInventory()->canAddItem($items)) {
                            $player2->getInventory()->addItem($items);
                        } else {
                            $x = $player->getX();
                            $y = $player->getY();
                            $z = $player->getZ();
                            $player->getLevel()->dropItem(new Vector3($x, $y, $z), $items);
                        }
                    }
                }
                $this->plugin->setAddress_ip($killer, $player);
                $this->plugin->setAttacker($player->getName(), false);
            }
            if (!$this->plugin->getAttacker($player->getName()) == false && !$this->plugin->getAssister($player->getName()) == false) {
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                    $p->sendMessage($this->plugin->formatMessage("Gracz§b " . $core->getFactionAsString($killer, $p->getName()) . "§b" . $killer . " §8[§a+" . $rand . "§8] §7zabil " . $core->getFactionAsString($player->getName(), $p->getName()) . "§b" . $player->getName() . " §8[§b-" . $rand2 . "§8] §7z asysta gracza " . $core->getFactionAsString($assister, $p->getName()) . "§b" . $assister . " §8[§a+" . $rand3 . "§8]", true));
                }
                $this->plugin->addAssist($assister, 1);
                $this->plugin->addKills($killer, 1);
                $this->plugin->addPoints($killer, $rand);
                $this->plugin->addPoints($assister, $rand3);
                $this->plugin->addDeaths($player->getName(), 1);
                $this->plugin->reducePoints($player->getName(), $rand2);
                $inventory = $player->getInventory();
                if ($this->plugin->getConfig()->get("ItemsDrop") == false) {
                    foreach ($inventory->getContents() as $items) {
                        if ($player2->getInventory()->canAddItem($items)) {
                            $player2->getInventory()->addItem($items);
                        } else {
                            $x = $player->getX();
                            $y = $player->getY();
                            $z = $player->getZ();
                            $player->getLevel()->dropItem(new Vector3($x, $y, $z), $items);
                        }
                    }
                }
                $this->plugin->setAddress_ip($killer, $player);
                $this->plugin->setAttacker($player->getName(), false);
                $this->plugin->setAssister($player->getName(), false);
            }
        } else {
            $player->sendMessage("");
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                $p->sendMessage($this->plugin->formatMessage("Gracz§b " . $core->getFactionAsString($killer, $p->getName()) . "§b" . $killer . " §8[§a+0§8] §7zabil " . $core->getFactionAsString($player->getName(), $p->getName()) . "§b" . $player->getName() . " §8[§b-" . $rand2 . "§8]", true));
            }
            $this->plugin->addDeaths($player->getName(), 1);
            $this->plugin->reducePoints($player->getName(), $rand2);
            $inventory = $player->getInventory();
            if ($this->plugin->getConfig()->get("ItemsDrop") == false) {
                foreach ($inventory->getContents() as $items) {
                    if ($player2->getInventory()->canAddItem($items)) {
                        $player2->getInventory()->addItem($items);
                    } else {
                        $x = $player->getX();
                        $y = $player->getY();
                        $z = $player->getZ();
                        $player->getLevel()->dropItem(new Vector3($x, $y, $z), $items);
                        $item = Item::get(Item::MOB_HEAD, 0, 1);
                        $item->setCustomName("§l§8» Glowa gracza:§b $player");
                        $player->getLevel()->dropItem(new Vector3($x, $y, $z), $item);
                    }
                }
            }
            $player->sendMessage($this->plugin->formatMessage("Tracisz§b " . $rand2 . " §7punktow przez smierc od§b " . $killer, true));
        }
    }
}