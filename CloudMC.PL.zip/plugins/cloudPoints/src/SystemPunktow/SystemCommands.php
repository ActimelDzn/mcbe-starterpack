<?php

namespace SystemPunktow;

use pocketmine\command\{Command, CommandSender};
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;

class SystemCommands
{

    public $plugin;

    public function __construct(SystemPunktow $pg)
    {
        $this->plugin = $pg;
    }

    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args): bool
    {
        if ($sender instanceof Player) {
            if ($cmd->getName() == "stats") {
                if (count($args) == 0) {
                    $this->plugin->openStats($sender->getName(), $sender->getName());
                    return true;
                }
                if (count($args) == 1) {
                    if ($this->plugin->playerExists($args[0]) == true) {
                        $this->plugin->openStats($sender->getName(), $args[0]);
                        return true;
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono gracza§b " . $args[0] . " §bw bazie danych!", false));
                        return true;
                    }
                }
            }
            if ($cmd->getName() == "resetujranking") {
                if (count($args) == 0) {
                    if ($sender->getInventory()->contains(Item::get(388, 0, 256))) {
                        $this->plugin->setPoints($sender->getName(), 500);
                        $sender->sendMessage($this->plugin->formatMessage("Zresetowano ranking pomyslnie!", true));
                        $sender->getInventory()->removeItem(Item::get(388, 0, 256));
                        return true;
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Aby zresetowac ranking potrzebujesz 256 emeraldow!", true));
                        return true;
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty", false));
                    return true;
                }
            }
            if ($cmd->getName() == "opstats") {
                if ($sender->hasPermission("f.override")) {
                    if (count($args) == 0) {
                        $sender->sendMessage("§8[ §7---------- §8[§b§lAdmin Stats§r§8] §7---------- §8]");
                        $sender->sendMessage("§b* §7/opstats dodajpunky <gracz> <ilosc>");
                        $sender->sendMessage("§b* §7/opstats usunpunkty <gracz> <ilosc>");
                        $sender->sendMessage("§b* §7/opstats ustawpunkty <gracz> <ilosc>");
                        $sender->sendMessage("§8[ §7---------- §8[§b§lAdmin Stats§r§8] §7---------- §8]");
                        return true;
                    }
                    if (count($args) == 3) {
                        if ($args[0] == "dodajpunkty") {
                            if (!isset($args[1])) {
                                $sender->sendMessage($this->plugin->formatMessage("Poprawne uzycie: /opstats dodajpunkty <gracz> <ilosc>", false));
                                return true;
                            }
                            if (!is_numeric($args[2])) {
                                $sender->sendMessage($this->plugin->formatMessage("Ilosc punktow musi byc numeryczna!", false));
                                return true;
                            }
                            $this->plugin->addPoints($args[1], $args[2]);
                            $sender->sendMessage($this->plugin->formatMessage("Dodano§b " . $args[2] . " §7punktow dla gracza§b " . $args[1] . "", true));
                            return true;
                        }
                        if ($args[0] == "usunpunkty") {
                            if (!isset($args[1])) {
                                $sender->sendMessage($this->plugin->formatMessage("Poprawne uzycie: /opstats usunpunkty <gracz> <ilosc>", false));
                                return true;
                            }
                            if (!is_numeric($args[2])) {
                                $sender->sendMessage($this->plugin->formatMessage("Ilosc punktow musi byc numeryczna!", false));
                                return true;
                            }
                            $this->plugin->addPoints($args[1], $args[2]);
                            $sender->sendMessage($this->plugin->formatMessage("Usunieto§b " . $args[2] . " §7punktow dla gracza§b " . $args[1] . "", true));
                            return true;
                        }
                        if ($args[0] == "ustawpunkty") {
                            if (!isset($args[1])) {
                                $sender->sendMessage($this->plugin->formatMessage("Poprawne uzycie: /opstats ustawpunkty <gracz> <ilosc>", false));
                                return true;
                            }
                            if (!is_numeric($args[2])) {
                                $sender->sendMessage($this->plugin->formatMessage("Ilosc punktow musi byc numeryczna!", false));
                                return true;
                            }
                            $this->plugin->setPoints($args[1], $args[2]);
                            $sender->sendMessage($this->plugin->formatMessage("Ustawiono§b " . $args[2] . " §7punktow dla gracza§b " . $args[1] . "", true));
                            return true;
                        }
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie masz dostepu do tej komendy!"));
                }
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Tej komendy nie mozesz uzyc w konsoli!", false));
            return true;
        }
        return true;
    }
}