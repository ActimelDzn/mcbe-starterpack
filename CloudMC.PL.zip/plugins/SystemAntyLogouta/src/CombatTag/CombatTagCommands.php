<?php

namespace CombatTag;

use pocketmine\command\{Command, CommandSender};
use pocketmine\network\mcpe\protocol\BossEventPacket;
use pocketmine\Player;
use pocketmine\Server;

class CombatTagCommands
{

    public $plugin;

    public function __construct(CombatTag $pg)
    {
        $this->plugin = $pg;
    }

    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args): bool
    {
        if ($cmd->getName() == "combattag") {
            if ($sender->hasPermission("combattag.override")) {
                if (count($args) == 0 or empty($args)) {
                    $sender->sendMessage($this->plugin->formatMessage("Poprawne uzycie: /combattag wylacz/wlacz <nick>", false));
                    return true;
                }
                if (count($args) == 1) {
                    $sender->sendMessage($this->plugin->formatMessage("Poprawne uzycie: /combattag wylacz/wlacz <nick>", false));
                    return true;
                }
                if (count($args) == 2) {
                    if ($args[0] == "wylacz") {
                        if ($this->plugin->getServer()->getPlayer($args[1]) instanceof Player) {
                            $this->plugin->endFight($this->plugin->getServer()->getPlayer($args[1])->getName());
                            $sender->sendMessage($this->plugin->formatMessage("Wylaczono tryb walki dla: " . $args[1] . " pomyslnie", true));
                            if (isset($this->plugin->bossbar[$this->plugin->getServer()->getPlayer($args[1])->getName()])) {
                                $pk = new BossEventPacket();
                                $pk->bossEid = $this->plugin->bossbar[$this->plugin->getServer()->getPlayer($args[1])->getName()];
                                $pk->eventType = BossEventPacket::TYPE_HIDE;
                                $this->plugin->getServer()->getPlayer($args[1])->sendDataPacket($pk);
                            }
                            return true;
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                            return true;
                        }
                    }
                    if ($args[0] == "wlacz") {
                        if ($this->plugin->getServer()->getPlayer($args[1]) instanceof Player) {
                            $sender->sendMessage($this->plugin->formatMessage("Wlaczono tryb walki dla: " . $args[1] . " pomyslnie", true));
                            $this->plugin->startFight($this->plugin->getServer()->getPlayer($args[1]));
                            return true;
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                            return true;
                        }
                    }
                    if ($args[0] == "reload") {
                        $this->plugin->getConfig()->reload();
                        $sender->sendMessage($this->plugin->formatMessage("Odswiezono config", true));
                    }
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie masz dostepu do tej komendy!", false));
                return true;
            }
        }
        return true;
    }
}