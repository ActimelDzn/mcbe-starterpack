<?php

namespace CombatTag;

use pocketmine\block\Block;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\inventory\InventoryOpenEvent;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\inventory\CraftItemEvent;

class CombatTagEventListener implements Listener
{

    public $plugin;

    public function __construct(CombatTag $pg)
    {
        $this->plugin = $pg;
    }

    public function onQuit(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer();
        if ($this->plugin->isInFight($player->getName())) {
            $player->kill();
            $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " wylogowal sie podczas walki!", true));
            $this->plugin->endFight($player->getName());
        }
    }

    public function onDeath(PlayerDeathEvent $event)
    {
        $player = $event->getEntity();
        if ($this->plugin->isInFight($player->getName())) {
            $this->plugin->endFight($player->getName());
        }
    }

   /**
     * @priority MONITOR
     * @param PlayerChatEvent $event
     */
    public function EntityDamageEvent(EntityDamageEvent $event)
    {
        if (!$event->isCancelled()) {
            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                $player = $event->getEntity();
                if ($damager instanceof Player and $player instanceof Player) {
                    foreach ([$damager, $player] as $players) {
                        $this->plugin->startFight($players);
                    }
                }
            }
        }
    }

    public function onPlayerCommandPreprocess(PlayerCommandPreprocessEvent $event)
    {
        $player = $event->getPlayer();
        $cmd = strtolower(explode(' ', $event->getMessage())[0]);
        if ($this->plugin->isInFight($player->getName())) {
            if ($this->plugin->isCommandBlocked($cmd)) {
                $player->sendMessage($this->plugin->formatMessage("Tej komendy nie mozesz uzyc podczas walki!", false));
                $event->setCancelled();
            }
        }
    }

    public function knockAndAttackDelay(EntityDamageEvent $event)
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $event->setKnockback(0.320);
        }
    }

    /**
     * @priority MONITOR
     * @param BlockPlaceEvent $event
     */

    public function onPlace(BlockPlaceEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $faction = $this->plugin->api("cloudGuilds");
        $height = $this->plugin->getHeightLimit();
        if ($this->plugin->isInFight($player->getName())) {
            if ($faction->inOwnPlot($event->getPlayer(), $block->getX(), $block->getZ())) {
                if ($block->getY() < $height) {
                    $event->setCancelled();
                    $player->sendMessage($this->plugin->formatMessage("Bloki na terenie swojej gildii podczas walki mozesz stawiac powyzej Y: " . $height . "!", false));
                }
            }
        }
        if ($this->plugin->isInFight($player->getName())) {
            if ($block->getId() == Block::FURNACE or
                $block->getId() == Block::WORKBENCH or
                $block->getId() == Block::CHEST or
                $block->getId() == Block::TRAPPED_CHEST or
                $block->getId() == Block::ENDER_CHEST) {
                $event->setCancelled();
            }
        }
    }

    public function onTouch(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        if ($event->getAction() == PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            if ($this->plugin->isInFight($player->getName())) {
                if ($block->getId() == Block::FURNACE or
                    $block->getId() == Block::WORKBENCH or
                    $block->getId() == Block::CHEST or
                    $block->getId() == Block::TRAPPED_CHEST or
                    $block->getId() == Block::ENDER_CHEST) {
                    $event->setCancelled();
                }
            }
        }
    }

    public function onCraft(CraftItemEvent $event)
    {
        $player = $event->getPlayer();
        if ($this->plugin->isInFight($player->getName())) {
            $event->setCancelled();
        }
    }

    public function onMove(PlayerMoveEvent $event)
    {
        $to = $event->getTo();
        $from = $event->getFrom();
        if ($to->getX() == $from->getX() && $to->getY() == $from->getY() && $to->getZ() == $from->getZ()) {
            return;
        }
        $cloudprotect = $this->plugin->api("cloudProtect");
        $player = $event->getPlayer();
        if ($this->plugin->isInFight($player->getName())) {
            if (!$cloudprotect->canGetHurt($player)) {
                $spawn = $this->plugin->getServer()->getDefaultLevel()->getSpawnLocation();
                $player->knockBack($player, 0, $to->getX() - $spawn->getX(), $to->getZ() - $spawn->getZ(), 0.4);
                }
            }
        }
    }