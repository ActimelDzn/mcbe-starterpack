<?php
namespace CombatTag;

use pocketmine\entity\utils\Bossbar;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\network\mcpe\protocol\BossEventPacket;

class CombatTagTask extends Task
{

    public $plugin;

    public function __construct(CombatTag $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick)
    {
        foreach ($this->plugin->infight as $player => $time) {
            $p = $this->plugin->getServer()->getPlayer($player);
            $fighttime = $this->plugin->getFightTime();
            if ($p instanceof Player) {
                if ((time() - $time) > $fighttime) {
                    $pk = new BossEventPacket();
                    $pk->bossEid = $this->plugin->bossbar[$p->getName()];
                    $pk->eventType = BossEventPacket::TYPE_HIDE;
                    $p->sendDataPacket($pk);

                    $this->plugin->endFight($p->getName());
                    unset($this->plugin->bossbar[$p->getName()]);
                } else {
                    if (isset($this->plugin->bossbar[$p->getName()])) {
                        $pk = new BossEventPacket();
                        $pk->bossEid = $this->plugin->bossbar[$p->getName()];
                        $pk->eventType = BossEventPacket::TYPE_HIDE;
                        $p->sendDataPacket($pk);
                    }
                    $hp = ($fighttime - (time() - $time));
                    if ($hp == 0) {
                        $bossbar = new Bossbar("§l§3ANTYLOGOUT - KONIEC WALKI§r", $hp, $fighttime);
                        $bossbar->showTo($p);
                        $this->plugin->bossbar[$p->getName()] = $bossbar->getEntityId();
                    } elseif ($hp > 0) {
                        switch (mt_rand(1, 2)) {
                            case 1:
                                $bossbar = new Bossbar("§l§bANTYLOGOUT - " . $hp . "s§r", $hp, $fighttime);
                                $bossbar->showTo($p);
                                $this->plugin->bossbar[$p->getName()] = $bossbar->getEntityId();
                                break;
                            case 2:
                                $bossbar = new Bossbar("§l§1ANTYLOGOUT - " . $hp . "s§r", $hp, $fighttime);
                                $bossbar->showTo($p);
                                $this->plugin->bossbar[$p->getName()] = $bossbar->getEntityId();
                                break;
                        }
                    }
                }
            } else {
                $this->plugin->endFight($player);
            }
        }
    }
}