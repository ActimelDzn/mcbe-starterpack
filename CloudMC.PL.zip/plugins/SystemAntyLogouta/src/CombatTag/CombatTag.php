<?php

namespace CombatTag;

use pocketmine\event\Listener;
use pocketmine\network\mcpe\protocol\BossEventPacket;
use pocketmine\plugin\PluginBase;
use pocketmine\command\{Command, CommandSender};
use pocketmine\math\Vector3;

class CombatTag extends PluginBase implements Listener
{

    public $config;
    public $infight = [];
    public $blockedcommands = [];
    public $bossbar = [];
    public $kb = [];

    public function onEnable()
    {
        $this->getServer()->getPluginManager()->registerEvents(new CombatTagEventListener($this), $this);
        $this->CombatTagCommand = new CombatTagCommands($this);

        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();

        $this->getScheduler()->scheduleRepeatingTask(new CombatTagTask($this, $this->getConfig()->get("FightTime")), 20);

        $cmds = $this->getConfig()->get("blocked-commands");
        foreach ($cmds as $cmd) {
            $this->blockedcommands[$cmd] = 1;
        }
    }

    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args): bool
    {
        $this->CombatTagCommand->onCommand($sender, $cmd, $label, $args);
        return true;
    }

    public function api($plugin)
    {
        return $this->getServer()->getPluginManager()->getPlugin($plugin);
    }

    public function formatMessage($string, $confirm = false)
    {
        $success = $this->getConfig()->get("PrefixSuccess");
        $failure = $this->getConfig()->get("PrefixFailure");
        if ($confirm) {
            return str_replace('{STRING}', $string, $success);
        } else {
            return str_replace('{STRING}', $string, $failure);
        }
    }

    public function getFightTime()
    {
        return $this->getConfig()->get("FightTime");
    }

    public function getHeightLimit()
    {
        return $this->getConfig()->get("InFightBuildLimit");
    }

    public function startFight($player)
    {
        $fighttime = $this->getFightTime();
        $msg = $this->formatMessage("Jestes podczas walki! Poczekaj " . $fighttime . " sekund!", true);
        if (isset($this->infight[$player->getName()])) {
            if ((time() - $this->infight[$player->getName()]) > $fighttime) {
                $player->sendMessage($msg);
            }
        } else {
            $player->sendMessage($msg);
        }
        $this->infight[$player->getName()] = time();
    }

    public function endFight($player)
    {
        unset($this->infight[$player]);
        if (isset($this->bossbar[$player])) {
            $pk = new BossEventPacket();
            $pk->bossEid = $this->bossbar[$player];
            $pk->eventType = BossEventPacket::TYPE_HIDE;
            $this->getServer()->getPlayer($player)->sendDataPacket($pk);
        }
    }

    public function isInFight($player)
    {
        return isset($this->infight[$player]);
    }

    public function isCommandBlocked($cmd)
    {
        return isset($this->blockedcommands[$cmd]);
    }
}