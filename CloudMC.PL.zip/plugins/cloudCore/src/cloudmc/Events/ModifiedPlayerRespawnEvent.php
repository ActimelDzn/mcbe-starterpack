<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;

class ModifiedPlayerRespawnEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRespawn(PlayerRespawnEvent $event)
    {
        $player = $event->getPlayer();
        $targetLevel = $this->plugin->getServer()->getLevelByName("world");
        $event->setRespawnPosition(new Position(0, 94, 0, $targetLevel));
        $this->plugin->setNameTag($player);
    }
}