<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\level\Position;
use pocketmine\Player;

class ModifiedPlayerMoveEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param PlayerMoveEvent $event
     */

    public function onMove(PlayerMoveEvent $event)
    {
        $player = $event->getPlayer();
        $borderplus = $this->plugin->getConfig()->get("BorderPlus");
        $borderminus = $this->plugin->getConfig()->get("BorderMinus");
        if ($player->getX() >= $borderplus) {
            $player->knockBack($player, 0, -2, 0, 0.4);
            $player->addTitle("§l§cBORDER", "§7800x800");
        }
        if ($player->getZ() >= $borderplus) {
            $player->knockBack($player, 0, 0, -2, 0.4);
            $player->addTitle("§l§cBORDER", "§7800x800");
        }
        if ($player->getZ() <= $borderminus) {
            $player->knockBack($player, 0, 0, 2, 0.4);
            $player->addTitle("§l§cBORDER", "§7800x800");
        }
        if ($player->getX() <= $borderminus) {
            $player->knockBack($player, 0, 2, 0, 0.4);
            $player->addTitle("§l§cBORDER", "§7800x800");
        }
        $cloudprotect = $this->plugin->api("cloudProtect");
        $pureperms = $this->plugin->api("PurePerms");
        if ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "Swagger" or $pureperms->getUserDataMgr()->getGroup($player)->getName() == "SwaggerNaZawsze") {
            if (!$cloudprotect->canGetHurt($player) or $player->getGamemode() == 1) {
                $player->setAllowFlight(true);
            } else {
                $player->setAllowFlight(false);
                $player->setFlying(false);
            }
        }
        if (floor($event->getTo()->getX()) != floor($event->getFrom()->getX()) || floor($event->getTo()->getZ()) != floor($event->getFrom()->getZ()) || floor($event->getTo()->getY()) != floor($event->getFrom()->getY())) {
            if ($this->plugin->tpastatus[$player->getName()] == 0) {
                $this->plugin->tpastatus[$player->getName()] = 1;
                $player->addTitle("§l§7Teleportacja nieudana!", "§r");
            }
            if ($this->plugin->spawn[$player->getName()] == 0) {
                $this->plugin->spawn[$player->getName()] = 1;
                $player->addTitle("§l§7Teleportacja nieudana!", "§r");
            }
            if ($this->plugin->warp[$player->getName()] == 0) {
                $this->plugin->warp[$player->getName()] = 1;
                $player->addTitle("§l§7Teleportacja nieudana!", "§r");
            }
            if ($this->plugin->home[$player->getName()] == 0) {
                $this->plugin->home[$player->getName()] = 1;
                $player->addTitle("§l§7Teleportacja nieudana!", "§r");
            }
            if ($this->plugin->backStarted[$player->getName()] == 0) {
                $this->plugin->backStarted[$player->getName()] = 1;
                $player->addTitle("§l§7Teleportacja nieudana!", "§r");
            }
            if ($player->hasEffect(Effect::BLINDNESS)) {
                $player->removeEffect(Effect::BLINDNESS);
            }
        }
    }
}