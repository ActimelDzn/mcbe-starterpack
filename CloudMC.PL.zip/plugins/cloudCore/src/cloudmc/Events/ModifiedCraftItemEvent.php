<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\Listener;
use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\Player;

class ModifiedCraftItemEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param CraftItemEvent $event
     */

    public function onCraft(CraftItemEvent $event)
    {
        $player = $event->getPlayer();
        $result = $event->getOutputs();
        $id = array_pop($result)->getId();
        if ($id == Item::MAP or $id == Item::BOAT or $id == Item::CAULDRON or $id == Item::MINECART or $id == Item::REDSTONE_TORCH or $id == Item::FISHING_ROD or $id == Item::ITEM_FRAME) {
            $player->sendMessage($this->plugin->formatMessage("Crafting tego przedmiotu zostal zablokowany!", true));
            $event->setCancelled();
        }
    }
}
