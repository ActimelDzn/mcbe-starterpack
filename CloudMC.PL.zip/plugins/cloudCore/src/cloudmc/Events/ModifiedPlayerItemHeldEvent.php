<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\Player;

class ModifiedPlayerItemHeldEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function ItemId(PlayerItemHeldEvent $event)
    {
        $player = $event->getPlayer();
        if ($player->isOp()) {
            $player->sendTip("§l§b" . $event->getItem()->getId() . "§7:§b" . $event->getItem()->getDamage());
        }
    }
}
