<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\Player;

class ModifiedPlayerItemConsumeEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onConsume(PlayerItemConsumeEvent $event)
    {
        $player = $event->getPlayer();
        $item = $event->getItem();
        if ($item->getId() == Item::GOLDEN_APPLE) {
            $this->plugin->addGoldenApple($player->getName(), 1);
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20 * 5, 3));
        }
        if ($item->getId() == Item::ENCHANTED_GOLDEN_APPLE) {
            $this->plugin->addEnchantedGoldenApple($player->getName(), 1);
            if ($player->hasEffect(Effect::ABSORPTION)) {
                $player->removeEffect(Effect::ABSORPTION);
                $player->addEffect(new EffectInstance(Effect::getEffect(Effect::ABSORPTION), 20 * 60 * 2, 4));
            }
        }
    }
}
