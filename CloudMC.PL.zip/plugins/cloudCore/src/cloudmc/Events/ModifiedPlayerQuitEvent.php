<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Player;

class ModifiedPlayerQuitEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param PlayerQuitEvent $event
     */

    public function onQuit(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer();
        unset($this->plugin->enderchest[$player->getName()]);
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
            if (isset($this->tpa[$p->getName()])) {
                if ($this->plugin->tpa[$p->getName()] == $player->getName()) {
                    unset($this->plugin->tpa[$p->getName()]);
                }
            }
        }
    }
}
