<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\network\mcpe\protocol\ContainerClosePacket;
use pocketmine\Player;

class ModifiedDataPacketReceiveEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param DataPacketReceiveEvent $event
     * @priority NORMAL
     * @ignoreCancelled true
     */

    public function onDataPacketReceive(DataPacketReceiveEvent $event) : void{
        if($event->getPacket() instanceof ContainerClosePacket){
            $this->plugin->cancel_send = false;
            $event->getPlayer()->sendDataPacket($event->getPacket(), false, true);
            $this->plugin->cancel_send = true;
        }
    }
}