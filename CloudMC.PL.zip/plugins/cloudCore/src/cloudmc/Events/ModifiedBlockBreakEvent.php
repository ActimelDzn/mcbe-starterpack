<?php

namespace cloudmc\Events;

use cloudmc\Main;
use cloudmc\Tasks\StoneTask;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\NamedTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class ModifiedBlockBreakEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param BlockBreakEvent $event
     */

    public function onBreak(BlockBreakEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        if ($block->getId() == Block::DIAMOND_ORE or $block->getID() == Block::GOLD_ORE or $block->getId() == Block::IRON_ORE or $block->getId() == Block::COAL_ORE or $block->getId() == Block::EMERALD_ORE or $block->getId() == Block::LAPIS_ORE or $block->getId() == Block::REDSTONE_ORE) {
            $event->setDrops([Item::get(Item::AIR, 0, 0)]);
            $event->setXpDropAmount(0);
        }

        if ($event->getBlock()->getId() == Block::ENDER_CHEST) {
            if ($player->getGamemode() == 0) {
                $event->setDrops([Item::get(Item::ENDER_CHEST, 0, 1)]);
            }
        }

        $borderplus = $this->plugin->getConfig()->get("BorderPlus");
        $borderminus = $this->plugin->getConfig()->get("BorderMinus");
        if ($block->getX() >= $borderplus or $block->getZ() >= $borderplus or $block->getZ() <= $borderminus or $block->getX() <= $borderminus) {
            $event->setCancelled();
        }

        if (!$event->isCancelled()) {
            $cloudprotect = $this->plugin->api("cloudProtect");
            $item = $player->getInventory()->getItemInHand();
            $task = new StoneTask($this->plugin, new Position($block->getX(), $block->getY(), $block->getZ()));
            if ($block->getId() == Block::STONE) {
                if ($this->plugin->isFarm($block->getX(), $block->getY(), $block->getZ())) {
                    if ($item->getId() != Item::GOLDEN_PICKAXE or !$cloudprotect->canEdit($player, $block)) {
                        if ($this->plugin->getFarmType($block->getX(), $block->getY(), $block->getZ()) == 1) {
                            $this->plugin->getScheduler()->scheduleDelayedTask($task, 20 * 2);
                        } elseif ($this->plugin->getFarmType($block->getX(), $block->getY(), $block->getZ()) == 2) {
                            $this->plugin->getScheduler()->scheduleDelayedTask($task, 20);
                        } elseif ($this->plugin->getFarmType($block->getX(), $block->getY(), $block->getZ()) == 3) {
                            $this->plugin->getScheduler()->scheduleDelayedTask($task, 10);
                        }
                        $event->setDrops([Item::get(Item::AIR, 0, 1)]);
                    } else {
                        if ($this->plugin->getFarmType($block->getX(), $block->getY(), $block->getZ()) == 1) {
                            $item = Item::get(Item::END_STONE, 0, 1);
                            $nbt = ($item->getNamedTag() ?? new CompoundTag());
                            $nbt->setTag(new StringTag("stonefarm", "1"));
                            $item->setNamedTag($nbt);
                            $item->setCustomName("§l§8» §7§lNormalna §bStoniarka");
                            $item->setLore(["§8>§7> §l§fCzas odnowienia: 2s"]);
                            $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                            $this->plugin->deleteFarm($block->getX(), $block->getY(), $block->getZ());
                        } elseif ($this->plugin->getFarmType($block->getX(), $block->getY(), $block->getZ()) == 2) {
                            $item = Item::get(Item::END_STONE, 0, 1);
                            $nbt = ($item->getNamedTag() ?? new CompoundTag());
                            $nbt->setTag(new StringTag("stonefarm", "2"));
                            $item->setNamedTag($nbt);
                            $item->setCustomName("§l§8» §7§lSzybka §bStoniarka");
                            $item->setLore(["§8>§7> §l§fCzas odnowienia: 1s"]);
                            $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                            $this->plugin->deleteFarm($block->getX(), $block->getY(), $block->getZ());
                        } elseif ($this->plugin->getFarmType($block->getX(), $block->getY(), $block->getZ()) == 3) {
                            $item = Item::get(Item::END_STONE, 0, 1);
                            $nbt = ($item->getNamedTag() ?? new CompoundTag());
                            $nbt->setTag(new StringTag("stonefarm", "3"));
                            $item->setNamedTag($nbt);
                            $item->setCustomName("§l§8» §7§lSuperszybka §bStoniarka");
                            $item->setLore(["§8>§7> §l§fCzas odnowienia: 0,5s"]);
                            $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                            $this->plugin->deleteFarm($block->getX(), $block->getY(), $block->getZ());
                        }
                    }
                }
            }
        }
        $noturbo = explode(",", $this->plugin->getConfig()->get("NoTurbo"));
        $noturbo = mt_rand($noturbo[0], $noturbo[1]);
        $turbo = explode(",", $this->plugin->getConfig()->get("Turbo"));
        $turbo = mt_rand($turbo[0], $turbo[1]);
        $cloudprotect = $this->plugin->api("cloudProtect");
        if (!$event->isCancelled()) {
            if ($player->getGamemode() == 0) {
                if ($block->getId() == Block::STONE) {
                    if ($cloudprotect->canEdit($player, $block) or $player->getLevel()->getBlock(new Vector3($block->getX(), $block->getY() - 1, $block->getZ()))->getId() == 121) {
                        if ($this->plugin->isPickaxe($player->getInventory()->getItemInHand())) {
                            if ($this->plugin->hasTurbo($player->getName())) {
                                $count = explode(",", $this->plugin->getConfig()->get("ItemsCountTurbo"));
                                $count = rand($count[0], $count[1]);
                                switch ($turbo) {
                                    case 1:
                                        if ($this->plugin->getDropStatus($player->getName(), "gold") == 0) {
                                            $player->sendTip("§8[§a+§8] §eZloto §8(§e" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(266, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(266, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(266, 0, $count));
                                            }
                                        }
                                        break;
                                    case 2:
                                        if ($this->plugin->getDropStatus($player->getName(), "diamond") == 0) {
                                            $player->sendTip("§8[§a+§8] §bDiament §8(§b" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(264, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(264, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(264, 0, $count));
                                            }
                                        }
                                        break;
                                    case 3:
                                        if ($this->plugin->getDropStatus($player->getName(), "emerald") == 0) {
                                            $player->sendTip("§8[§a+§8] §aEmerald §8(§a" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(388, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(388, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(388, 0, $count));
                                            }
                                        }
                                        break;
                                    case 4:
                                        if ($this->plugin->getDropStatus($player->getName(), "iron") == 0) {
                                            $player->sendTip("§8[§a+§8] §fZelazo §8(§f" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(265, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(265, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(265, 0, $count));
                                            }
                                        }
                                        break;
                                    case 5:
                                        if ($this->plugin->getDropStatus($player->getName(), "obsidian") == 0) {
                                            $player->sendTip("§8[§a+§8] §dObsydian §8(§d" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(49, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(49, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(49, 0, $count));
                                            }
                                        }
                                        break;
                                    case 6:
                                        if ($this->plugin->getDropStatus($player->getName(), "bookshelf") == 0) {
                                            $player->sendTip("§8[§a+§8] §6Bookshelf §8(§6" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(47, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(47, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(47, 0, $count));
                                            }
                                        }
                                        break;
                                    case 7:
                                        if ($this->plugin->getDropStatus($player->getName(), "coal") == 0) {
                                            $player->sendTip("§8[§a+§8] §0Wegiel §8(§0" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(263, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(263, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(263, 0, $count));
                                            }
                                        }
                                        break;
                                    case 8:
                                        if ($this->plugin->getDropStatus($player->getName(), "redstone") == 0) {
                                            $player->sendTip("§8[§c+§8] §cRedstone §8(§c" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(331, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(331, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(331, 0, $count));
                                            }
                                        }
                                        break;
                                    case 9:
                                        if ($this->plugin->getDropStatus($player->getName(), "apple") == 0) {
                                            $player->sendTip("§8[§c+§8] §cJablko §8(§c" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(260, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(260, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(260, 0, $count));
                                            }
                                        }
                                        break;
                                    case 10:
                                        if ($this->plugin->getDropStatus($player->getName(), "pearl") == 0) {
                                            $player->sendTip("§8[§0+§8] §0Perly §8(§0" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(368, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(368, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(368, 0, $count));
                                            }
                                        }
                                        break;
                                }
                                if ($this->plugin->getDropStatus($player->getName(), "xp") == 0) {
                                    $amount = $this->plugin->getConfig()->get("XpAmountPerBlockTurbo");
                                    $player->addXp($amount);
                                }
                            } else {
                                $count = explode(",", $this->plugin->getConfig()->get("ItemsCountNoTurbo"));
                                $count = rand($count[0], $count[1]);
                                switch ($noturbo) {
                                    case 1:
                                        if ($this->plugin->getDropStatus($player->getName(), "gold") == 0) {
                                            $player->sendTip("§8[§a+§8] §eZloto §8(§e" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(266, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(266, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(266, 0, $count));
                                            }
                                        }
                                        break;
                                    case 2:
                                        if ($this->plugin->getDropStatus($player->getName(), "diamond") == 0) {
                                            $player->sendTip("§8[§a+§8] §bDiament §8(§b" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(264, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(264, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(264, 0, $count));
                                            }
                                        }
                                        break;
                                    case 3:
                                        if ($this->plugin->getDropStatus($player->getName(), "emerald") == 0) {
                                            $player->sendTip("§8[§a+§8] §aEmerald §8(§a" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(388, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(388, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(388, 0, $count));
                                            }
                                        }
                                        break;
                                    case 4:
                                        if ($this->plugin->getDropStatus($player->getName(), "iron") == 0) {
                                            $player->sendTip("§8[§a+§8] §fZelazo §8(§f" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(265, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(265, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(265, 0, $count));
                                            }
                                        }
                                        break;
                                    case 5:
                                        if ($this->plugin->getDropStatus($player->getName(), "obsidian") == 0) {
                                            $player->sendTip("§8[§a+§8] §dObsydian §8(§d" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(49, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(49, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(49, 0, $count));
                                            }
                                        }
                                        break;
                                    case 6:
                                        if ($this->plugin->getDropStatus($player->getName(), "bookshelf") == 0) {
                                            $player->sendTip("§8[§a+§8] §6Bookshelf §8(§6" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(47, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(47, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(47, 0, $count));
                                            }
                                        }
                                        break;
                                    case 7:
                                        if ($this->plugin->getDropStatus($player->getName(), "coal") == 0) {
                                            $player->sendTip("§8[§a+§8] §0Wegiel §8(§0" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(263, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(263, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(263, 0, $count));
                                            }
                                        }
                                        break;
                                    case 8:
                                        if ($this->plugin->getDropStatus($player->getName(), "redstone") == 0) {
                                            $player->sendTip("§8[§c+§8] §cRedstone §8(§c" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(331, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(331, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(331, 0, $count));
                                            }
                                        }
                                        break;
                                    case 9:
                                        if ($this->plugin->getDropStatus($player->getName(), "apple") == 0) {
                                            $player->sendTip("§8[§c+§8] §cJablko §8(§c" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(260, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(260, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(260, 0, $count));
                                            }
                                        }
                                        break;
                                    case 10:
                                        if ($this->plugin->getDropStatus($player->getName(), "pearl") == 0) {
                                            $player->sendTip("§8[§0+§8] §0Perly §8(§0" . $count . "§8)");
                                            if ($player->getInventory()->canAddItem(Item::get(368, 0, $count))) {
                                                $player->getInventory()->addItem(Item::get(368, 0, $count));
                                            } else {
                                                $block->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), Item::get(368, 0, $count));
                                            }
                                        }
                                        break;
                                }
                                if ($this->plugin->getDropStatus($player->getName(), "xp") == 0) {
                                    $amount = $this->plugin->getConfig()->get("XpAmountPerBlockNoTurbo");
                                    $player->addXp($amount);
                                }
                            }
                            if ($block->getId() == BLOCK::STONE or $block->getId() == BLOCK::COBBLESTONE) {
                                $event->setDrops(array(Item::get(0, 0, 0)));
                                if ($this->plugin->getDropStatus($player->getName(), "cobblestone") == 0) {
                                    $player->getInventory()->addItem(Item::get(4, 0, 1));
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
