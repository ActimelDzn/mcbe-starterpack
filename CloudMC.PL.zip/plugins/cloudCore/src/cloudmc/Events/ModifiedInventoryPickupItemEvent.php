<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\Listener;
use pocketmine\Player;

class ModifiedInventoryPickupItemEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param InventoryPickupItemEvent $event
     */

    public function onPickup(InventoryPickupItemEvent $event)
    {
        $player = $event->getInventory()->getHolder();
        if ($this->plugin->getVanish($player) == 0) {
            $event->setCancelled();
        }
    }
}