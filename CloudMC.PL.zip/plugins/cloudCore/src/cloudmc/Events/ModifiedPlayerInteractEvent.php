<?php

namespace cloudmc\Events;

use cloudmc\Main;
use cloudmc\GUIListeners\AnvilListener;
use cloudmc\GUIListeners\EnchantmentListener;
use pocketmine\block\Block;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Armor;
use pocketmine\item\Axe;
use pocketmine\item\Hoe;
use pocketmine\item\Item;
use pocketmine\item\Pickaxe;
use pocketmine\item\Shovel;
use pocketmine\item\Sword;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;

class ModifiedPlayerInteractEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param PlayerInteractEvent $event
     */
    public function onInteract(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $item = $event->getItem();
        $randX = rand(-799, 799);
        $randY = rand(65, 80);
        $randZ = rand(-799, 799);
        if ($block->getId() == Block::SPONGE) {
            if ($this->plugin->isOnPlate($player)) {
                if ($player->getPosition()->distance($player->getLevel()->getSafeSpawn()) < 250) {
                    foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                        if ($this->plugin->isOnPlate($p)) {
                            #if ($p->getPosition()->distance($player) <= $this->plugin->getConfig()->get("maxGroupTeleportCheckPlateDistance")) {
                                $position = new Vector3($randX, $randY, $randZ);
                                if ($position->distance($block) > 200) {
                                    $p->teleport($player->getLevel()->getSafeSpawn($position));
                                    $p->sendMessage($this->plugin->formatMessage("Przeteleportowano GRUPOWO na losowe kordy! (X: " . $randX . ", Y: " . $randY . ", Z: " . $randZ . ", Dystans od spawnu: " . floor($p->distance($block)) . ")", true));
                                } else {
                                    $player->sendMessage($this->plugin->formatMessage("Wybrana losowa pozycja jest zbyt blisko spawnu! Sprobuj ponownie!", false));
                                }
                            }
                        }
                    }
            } else {
                $position = new Vector3($randX, $randY, $randZ);
                if ($position->distance($block) > 200) {
                    $player->teleport($player->getLevel()->getSafeSpawn($position));
                    $player->sendMessage($this->plugin->formatMessage("Przeteleportowano na losowe kordy! (X: " . $randX . ", Y: " . $randY . ", Z: " . $randZ . ", Dystans od spawnu: " . floor($player->distance($block)) . ")", true));
                } else {
                    $player->sendMessage($this->plugin->formatMessage("Wybrana losowa pozycja jest zbyt blisko spawnu! Sprobuj ponownie!", false));
                }
            }
        }
                    if ($event->getAction() == PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                        if ($block->getId() == Block::BED_BLOCK or $block->getId() == Block::SHULKER_BOX or $block->getId() == Block::ANVIL) {
                            $event->setCancelled();
                        }
                        if ($block->getId() == Block::CHEST or $block->getId() == Block::TRAPPED_CHEST) {
                            if ($this->plugin->getVanish($player) == 0) {
                                $event->setCancelled();
                                $this->plugin->openChestInventory($player, $block->getX(), $block->getY(), $block->getZ());
                            }
                        }
                        if ($block->getId() == Block::ANVIL) {
                            $event->setCancelled();
                            $gui = new AnvilListener($this->plugin, "§l§bKowadlo");
                            $gui->addContents($player);
                            $gui->sendTo($player);
                        }
                        if ($block->getId() == Block::HOPPER_BLOCK) {
                            $event->setCancelled();
                        }
                        if ($block->getId() == Block::ENCHANTING_TABLE) {
                            $event->setCancelled();
                            $item = $player->getInventory()->getItemInHand();
                            if ($item instanceof Pickaxe or $item instanceof Axe or $item instanceof Hoe or $item instanceof Shovel or $item instanceof Sword or $item instanceof Armor) {
                                $gui = new EnchantmentListener($this->plugin, "§l§bEnchant", $block->asVector3());
                                if ($item instanceof Pickaxe or $item instanceof Axe or $item instanceof Hoe or $item instanceof Shovel) {
                                    $gui->addToolsEnchantments();
                                } elseif ($item instanceof Sword) {
                                    $gui->addWeaponsEnchantments();
                                } elseif ($item instanceof Armor) {
                                    $gui->addArmorEnchantments();
                                }
                                $gui->sendTo($player);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Nie mozesz zenchantowac tego przedmiotu!", false));
                            }
                        }
                    }
                    if ($event->getAction() == PlayerInteractEvent::RIGHT_CLICK_AIR) {
                        if ($player->getInventory()->getItemInHand()->getId() == Item::ENDER_PEARL) {
                            if (isset($this->plugin->pearl[$player->getName()])) {
                                if (microtime(true) - $this->plugin->pearl[$player->getName()] <= $this->plugin->getConfig()->get("EnderPearlCooldown")) {
                                    $event->setCancelled();
                                    $time = round($this->plugin->getConfig()->get("EnderPearlCooldown") - (microtime(true) - $this->plugin->pearl[$player->getName()]), 2);
                                    $player->sendPopup("§7§lPerla: §b" . $time . "s");
                                } else {
                                    $this->plugin->pearl[$player->getName()] = time();
                                    $this->plugin->addEnderPearl($player->getName(), 1);
                                }
                            } else {
                                $this->plugin->pearl[$player->getName()] = time();
                            }
                        }
                    }
                }
            }
