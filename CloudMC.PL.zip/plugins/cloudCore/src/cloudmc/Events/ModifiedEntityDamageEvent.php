<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\Player;

class ModifiedEntityDamageEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onDamage(EntityDamageEvent $event)
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if ($damager instanceof Player && $entity instanceof Player) {
                if ($this->plugin->getFly($damager) == 0 or $this->plugin->getGod($damager) == 0) {
                    $event->setCancelled();
                }
            }
        }
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            $player = $event->getEntity();
            if ($player instanceof Player && $damager instanceof Player) {
                foreach ([$damager, $player] as $player) {
                    $this->plugin->checkLimit($player);
                }
            }
        }
        $entity = $event->getEntity();
        if ($entity instanceof Player) {
            if ($this->plugin->getGod($entity) == 0) {
                $event->setCancelled();
            }
        }
    }
}

