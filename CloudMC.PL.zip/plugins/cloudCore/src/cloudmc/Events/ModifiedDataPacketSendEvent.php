<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\network\mcpe\protocol\PlayerListPacket;
use pocketmine\network\mcpe\protocol\ContainerClosePacket;
use pocketmine\Player;

class ModifiedDataPacketSendEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param DataPacketSendEvent $event
     * @priority NORMAL
     * @ignoreCancelled true
     */

    public function onDataPacketSend(DataPacketSendEvent $event): void
    {
        if ($event->getPacket() instanceof AvailableCommandsPacket) {
            $event->setCancelled(true);
        }
        if ($this->plugin->cancel_send && $event->getPacket() instanceof ContainerClosePacket) {
            $event->setCancelled();
        }
    }
}