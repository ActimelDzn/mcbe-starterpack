<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\block\Block;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\NamedTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\entity\Entity;

class ModifiedBlockPlaceEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param BlockPlaceEvent $event
     */
    public function onPlace(BlockPlaceEvent $event)
    {
        $block = $event->getBlock();
        $player = $event->getPlayer();
        $y = $block->getFloorY();
        $x = $block->getFloorX();
        $z = $block->getFloorZ();
        $borderplus = $this->plugin->getConfig()->get("BorderPlus");
        $borderminus = $this->plugin->getConfig()->get("BorderMinus");
        if ($block->getX() >= $borderplus or $block->getZ() >= $borderplus or $block->getZ() <= $borderminus or $block->getX() <= $borderminus) {
            $event->setCancelled();
        }
        if ($block->getId() == Block::MOB_SPAWNER) {
            $event->setCancelled();
            if ($this->plugin->api("cloudGuilds")->isInPlot($block->getX(), $block->getZ())) {
                $nbt = Entity::createBaseNBT(new Vector3($block->getX(), $block->getY(), $block->getZ()), null, $player->getYaw(), $player->getPitch());
                $entity = Entity::createEntity("PrimedTNT", $player->getLevel(), $nbt);
                $entity->spawnToAll();
                $item = $player->getInventory()->getItemInHand();
                $item->setCount($item->getCount() - 1);
                $player->getInventory()->setItemInHand($item);
            } else {
                $player->sendMessage($this->plugin->formatMessage("Rzucane TNT mozesz postawic tylko na terenie gildii!", false));
            }
        }
        if ($block->getY() > 50 && $block->getId() == Block::TNT) {
            $event->setCancelled();
            $event->getPlayer()->sendMessage($this->plugin->formatMessage("TNT mozesz stawiac ponizej Y:50!", false));
        }
        if (!$this->plugin->api("cloudGuilds")->isInFaction($player->getName()) && $block->getId() == Block::TNT) {
            $event->setCancelled();
            $event->getPlayer()->sendMessage($this->plugin->formatMessage("Musisz byc w gildii, aby postawic TNT!", false));
        }
        if ($this->plugin->isPremiumCase($player->getInventory()->getItemInHand())) {
            $event->setCancelled();
            $item = $player->getInventory()->getItemInHand();
            $item->setCount($item->getCount() - 1);
            $player->getInventory()->setItemInHand($item);
            $this->plugin->addPc($player->getName(), 1);
            $player->sendMessage("§b" . $player->getName() . " §7otworzyl §b§lPREMIUMCASE§r §7i wylosowal:");
            switch (mt_rand(1, 14)) {
                case 1:
                    $rand = mt_rand(8, 16);
                    $item = Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r §7Koxy (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 2:
                    $rand = mt_rand(8, 16);
                    $item = Item::get(Item::GOLDEN_APPLE, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r §7Refile (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 3:
                    $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 5));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_ASPECT), 2));
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- Miecz §l§bMiecz 5/2§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 4:
                    $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 5));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::KNOCKBACK), 2));
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- Miecz §l§bKNOCK 2§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 5:
                    $item = Item::get(Item::DIAMOND_HELMET, 0, 1);
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- Helm §l§b4/3§r§7 (+0.10$)");
                    break;
                case 6:
                    $item = Item::get(Item:: DIAMOND_CHESTPLATE, 0, 1);
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- Klata §b§l4/3§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 7:
                    $item = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- Spodnie §b§l4/3§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 8:
                    $item = Item::get(Item::DIAMOND_BOOTS, 0, 1);
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- Buty §b§l4/3§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 9:
                    $rand = mt_rand(128, 256);
                    $item = Item::get(Item::EMERALD, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r§l §7Emeraldow§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 10:
                    $rand = mt_rand(128, 256);
                    $item = Item::get(Item::DIAMOND, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r §l§7Diamentow§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 11:
                    $rand = mt_rand(128, 256);
                    $item = Item::get(Item::GOLD_INGOT, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r §7§lZlota§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 12:
                    $rand = mt_rand(128, 256);
                    $item = Item::get(Item::IRON_INGOT, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r §7§lZelaza§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 13:
                    $rand = mt_rand(8, 16);
                    $item = Item::get(Item::ENDER_PEARL, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r §7§lEnderPerly§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
                case 14:
                    $rand = mt_rand(32, 64);
                    $item = Item::get(Item::TNT, 0, $rand);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l" . $rand . "§r §l§7TNT§r§7 (+0.10$)");
                    $this->plugin->addMoney($player->getName(), 0.10);
                    break;
            }
            switch (mt_rand(1, 300)) {
                case 1:
                    $item = Item::get(Item::BEACON, 0, 1);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l1§r §l§7Beacon§r§7 (+1.00$)");
                    $this->plugin->addMoney($player->getName(), 1.00);
                    $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("§r§7Gracz §b" . $player->getName() . " §r§7wylosowal z premium case: §bBEACON"));
                    break;
                case 2:
                    $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 6));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FORTUNE), 3));
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- Kilof §l§b6/3/3§r§7 (+1.00$)");
                    $this->plugin->addMoney($player->getName(), 1.00);
                    $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("§r§7Gracz §b" . $player->getName() . " §r§7wylosowal z premium case: §bKILOF 6/3/3"));
                    break;
                case 3:
                    $item = Item::get(Item::MONSTER_SPAWNER, 0, 1);
                    $player->getLevel()->dropItem(new Vector3($block->getX(), $block->getY(), $block->getZ()), $item);
                    $player->sendMessage("§7- §b§l1§r §7Rzucak§r§7 (+1.00$)");
                    $this->plugin->addMoney($player->getName(), 1.00);
                    $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("§r§7Gracz §b" . $player->getName() . " §r§7wylosowal z premium case: §bRZUCAK"));
                    break;
            }
        }
        $item = $player->getInventory()->getItemInHand();
        if ($this->plugin->isBlockStoneFarm($item)) {
            if (!$event->isCancelled()) {
                $item2 = $event->getItem();
                $item2->setCount($item2->getCount() - 1);
                $player->getInventory()->setItemInHand($item2);
                $event->setCancelled();
                $player->getLevel()->setBlock(new Vector3($block->getX(), $block->getY(), $block->getZ()), Block::get(Block::STONE, 0));
                if ($this->plugin->getStoneFarmTypeItem($item) == "1") {
                    $this->plugin->createFarm($block->getX(), $block->getY(), $block->getZ(), 1);
                } elseif ($this->plugin->getStoneFarmTypeItem($item) == "2") {
                    $this->plugin->createFarm($block->getX(), $block->getY(), $block->getZ(), 2);
                } elseif ($this->plugin->getStoneFarmTypeItem($item) == "3") {
                    $this->plugin->createFarm($block->getX(), $block->getY(), $block->getZ(), 3);
                }
            }
        }
    }
}