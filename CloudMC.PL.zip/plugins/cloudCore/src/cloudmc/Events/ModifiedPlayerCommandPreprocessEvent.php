<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;

class ModifiedPlayerCommandPreprocessEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onPlayerCommandPreprocess(PlayerCommandPreprocessEvent $event){
        $player = $event->getPlayer();
        $message = $event->getMessage();
        $this->plugin->getLogger()->notice($player->getName().": ".$message);
        if(!isset($this->plugin->cooldown[$player->getName()])){
            if($message[0] == "/"){
                $this->plugin->cooldown[$player->getName()] = time();
            }
        }
        else{
            if(time() - $this->plugin->cooldown[$player->getName()] <= 3){
                if($message[0] == "/"){
                    $player->sendMessage($this->plugin->formatMessage("Komend mozesz uzywac co 3 sekundy!", false));
                    $event->setCancelled();
                    return true;
                }
            } else{
                $this->plugin->cooldown[$player->getName()] = time();
            }
        }
    }
}