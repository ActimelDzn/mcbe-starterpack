<?php

namespace cloudmc\Events;

use cloudmc\Main;
use cloudmc\GUIListeners\EnderChestListener;
use pocketmine\event\inventory\InventoryOpenEvent;
use pocketmine\event\Listener;
use pocketmine\inventory\EnderChestInventory;
use pocketmine\Player;

class ModifiedInventoryOpenEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param InventoryOpenEvent $event
     */

    public function onInventoryOpen(InventoryOpenEvent $event)
    {
        $player = $event->getPlayer();
        if ($event->getInventory() instanceof EnderChestInventory) {
            $event->setCancelled();
            if (!isset($this->plugin->enderchest[$player->getName()]) or $this->plugin->enderchest[$player->getName()] == 0) {
                $gui = new EnderChestListener($this->plugin, $player, "§l§bEnderchest");
                $gui->addContents($player);
                $gui->sendTo($player);
                $this->plugin->enderchest[$player->getName()] = 1;
            }
        }
    }
}