<?php

namespace cloudmc\Events;

use _64FF00\PurePerms\PurePerms;
use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\Player;

class ModifiedPlayerChatEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param PlayerChatEvent $event
     */

    public function onModifiedPlayerChatEvent(PlayerChatEvent $event)
    {
        $player = $event->getPlayer();
        if (!$event->isCancelled()) {
            if ($this->plugin->getChatStatus() == 1 && !$player->hasPermission("antispam.override")) {
                $event->setCancelled();
                $player->sendMessage($this->plugin->formatMessage("Chat glowny jest aktualnie wylaczony!", false));
            }
        }
        if (!$event->isCancelled()) {
            if (isset($this->plugin->antispam[$player->getName()])) {
                if (!$player->hasPermission("antispam.override")) {
                    if (time() - $this->plugin->antispam[$player->getName()] < $this->plugin->getConfig()->get("AntiSpamCooldown")) {
                        $event->setCancelled();
                        $player->sendMessage($this->plugin->formatMessage("Nastepna wiadomosc mozesz wyslac za: " . round($this->plugin->getConfig()->get("AntiSpamCooldown") - (time() - $this->plugin->antispam[$player->getName()]), 1) . "s!", false));
                    } else {
                        $this->plugin->antispam[$player->getName()] = time();
                    }
                }
            } else {
                $this->plugin->antispam[$player->getName()] = time();
            }
            if ($this->plugin->isMuted($player->getName())) {
                $time = $this->plugin->getMuteTime($player->getName());
                $time = floor((($time) % 86400) / 3600) . "h. " . floor(((($time) % 86400) % 3600) / 60) . "min. " . floor(((($time) % 86400) % 3600) % 60) . "s.";
                $player->sendMessage($this->plugin->formatMessage("Jestes wyciszony jeszcze na: " . $time, false));
            }
            if (!$event->isCancelled()) {
                $event->setCancelled();
                $player = $event->getPlayer();
                if (!$this->plugin->isMuted($player->getName())) {
                    if ($event->getMessage()[0] != "#" && $event->getMessage()[0] != "!") {
                        foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                            $message = $event->getMessage();
                            $points = $this->plugin->getPoints($player->getName());
                            $faction = $this->plugin->getFactionAsString($player->getName(), $p->getName());
                            $name = $player->getDisplayName();
                            $group = $this->plugin->getGroupAsString($player->getName());
                            $ar = getdate();
                            $time = $ar['hours'] . ":" . $ar['minutes'] . ":" . $ar['seconds'];
                            if ($this->plugin->getGroup($player->getName()) == "Gracz") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "§f" . $name . "§r§8: §7" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "" . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Vip") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §6" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Vip] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "VipNaZawsze") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §6" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Vip] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Svip") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §9" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Svip] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "SvipNaZawsze") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §9" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Svip] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Sponsor") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §a" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Sponsor] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "SponsorNaZawsze") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §a" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Sponsor] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Swagger") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §d" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Swagger] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "SwaggerNaZawsze") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §d" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Swagger] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "ChatHelper") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §c" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[ChatHelper] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Pomocnik") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §c" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Pomocnik] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Moderator") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §c" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Moderator] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Admin") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §c" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Administrator] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            } elseif ($this->plugin->getGroup($player->getName()) == "Wlasciciel") {
                                $format = "§8[§f" . $points . "§8] " . $faction . "" . $group . " §f" . $name . "§r§8: §c" . $message;
                                $discordformat = "[" . $time . "] " . "[" . $points . "] " . $faction . "[Wlasciciel] " . $name . ": " . $message;
                                $this->plugin->getServer()->broadcastMessage($this->plugin->replacePolishChars($format));
                                $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars($discordformat));
                                return true;
                            }
                        }
                    }
                }
            }
        }
    }
}