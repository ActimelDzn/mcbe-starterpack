<?php

namespace cloudmc\Events;

use cloudmc\Main;
use muqsit\invmenu\inventories\BaseFakeInventory;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class ModifiedInventoryTransactionEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param InventoryTransactionEvent $event
     */

    public function onTransaction(InventoryTransactionEvent $event)
    {
        $transaction = $event->getTransaction();
        foreach ($transaction->getActions() as $action) {
            if ($action instanceof SlotChangeAction) {
                $inventory = $action->getInventory();
                if ($inventory instanceof BaseFakeInventory) {
                    foreach ([$action->getSourceItem(), $action->getTargetItem()] as $item) {
                        $nbt = ($item->getNamedTag() ?? new CompoundTag());
                        if ($nbt->hasTag("blocked", StringTag::class)) {
                            $event->setCancelled();
                        }
                    }
                }
            }
        }
    }
}
