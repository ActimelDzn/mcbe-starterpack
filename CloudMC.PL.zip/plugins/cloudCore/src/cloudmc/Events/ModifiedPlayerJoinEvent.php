<?php

namespace cloudmc\Events;

use cloudmc\Main;
use cloudmc\Tasks\NameTagTask;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;

class ModifiedPlayerJoinEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param PlayerJoinEvent $event
     */

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        $this->plugin->spawn[$player->getName()] = 1;
        $this->plugin->tpastatus[$player->getName()] = 1;
        $this->plugin->warp[$player->getName()] = 1;
        $this->plugin->home[$player->getName()] = 1;
        $this->plugin->backStarted[$player->getName()] = 1;
        $this->plugin->flystatus[$player->getName()] = 1;
        $this->plugin->enderchest[$player->getName()] = 0;
        $this->plugin->cooldown[$player->getName()] = 0;
        $this->plugin->logPlayer($player);
        $this->plugin->setNameTag($player);
        if (!$this->plugin->playerExists($player)) {
            $this->plugin->addPlayer($player);
        }
        if (!$this->plugin->playerExistsInColoredNames($player)) {
            $this->plugin->addPlayerToColoredNames($player);
        }
        if ($this->plugin->getFly($player) == 0 or $player->getGamemode() == 1 or $player->getGamemode() == 3) {
            $player->setAllowFlight(true);
        } else {
            $player->setAllowFlight(false);
            $player->setFlying(false);
        }
        if ($this->plugin->getVanish($player) == 0) {
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                if (!$p->hasPermission("vanish.override")) {
                    $p->hidePlayer($player);
                }
            }
        }
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
            if ($this->plugin->getVanish($p) == 0) {
                if (!$player->hasPermission("vanish.override")) {
                    $player->hidePlayer($p);
                }
            }
        }
        if ($this->plugin->hasColoredName($player)) {
            $player->setDisplayName($this->plugin->getColoredName($player));
        }
        if ($this->plugin->playerExistsInShop($player->getName()) == false) {
            $this->plugin->addPlayerToShop($player->getName());
        }
        if ($this->plugin->playerExistsInPremiumCase($player->getName()) == false) {
            $this->plugin->addPlayerToPremiumCase($player->getName());
        }
        if ($this->plugin->playerExistsInGoldenApple($player->getName()) == false) {
            $this->plugin->addPlayerToGoldenApple($player->getName());
        }
        if ($this->plugin->playerExistsInEnderPearl($player->getName()) == false) {
            $this->plugin->addPlayerToEnderPearl($player->getName());
        }
        if ($this->plugin->playerExistsInEnchantedGoldenApple($player->getName()) == false) {
            $this->plugin->addPlayerToEnchantedGoldenApple($player->getName());
        }
        if ($this->plugin->playerExistsInSpendMoney($player->getName()) == false) {
            $this->plugin->addPlayerToSpendMoney($player->getName());
        }
        if (!$this->plugin->playerExistsInEnderchest($player)) {
            $this->plugin->addPlayerToEnderchest($player);
        }
        if (!$this->plugin->playerExistsInDrop($player->getName())) {
            $this->plugin->addPlayerToDrop($player->getName());
        }
        if (!$this->plugin->playerExistsInSchowek($player->getName())) {
            $this->plugin->addPlayerToSchowek($player->getName());
        }
        if (!$player->hasPlayedBefore()) {
            $randX = rand(-250, 700);
            $randY = rand(65, 80);
            $randZ = rand(-250, 700);
            $position = new Vector3($randX, $randY, $randZ);
            $player->teleport($player->getLevel()->getSafeSpawn($position));
            $item = Item::get(Item::STONE_PICKAXE, 0, 1);
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
            $item->setCustomName("§l§bSTARTOWY KILOF");
            $player->getInventory()->addItem($item);
            $player->getInventory()->addItem(Item::get(Item::COOKED_BEEF, 0, 64));
            $player->getInventory()->addItem(Item::get(Item::ENDER_CHEST, 0, 1));
            $player->getInventory()->addItem(Item::get(Item::WOODEN_PLANKS, 0, 32));
        }
    }
}