<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;

class ModifiedPlayerDeathEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority MONITOR
     * @param PlayerDeathEvent $event
     */

    public function onDeath(PlayerDeathEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $item = Item::get(Item::MOB_HEAD, 3, 1);
        $item->setCustomName("§l§8» §7Glowa gracza:§b $name");
        $x = $player->getX();
        $y = $player->getY();
        $z = $player->getZ();
        $player->getLevel()->dropItem(new Vector3($x, $y, $z), $item);
    }
}