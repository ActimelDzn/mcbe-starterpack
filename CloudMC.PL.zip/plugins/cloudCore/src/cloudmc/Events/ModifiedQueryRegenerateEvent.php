<?php

namespace cloudmc\Events;

use cloudmc\Main;
use pocketmine\event\Listener;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\Server;

class ModifiedQueryRegenerateEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /* public function onQuery(QueryRegenerateEvent $event)
    {
        $event->setMaxPlayerCount($event->getPlayerCount() + 1);
    }*/
}