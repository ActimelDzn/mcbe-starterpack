<?php

namespace cloudmc\Events;

use cloudmc\Main;
use cloudmc\Player\CustomPlayer;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\Player;

class ModifiedPlayerCreationEvent implements Listener
{

    public $plugin;
    private $player;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerCreationEvent $event
     */

    public function onModifiedPlayerCreation(PlayerCreationEvent $event)
    {
        $event->setPlayerClass(CustomPlayer::class);
    }
}