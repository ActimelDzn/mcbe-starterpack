<?php

declare(strict_types=1);

namespace cloudmc;

use _64FF00\PurePerms\PurePerms;
use cloudmc\Blocks\Anvil;
use cloudmc\Blocks\EnchantingTable;
use cloudmc\Blocks\EnderChest;
use cloudmc\Blocks\Obsidian;
use cloudmc\Commands\AnvilCommand;
use cloudmc\Commands\BackCommand;
use cloudmc\Commands\ChatCommand;
use cloudmc\Commands\CraftingiCommand;
use cloudmc\Commands\DelHomeCommand;
use cloudmc\Commands\DropCommand;
use cloudmc\Commands\EffectsCommand;
use cloudmc\Commands\EnchantCommand;
use cloudmc\Commands\EnderchestCommand;
use cloudmc\Commands\EnderSeeCommand;
use cloudmc\Commands\FeedCommand;
use cloudmc\Commands\FlyCommand;
use cloudmc\Commands\GamemodeCommand;
use cloudmc\Commands\GodCommand;
use cloudmc\Commands\HealCommand;
use cloudmc\Commands\HomeCommand;
use cloudmc\Commands\InvseeCommand;
use cloudmc\Commands\KityCommand;
use cloudmc\Commands\LaggCommand;
use cloudmc\Commands\MoneyCommand;
use cloudmc\Commands\MuteCommand;
use cloudmc\Commands\PomocCommand;
use cloudmc\Commands\PremiumCaseCommand;
use cloudmc\Commands\PremiumInfoCommand;
use cloudmc\Commands\RangiCommand;
use cloudmc\Commands\RepairCommand;
use cloudmc\Commands\SchowekCommand;
use cloudmc\Commands\SellAllCommand;
use cloudmc\Commands\SetHomeCommand;
use cloudmc\Commands\SetyCommand;
use cloudmc\Commands\SklepCommand;
use cloudmc\Commands\SpawnCommand;
use cloudmc\Commands\SprawdzCommand;
use cloudmc\Commands\StoneFarmCommand;
use cloudmc\Commands\TopkaCommand;
use cloudmc\Commands\TpacceptCommand;
use cloudmc\Commands\TpaCommand;
use cloudmc\Commands\UslugaCommand;
use cloudmc\Commands\VanishCommand;
use cloudmc\Commands\WarpCommand;
use cloudmc\Enchantments\Knockback;
use cloudmc\Events\ModifiedBlockBreakEvent;
use cloudmc\Events\ModifiedBlockPlaceEvent;
use cloudmc\Events\ModifiedCraftItemEvent;
use cloudmc\Events\ModifiedDataPacketSendEvent;
use cloudmc\Events\ModifiedDataPacketReceiveEvent;
use cloudmc\Events\ModifiedEntityDamageEvent;
use cloudmc\Events\ModifiedInventoryOpenEvent;
use cloudmc\Events\ModifiedInventoryPickupItemEvent;
use cloudmc\Events\ModifiedInventoryTransactionEvent;
use cloudmc\Events\ModifiedPlayerChatEvent;
use cloudmc\Events\ModifiedPlayerCreationEvent;
use cloudmc\Events\ModifiedPlayerCommandPreprocessEvent;
use cloudmc\Events\ModifiedPlayerDeathEvent;
use cloudmc\Events\ModifiedPlayerInteractEvent;
use cloudmc\Events\ModifiedPlayerItemConsumeEvent;
use cloudmc\Events\ModifiedPlayerItemHeldEvent;
use cloudmc\Events\ModifiedPlayerJoinEvent;
use cloudmc\Events\ModifiedPlayerMoveEvent;
use cloudmc\Events\ModifiedPlayerQuitEvent;
use cloudmc\Events\ModifiedPlayerRespawnEvent;
use cloudmc\Events\ModifiedQueryRegenerateEvent;
use cloudmc\GUIListeners\CraftingListener;
use cloudmc\GUIListeners\EffectsListener;
use cloudmc\GUIListeners\TopsListener;
use cloudmc\GUIListeners\SchowekListener;
use cloudmc\Tasks\BroadcastTask;
use cloudmc\Tasks\LaggClearTask;
use cloudmc\Tasks\MuteTask;
use cloudmc\Tasks\StoneTask;
use cloudmc\Tasks\TimeTask;
use cloudmc\Tasks\TurboTask;
use cloudmc\Tasks\WebhookAsyncTask;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\inventory\ShapedRecipe;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\LoginPacket;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Chest;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use SQLite3;

class Main extends PluginBase
{


    /** @var float[] */
    /** @var Config */
    /** @var bool */

    private static $config;
    public $cancel_send = true;

    public $enchanted = [];
    public $golden = [];
    public $pearls = [];
    public $fillenchanted = [];
    public $fillgolden = [];
    public $fillpearls = [];
    public $tpa, $spawn, $tpastatus, $warp, $home, $pearl, $enderchest, $back, $backStarted, $lastPosition, $flystatus;
    public $db, $getX, $getY, $getZ, $getWorld;
    public $RAINBOW_COLORS = ["§r§l" . TextFormat::RED, TextFormat::GOLD, TextFormat::YELLOW, TextFormat::GREEN, TextFormat::AQUA, TextFormat::BLUE, TextFormat::LIGHT_PURPLE . "§r"];

    public function onEnable(): void
    {
        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();
        $this->saveResource("config.yml");
        self::$config = $this->getConfig()->getAll();
        $this->db = new SQLite3($this->getDataFolder() . "Files.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS admins (player TEXT PRIMARY KEY, fly INT, god INT, vanish INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS chat (chat TEXT PRIMARY KEY, status INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS colorednames (player TEXT PRIMARY KEY, displayname TEXT, status INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS farms1(x INT, y INT, z INT, type INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS farms(x INT, y INT, z INT, type INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS enderchest(player TEXT PRIMARY KEY, contents TEXT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS home (id INTEGER PRIMARY KEY AUTOINCREMENT, player TEXT, name TEXT, x INT, y INT, z INT, world TEXT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS mute (player TEXT PRIMARY KEY, timestamp INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS drops(player TEXT PRIMARY KEY, diamond INT, iron INT, gold INT, emerald INT, coal INT, redstone INT, gunpowder INT, bookshelf INT, obsidian INT, xp INT, cobblestone INT, apple INT, pearl INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS turbodrop(player TEXT PRIMARY KEY, timestamp INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS shop(player TEXT PRIMARY KEY, money INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS premiumcase(player TEXT PRIMARY KEY, pc INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS golden(player TEXT PRIMARY KEY, goldenapple INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS pearl(player TEXT PRIMARY KEY, enderpearl INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS spendmoney(player TEXT PRIMARY KEY, monety INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS enchantedgolden(player TEXT PRIMARY KEY, enchantedgoldenapple INT);");
        $result = $this->db->query("SELECT * FROM chat;");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        if (empty($array)) {
            $stmt = $this->db->prepare("INSERT OR REPLACE INTO chat (chat, status) VALUES (:chat, :status);");
            $stmt->bindValue(":chat", "chat");
            $stmt->bindValue(":status", 0);
            $result = $stmt->execute();
        }
        $this->registerBlocks();
        $this->registerEnchantments();
        $this->registerEvents();
        $this->registerCommands();
        $this->registerRecipes();
        $this->registerTasks();
        #$this->registerDatabase();
        $this->registerInventoryMenu();
        $this->loadFarms();
        $this->unregisterCommands();
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Plugin zostal wlaczony.");
    }

    public function onDisable(): void
    {
        $this->getLogger()->info(TextFormat::DARK_RED . "Plugin zostal wylaczony.");
        $this->db->close();
    }

    public function registerBlocks()
    {
        $i = 0;
        BlockFactory::registerBlock(new Obsidian(), true);
        $i++;
        BlockFactory::registerBlock(new EnderChest(), true);
        $i++;
        BlockFactory::registerBlock(new EnchantingTable(), true);
        $i++;
        BlockFactory::registerBlock(new Anvil(), true);
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") bloki pomyslnie.");
    }

    public function registerEnchantments()
    {
        $i = 0;
        Enchantment::registerEnchantment(new Knockback(Enchantment::KNOCKBACK, "Knockback", Enchantment::RARITY_UNCOMMON, Enchantment::SLOT_SWORD, Enchantment::SLOT_NONE, 2));
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") enchant pomyslnie.");
    }

    public function registerEvents()
    {
        $i = 0;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedBlockBreakEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedBlockPlaceEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedCraftItemEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerCommandPreprocessEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedDataPacketSendEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedDataPacketReceiveEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedEntityDamageEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedInventoryOpenEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedInventoryPickupItemEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedInventoryTransactionEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerChatEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerCreationEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerDeathEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerItemConsumeEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerInteractEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerItemHeldEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerRespawnEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerJoinEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerMoveEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedPlayerQuitEvent($this), $this);
        $i++;
        $this->getServer()->getPluginManager()->registerEvents(new ModifiedQueryRegenerateEvent($this), $this);
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") eventow pomyslnie.");
    }

    public function unregisterCommands()
    {
        $i = 0;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("ban"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("banlist"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("enchant"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("me"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("say"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("reload"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("op"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("version"));
        $i++;
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("plugins"));
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Wylaczono (" . $i . ") domyslnych komend pomyslnie.");
    }

    public function registerCommands()
    {
        $i = 0;
        $this->getServer()->getCommandMap()->register("anvil", new AnvilCommand($this, "anvil"));
        $i++;
        $this->getServer()->getCommandMap()->register("chat", new ChatCommand($this, "chat"));
        $i++;
        $this->getServer()->getCommandMap()->register("craftingi", new CraftingiCommand($this, "craftingi"));
        $i++;
        #$this->getServer()->getCommandMap()->register("delhome", new DelHomeCommand($this, "delhome"));
        #++;
        $this->getServer()->getCommandMap()->register("drop", new DropCommand($this, "drop"));
        $i++;
        $this->getServer()->getCommandMap()->register("efekty", new EffectsCommand($this, "efekty"));
        $i++;
        $this->getServer()->getCommandMap()->register("endersee", new EnderSeeCommand($this, "endersee"));
        $i++;
        $this->getServer()->getCommandMap()->register("enderchest", new EnderchestCommand($this, "enderchest"));
        $i++;
        $this->getServer()->getCommandMap()->register("feed", new FeedCommand($this, "feed"));
        $i++;
        $this->getServer()->getCommandMap()->register("fly", new FlyCommand($this, "fly"));
        $i++;
        $this->getServer()->getCommandMap()->register("god", new GodCommand($this, "god"));
        $i++;
        $this->getServer()->getCommandMap()->register("cgm", new GamemodeCommand($this, "cgm"));
        $i++;
        $this->getServer()->getCommandMap()->register("heal", new HealCommand($this, "heal"));
        $i++;
        $this->getServer()->getCommandMap()->register("home", new HomeCommand($this, "home"));
        $i++;
        $this->getServer()->getCommandMap()->register("invsee", new InvseeCommand($this, "invsee"));
        $i++;
        $this->getServer()->getCommandMap()->register("lagg", new LaggCommand($this, "lagg"));
        $i++;
        $this->getServer()->getCommandMap()->register("mute", new MuteCommand($this, "mute"));
        $i++;
        $this->getServer()->getCommandMap()->register("monety", new MoneyCommand($this, "monety"));
        $i++;
        $this->getServer()->getCommandMap()->register("pomoc", new PomocCommand($this, "pomoc"));
        $i++;
        $this->getServer()->getCommandMap()->register("pc", new PremiumCaseCommand($this, "pc"));
        $i++;
        $this->getServer()->getCommandMap()->register("rangi", new RangiCommand($this, "rangi"));
        $i++;
        $this->getServer()->getCommandMap()->register("repair", new RepairCommand($this, "repair"));
        $i++;
        $this->getServer()->getCommandMap()->register("schowek", new SchowekCommand($this, "schowek"));
        $i++;
        $this->getServer()->getCommandMap()->register("sellall", new SellAllCommand($this, "sellall"));
        $i++;
        $this->getServer()->getCommandMap()->register("sethome", new SetHomeCommand($this, "sethome"));
        $i++;
        $this->getServer()->getCommandMap()->register("sety", new SetyCommand($this, "sety"));
        $i++;
        $this->getServer()->getCommandMap()->register("sklep", new SklepCommand($this, "sklep"));
        $i++;
        $this->getServer()->getCommandMap()->register("spawn", new SpawnCommand($this, "spawn"));
        $i++;
        $this->getServer()->getCommandMap()->register("sprawdz", new SprawdzCommand($this, "sprawdz"));
        $i++;
        $this->getServer()->getCommandMap()->register("stonefarm", new StoneFarmCommand($this, "stonefarm"));
        $i++;
        $this->getServer()->getCommandMap()->register("topka", new TopkaCommand($this, "topka"));
        $i++;
        $this->getServer()->getCommandMap()->register("tpaccept", new TpacceptCommand($this, "tpaccept"));
        $i++;
        $this->getServer()->getCommandMap()->register("tpa", new TpaCommand($this, "tpa"));
        $i++;
        $this->getServer()->getCommandMap()->register("usluga", new UslugaCommand($this, "usluga"));
        $i++;
        $this->getServer()->getCommandMap()->register("vanish", new VanishCommand($this, "vanish"));
        $i++;
        $this->getServer()->getCommandMap()->register("warp", new WarpCommand($this, "warp"));
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") komend pomyslnie.");
    }

    public function registerRecipes()
    {
        $i = 0;
        $enchantedgoldenapple = new ShapedRecipe(
            ["aaa", "axa", "aaa"],
            [
                "a" => Item::get(Item::GOLD_BLOCK, 0, 1),
                "x" => Item::get(Item::APPLE, 0, 1)
            ],
            [Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 1)]);
        $this->getServer()->getCraftingManager()->registerRecipe($enchantedgoldenapple);
        $i++;

        $boyfarmer = new ShapedRecipe(
            ["aaa", "aca", "aaa"],
            [
                "a" => Item::get(Item::OBSIDIAN, 0, 1),
                "c" => Item::get(Item::DIAMOND, 0, 1)
            ],
            [Item::get(Item::IRON_ORE, 0, 1)]);
        $this->getServer()->getCraftingManager()->registerRecipe($boyfarmer);
        $i++;

        $fosafarmer = new ShapedRecipe(
            ["aaa", "bcb", "aaa"],
            [
                "a" => Item::get(Item::STONE, 0, 1),
                "c" => Item::get(Item::DIAMOND, 0, 1),
                "b" => Item::get(Item::DIAMOND_PICKAXE, 0, 1)
            ],
            [Item::get(Item::DIAMOND_ORE, 0, 1)]);
        $this->getServer()->getCraftingManager()->registerRecipe($fosafarmer);
        $i++;

        $enderchest = new ShapedRecipe(
            ["aaa", "aca", "aaa"],
            [
                "a" => Item::get(Item::OBSIDIAN, 0, 1),
                "c" => Item::get(Item::ENDER_PEARL, 0, 1)
            ],
            [Item::get(Item::ENDER_CHEST, 0, 1)]);
        $this->getServer()->getCraftingManager()->registerRecipe($enderchest);
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") craftingow pomyslnie.");
    }

    public function loadFarms()
    {
        $result = $this->db->query("SELECT * FROM farms");
        $world = $this->getServer()->getDefaultLevel();
        $i = 0;
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            if ($world->getBlock(new Vector3($row['x'], $row['y'], $row['z']))->getId() == Block::AIR) {
                $world->setBlock(new Vector3($row['x'], $row['y'], $row['z']), Block::get(Block::STONE, 0));
            }
            $i++;
        }
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") stoniarek pomyslnie.");
    }

    public function registerTasks()
    {
        $i = 0;
        $task = new MuteTask($this);
        $this->getScheduler()->scheduleDelayedRepeatingTask($task, 20 * 60, 20 * 60);
        $i++;
        $task = new TurboTask($this);
        $this->getScheduler()->scheduleDelayedRepeatingTask($task, 20 * 1, 20 * 1);
        $i++;
        $task = new BroadcastTask($this);
        $this->getScheduler()->scheduleDelayedRepeatingTask($task, 20 * 1, 20 * 1);
        $i++;
        $task = new TimeTask($this);
        $this->getScheduler()->scheduleRepeatingTask($task, 20 * 600);
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") taskow pomyslnie.");
    }

    public function registerInventoryMenu()
    {
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    public function withdrawEnchanted(Player $player, $amount)
    {
        $player->getInventory()->addItem(Item::get(466, 0, $amount));
        $name = $player->getName();
        $this->db->query("UPDATE limits SET enchanted = enchanted  + '-$amount' WHERE player='$name';");
    }

    public function withdrawGolden(Player $player, $amount)
    {
        $player->getInventory()->addItem(Item::get(322, 0, $amount));
        $name = $player->getName();
        $this->db->query("UPDATE limits SET golden = golden + '-$amount' WHERE player='$name';");
    }

    public function withdrawPearls(Player $player, $amount)
    {
        $player->getInventory()->addItem(Item::get(368, 0, $amount));
        $name = $player->getName();
        $this->db->query("UPDATE limits SET pearl = pearl + '-$amount' WHERE player='$name';");
    }

    public function addSchowekEnchanted(Player $player, int $amount)
    {
        $player = $player->getName();
        $this->db->query("UPDATE limits SET enchanted = enchanted + '$amount' WHERE player='$player';");
    }

    public function addSchowekGolden(Player $player, int $amount)
    {
        $player = $player->getName();
        $this->db->query("UPDATE limits SET golden = golden + '$amount' WHERE player='$player';");
    }

    public function addSchowekPearls(Player $player, int $amount)
    {
        $player = $player->getName();
        $this->db->query("UPDATE limits SET pearl = pearl + '$amount' WHERE player='$player';");
    }

    public function fillEq(Player $player)
    {
        $this->fillenchanted[$player->getName()] = 0;
        $this->fillgolden[$player->getName()] = 0;
        $this->fillpearls[$player->getName()] = 0;
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM limits WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        $goldenamount = $array["golden"];
        $enchantedamount = $array["enchanted"];
        $pearlsamount = $array["pearl"];
        if ($player instanceof Player) {
            foreach ($player->getInventory()->getContents() as $items) {
                if ($items->getId() == 466) {
                    $count = $items->getCount();
                    $count = $this->fillenchanted[$player->getName()] + $count;
                    $this->fillenchanted[$player->getName()] = $count;
                }
                if ($items->getId() == 322) {
                    $count = $items->getCount();
                    $count = $this->fillgolden[$player->getName()] + $count;
                    $this->fillgolden[$player->getName()] = $count;
                }
                if ($items->getId() == 368) {
                    $count = $items->getCount();
                    $count = $this->fillpearls[$player->getName()] + $count;
                    $this->fillpearls[$player->getName()] = $count;
                }
            }
            $enchantedcount = $this->getConfig()->get("max-enchanted") - $this->fillenchanted[$player->getName()];
            if ($this->fillenchanted[$player->getName()] < $this->getConfig()->get("max-enchanted")) {
                if ($enchantedamount >= $enchantedcount) {
                    $this->withdrawEnchanted($player, $enchantedcount);
                } else {
                    $enchantedcount = 0;
                }
            } else {
                $enchantedcount = 0;
            }
            $goldencount = $this->getConfig()->get("max-golden") - $this->fillgolden[$player->getName()];
            if ($this->fillgolden[$player->getName()] < $this->getConfig()->get("max-golden")) {
                if ($goldenamount >= $goldencount) {
                    $this->withdrawGolden($player, $goldencount);
                } else {
                    $goldencount = 0;
                }
            } else {
                $goldencount = 0;
            }
            $pearlscount = $this->getConfig()->get("max-pearls") - $this->fillpearls[$player->getName()];
            if ($this->fillpearls[$player->getName()] < $this->getConfig()->get("max-pearls")) {
                if ($pearlsamount >= $pearlscount) {
                    $this->withdrawPearls($player, $pearlscount);
                } else {
                    $pearlscount = 0;
                }
            } else {
                $pearlscount = 0;
            }
            $player->sendMessage($this->formatMessage("Uzupelniono: " . $enchantedcount . " koxow, " . $goldencount . " refili oraz " . $pearlscount . " perel", true));
        } else {
            $this->getLogger()->info(TextFormat::RED . "Ten gracz jest offline.");
        }
    }

    public function playerExistsInSchowek($player)
    {
        $result = $this->db->query("SELECT * FROM limits WHERE player='$player';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function addPlayerToSchowek($player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO limits (player, enchanted, golden, pearl) VALUES (:player, :enchanted, :golden, :pearl);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":enchanted", 0);
        $stmt->bindValue(":golden", 0);
        $stmt->bindValue(":pearl", 0);
        $result = $stmt->execute();
    }

    public function checkLimit(Player $player)
    {
        $this->enchanted[$player->getName()] = 0;
        $this->golden[$player->getName()] = 0;
        $this->pearls[$player->getName()] = 0;
        if ($player->getGamemode() != 1) {
            foreach ($player->getInventory()->getContents() as $items) {
                if ($items->getId() == 466) {
                    $count = $items->getCount();
                    $count = $this->enchanted[$player->getName()] + $count;
                    $this->enchanted[$player->getName()] = $count;
                }
                if ($items->getId() == 322) {
                    $count = $items->getCount();
                    $count = $this->golden[$player->getName()] + $count;
                    $this->golden[$player->getName()] = $count;
                }
                if ($items->getId() == 368) {
                    $count = $items->getCount();
                    $count = $this->pearls[$player->getName()] + $count;
                    $this->pearls[$player->getName()] = $count;
                }
            }
            if ($this->enchanted[$player->getName()] > $this->getConfig()->get("max-enchanted")) {
                $count = $this->enchanted[$player->getName()] - $this->getConfig()->get("max-enchanted");
                $player->getInventory()->removeItem(Item::get(466, 0, $count));
                $player->sendMessage($this->formatMessage("Limit koxow w ekwipunku to " . $this->getConfig()->get("max-enchanted") . ". Limit " . $count . " zostal dodany do schowka!", false));
                $this->addSchowekEnchanted($player, $count);
                $this->enchanted[$player->getName()] = 0;
            }
            if ($this->golden[$player->getName()] > $this->getConfig()->get("max-golden")) {
                $count = $this->golden[$player->getName()] - $this->getConfig()->get("max-golden");
                $player->getInventory()->removeItem(Item::get(322, 0, $count));
                $player->sendMessage($this->formatMessage("Limit refilow w ekwipunku to " . $this->getConfig()->get("max-golden") . ". Limit " . $count . " zostal dodany do schowka!", false));
                $this->addSchowekGolden($player, $count);
                $this->golden[$player->getName()] = 0;
            }
            if ($this->pearls[$player->getName()] > $this->getConfig()->get("max-pearls")) {
                $count = $this->pearls[$player->getName()] - $this->getConfig()->get("max-pearls");
                $player->getInventory()->removeItem(Item::get(368, 0, $count));
                $player->sendMessage($this->formatMessage("Limit perel w ekwipunku to " . $this->getConfig()->get("max-pearls") . ". Limit " . $count . " zostal dodany do schowka!", false));
                $this->addSchowekPearls($player, $count);
                $this->pearls[$player->getName()] = 0;
            }
        }
    }

    public function sendDiscordBanMessage(string $msg): void
    {
        $name = self::$config["discord"]["ban-webhook-name"];
        $url = self::$config["discord"]["ban-webhook-url"];
        $curlopts = [
            "content" => $msg,
            "username" => $name
        ];
        $this->getServer()->getAsyncPool()->submitTask(new WebhookAsyncTask($url, serialize($curlopts)));
    }

    public function sendDiscordChatMessage(string $msg): void
    {
        $name = self::$config["discord"]["chat-webhook-name"];
        $url = self::$config["discord"]["chat-webhook-url"];
        $curlopts = [
            "content" => $msg,
            "username" => $name
        ];
        $this->getServer()->getAsyncPool()->submitTask(new WebhookAsyncTask($url, serialize($curlopts)));
    }

    public function isOnPlate(Player $player)
    {
        return ($player->getLevel()->getBlock(new Vector3($player->getX(), $player->getY(), $player->getZ()))->getId() == Block::STONE_PRESSURE_PLATE or
            $player->getLevel()->getBlock(new Vector3($player->getX(), $player->getY(), $player->getZ()))->getId() == Block::WOODEN_PRESSURE_PLATE or
            $player->getLevel()->getBlock(new Vector3($player->getX(), $player->getY(), $player->getZ()))->getId() == Block::HEAVY_WEIGHTED_PRESSURE_PLATE or
            $player->getLevel()->getBlock(new Vector3($player->getX(), $player->getY(), $player->getZ()))->getId() == Block::LIGHT_WEIGHTED_PRESSURE_PLATE);
    }

    public function getPearl(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM pearl WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['enderpearl'];
    }

    public function getPremium(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM premiumcase WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['pc'];
    }

    public function getGolden(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM golden WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['goldenapple'];
    }

    public function getSpendMoney(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM spendmoney WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['monety'];
    }

    public function getEnchantedGolden(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM enchantedgolden WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['enchantedgoldenapple'];
    }

    public function addPlayerToEnderPearl(String $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO pearl (player, enderpearl) VALUES (:player, :enderpearl);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":enderpearl", 0);
        $result = $stmt->execute();
    }

    public function playerExistsInEnderPearl(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM pearl WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        if (!empty($stmt)) {
            return true;
        } else {
            return false;
        }
    }

    public function addPlayerToSpendMoney(String $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO spendmoney (player, monety) VALUES (:player, :monety);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":monety", 0);
        $result = $stmt->execute();
    }

    public function playerExistsInSpendMoney(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM spendmoney WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        if (!empty($stmt)) {
            return true;
        } else {
            return false;
        }
    }

    public function addSpendMoney(String $player, float $amount)
    {
        $this->db->query("UPDATE spendmoney SET monety = monety + '$amount' WHERE player='$player';");
    }

    public function addPlayerToEnchantedGoldenApple(String $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO enchantedgolden (player, enchantedgoldenapple) VALUES (:player, :enchantedgoldenapple);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":enchantedgoldenapple", 0);
        $result = $stmt->execute();
    }

    public function playerExistsInEnchantedGoldenApple(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM enchantedgolden WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        if (!empty($stmt)) {
            return true;
        } else {
            return false;
        }
    }

    public function addPlayerToGoldenApple(String $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO golden (player, goldenapple) VALUES (:player, :goldenapple);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":goldenapple", 0);
        $result = $stmt->execute();
    }

    public function playerExistsInGoldenApple(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM golden WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        if (!empty($stmt)) {
            return true;
        } else {
            return false;
        }
    }

    public function playerExistsInPremiumCase(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM premiumcase WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        if (!empty($stmt)) {
            return true;
        } else {
            return false;
        }
    }

    public function addPlayerToPremiumCase(String $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO premiumcase (player, pc) VALUES (:player, :pc);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":pc", 0);
        $result = $stmt->execute();
    }

    public function addPc(String $player, float $amount)
    {
        $this->db->query("UPDATE premiumcase SET pc = pc + '$amount' WHERE player='$player';");
    }

    public function addGoldenApple(String $player, float $amount)
    {
        $this->db->query("UPDATE golden SET goldenapple = goldenapple + '$amount' WHERE player='$player';");
    }

    public function addEnchantedGoldenApple(String $player, float $amount)
    {
        $this->db->query("UPDATE enchantedgolden SET enchantedgoldenapple = enchantedgoldenapple + '$amount' WHERE player='$player';");
    }

    public function addEnderPearl(String $player, float $amount)
    {
        $this->db->query("UPDATE pearl SET enderpearl = enderpearl + '$amount' WHERE player='$player';");
    }

    public function playerExistsInShop(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM shop WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        if (!empty($stmt)) {
            return true;
        } else {
            return false;
        }
    }

    public function addPlayerToShop(String $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO shop (player, money) VALUES (:player, :money);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":money", 0);
        $result = $stmt->execute();
    }

    public function getMoney(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM shop WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt['money'];
    }

    public function addMoney(String $player, float $amount)
    {
        $this->db->query("UPDATE shop SET money = money + '$amount' WHERE player='$player';");
    }

    public function reduceMoney(String $player, float $amount)
    {
        $this->db->query("UPDATE shop SET money = money + '-$amount' WHERE player='$player';");
    }

    public function playerExists(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM admins WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function addPlayer(Player $player)
    {
        $name = $player->getName();
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO admins (player, fly, god, vanish) VALUES (:player, :fly, :god, :vanish);");
        $stmt->bindValue(":player", $name);
        $stmt->bindValue(":fly", 1);
        $stmt->bindValue(":god", 1);
        $stmt->bindValue(":vanish", 1);
        $result = $stmt->execute();
    }

    public function addPlayerToColoredNames(Player $player)
    {
        $name = $player->getName();
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO colorednames (player, displayname, status) VALUES (:player, :displayname, :status);");
        $stmt->bindValue(":player", $name);
        $stmt->bindValue(":displayname", $name);
        $stmt->bindValue(":status", 1);
        $result = $stmt->execute();
    }

    public function playerExistsInColoredNames(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM colorednames WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function stringExistsInColoredName(String $name)
    {
        $result = $this->db->query("SELECT * FROM colorednames WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function hasColoredName(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM colorednames WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["status"] == 0;
    }

    public function getColoredName(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM colorednames WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["displayname"];
    }

    public function switchFly(Player $player)
    {
        $name = $player->getName();
        if ($this->getFly($player) == 0) {
            $this->db->query("UPDATE admins SET fly = '1' WHERE player='$name';");
            $player->setAllowFlight(false);
            $player->setFlying(false);
            $player->sendMessage($this->formatMessage("Wylaczyles latanie!", true));
        } elseif ($this->getFly($player) == 1) {
            $this->db->query("UPDATE admins SET fly = '0' WHERE player='$name';");
            $player->setAllowFlight(true);
            $player->sendMessage($this->formatMessage("Wlaczyles latanie!", true));
        }
    }

    public function getFly(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM admins WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["fly"];
    }

    public function formatMessage($string, $confirm = false)
    {
        $success = $this->getConfig()->get("PrefixSuccess");
        $failure = $this->getConfig()->get("PrefixFailure");
        if ($confirm) {
            return str_replace('{STRING}', $string, $success);
        } else {
            return str_replace('{STRING}', $string, $failure);
        }
    }

    public function switchGod(Player $player)
    {
        $name = $player->getName();
        if ($this->getGod($player) == 0) {
            $this->db->query("UPDATE admins SET god = '1' WHERE player='$name';");
            $player->sendMessage($this->formatMessage("Wylaczyles goda!", true));
        } elseif ($this->getGod($player) == 1) {
            $this->db->query("UPDATE admins SET god = '0' WHERE player='$name';");
            $player->sendMessage($this->formatMessage("Wlaczyles goda!", true));
        }
    }

    public function getGod(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM admins WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["god"];
    }

    public function switchVanish(Player $player)
    {
        $name = $player->getName();
        if ($this->getVanish($player) == 0) {
            $this->db->query("UPDATE admins SET vanish = '1' WHERE player='$name';");
            $player->sendMessage($this->formatMessage("Wylaczyles vanisha!", true));
            foreach ($this->getServer()->getOnlinePlayers() as $p) {
                $p->showPlayer($player);
                if ($p->hasPermission("vanish.override")) {
                    $p->sendMessage($this->formatMessage("Administrator " . $player->getName() . " wylaczyl vanish!", true));
                }
            }
        } elseif ($this->getVanish($player) == 1) {
            $this->db->query("UPDATE admins SET vanish = '0' WHERE player='$name';");
            $player->sendMessage($this->formatMessage("Wlaczyles vanisha!", true));
            foreach ($this->getServer()->getOnlinePlayers() as $p) {
                if (!$p->hasPermission("vanish.override")) {
                    $p->hidePlayer($player);
                } else {
                    $p->showPlayer($player);
                    $p->sendMessage($this->formatMessage("Administrator " . $player->getName() . " wlaczyl vanish!", true));
                }
            }
        }
    }

    public function getVanish(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM admins WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["vanish"];
    }

    public function openChestInventory(Player $player, int $x, int $y, int $z)
    {
        $tile = $player->getLevel()->getTile(new Vector3($x, $y, $z));
        if ($tile instanceof Chest) {
            if ($tile->isPaired()) {
                $items = $tile->getInventory()->getContents(true);
                $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
                $menu->getInventory()->setContents($items);
                $menu->readonly();
                $menu->send($player);
            } else {
                $items = $tile->getInventory()->getContents(true);
                $menu = InvMenu::create(InvMenu::TYPE_CHEST);
                $menu->getInventory()->setContents($items);
                $menu->readonly();
                $menu->send($player);
            }
        }
    }

    public function openPlayerInventory(Player $player, Player $target)
    {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $items = $target->getInventory()->getContents(true);
        $menu->getInventory()->setContents($items);
        $armor = $target->getArmorInventory();
        $helmet = $armor->getHelmet();
        $chestplate = $armor->getChestplate();
        $leggings = $armor->getLeggings();
        $boots = $armor->getBoots();
        $menu->getInventory()->setItem(53, $helmet->setLore(["§8[§bAKTUALNIE UBRANE§8]"]));
        $menu->getInventory()->setItem(52, $chestplate->setLore(["§8[§bAKTUALNIE UBRANE§8]"]));
        $menu->getInventory()->setItem(51, $leggings->setLore(["§8[§bAKTUALNIE UBRANE§8]"]));
        $menu->getInventory()->setItem(50, $boots->setLore(["§8[§bAKTUALNIE UBRANE§8]"]));
        $menu->setName("§l§8» §bEkwipunek: " . $target->getName());
        $menu->readonly();
        $menu->send($player);
    }

    public function changeChatStatus(int $status)
    {
        $this->db->query("UPDATE chat SET status = '$status' WHERE chat='chat';");
    }

    public function getChatStatus()
    {
        $result = $this->db->query("SELECT * FROM chat WHERE chat='chat';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["status"];
    }

    public function makeRainbow(String $string)
    {
        $text = str_split($string);
        $i = -1;
        foreach ($text as $index => $char) {
            if ($char == " ") continue;
            if ($i >= count($this->RAINBOW_COLORS) - 1) $i = -1;
            $color = $this->RAINBOW_COLORS[++$i];
            $text[$index] = $color . $char;
        }
        return implode($text);
    }

    public function isPremiumCase(Item $item)
    {
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        return ($nbt->hasTag("premiumcase", StringTag::class) && $nbt->getTagValue("premiumcase", StringTag::class) == "true" && $item->getId() == Item::TRAPPED_CHEST && $item->getCustomName() == $this->getConfig()->get("PremiumCaseCustomName"));
    }

    public function isBlockStoneFarm(Item $item)
    {
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        return ($nbt->hasTag("stonefarm", StringTag::class) && $nbt->getTagValue("stonefarm", StringTag::class) == "3" or $nbt->hasTag("stonefarm", StringTag::class) && $nbt->getTagValue("stonefarm", StringTag::class) == "2" or $nbt->hasTag("stonefarm", StringTag::class) && $nbt->getTagValue("stonefarm", StringTag::class) == "1");
    }

    public function createFarm(int $x, int $y, int $z, int $type)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO farms1 (x, y, z, type) VALUES (:x, :y, :z, :type);");
        $stmt->bindValue(":x", $x);
        $stmt->bindValue(":y", $y);
        $stmt->bindValue(":z", $z);
        $stmt->bindValue(":type", $type);
        $result = $stmt->execute();
    }

    public function deleteFarm(int $x, int $y, int $z)
    {
        $this->db->query("DELETE FROM farms1 WHERE x='$x' AND y='$y' AND z='$z';");
    }

    public function getFarmType(int $x, int $y, int $z)
    {
        $result = $this->db->query("SELECT * FROM farms1 WHERE x='$x' AND y='$y' AND z='$z';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["type"];
    }

    public function isFarm(int $x, int $y, int $z)
    {
        $result = $this->db->query("SELECT * FROM farms1 WHERE x='$x' AND y='$y' AND z='$z';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return ($array['x'] == $x && $array['y'] == $y && $array['z'] == $z);
    }

    public function getStoneFarmTypeItem(Item $item)
    {
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        return $nbt->getTagValue("stonefarm", StringTag::class);
    }

    public function addStoneFarm(Player $player, int $count, int $type)
    {
        if ($type == 1) {
            $item = Item::get(Item::END_STONE, 0, $count);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("stonefarm", "1"));
            $item->setNamedTag($nbt);
            $item->setCustomName("§l§8» §b§lNormalna Stoniarka");
            $item->setLore(["§l§8» §7Czas odnowienia: §b2s"]);
            $player->getInventory()->addItem($item);
        } elseif ($type == 2) {
            $item = Item::get(Item::END_STONE, 0, $count);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("stonefarm", "2"));
            $item->setNamedTag($nbt);
            $item->setCustomName("§l§8» §bSzybka Stoniarka");
            $item->setLore(["§l§8» §7Czas odnowienia: §b1s"]);
            $player->getInventory()->addItem($item);
        } elseif ($type == 3) {
            $item = Item::get(Item::END_STONE, 0, $count);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("stonefarm", "3"));
            $item->setNamedTag($nbt);
            $item->setCustomName("§l§8» §bSuperszybka Stoniarka");
            $item->setLore(["§l§8» §7Czas odnowienia: §b0.5s"]);
            $player->getInventory()->addItem($item);
        }
    }

    public function playerExistsInEnderchest(Player $player)
    {
        $path = $this->getDataFolder() . "enderchests/" . $player->getName() . ".dat";
        return file_exists($path);
    }

    public function playerExistsInDrop(String $player)
    {
        $result = $this->db->query("SELECT * FROM drops WHERE player='$player';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function addPlayerToDrop(String $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO drops (player, diamond, iron, gold, emerald, coal, redstone, gunpowder, bookshelf, obsidian, xp, cobblestone, apple, pearl) VALUES (:player, :diamond, :iron, :gold, :emerald, :coal, :redstone, :gunpowder, :bookshelf, :obsidian, :xp, :cobblestone, :apple, :pearl);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":diamond", 0);
        $stmt->bindValue(":iron", 0);
        $stmt->bindValue(":gold", 0);
        $stmt->bindValue(":emerald", 0);
        $stmt->bindValue(":coal", 0);
        $stmt->bindValue(":redstone", 0);
        $stmt->bindValue(":gunpowder", 0);
        $stmt->bindValue(":bookshelf", 0);
        $stmt->bindValue(":obsidian", 0);
        $stmt->bindValue(":xp", 0);
        $stmt->bindValue(":cobblestone", 0);
        $stmt->bindValue(":apple", 0);
        $stmt->bindValue(":pearl", 0);
        $result = $stmt->execute();
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO turbodrop (player, timestamp) VALUES (:player, :timestamp);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":timestamp", -1);
        $result = $stmt->execute();
    }

    public function switchDropStatus(String $player, String $item)
    {
        if ($item == "diamond" or $item == "iron" or $item == "gold" or $item == "emerald" or $item == "coal" or $item == "redstone" or $item == "gunpowder" or $item == "bookshelf" or $item == "obsidian" or $item == "xp" or $item == "cobblestone" or $item == "apple" or $item == "pearl") {
            if ($this->getDropStatus($player, $item) == 0) {
                $this->setDropStatus($player, $item, 1);
            } elseif ($this->getDropStatus($player, $item) == 1) {
                $this->setDropStatus($player, $item, 0);
            }
        } else {
            $this->getLogger()->alert($item . " was not found in database! (function: switchDropStatus)");
        }
    }

    public function getDropStatus(String $player, String $item)
    {
        if ($item == "diamond" or $item == "iron" or $item == "gold" or $item == "emerald" or $item == "coal" or $item == "redstone" or $item == "gunpowder" or $item == "bookshelf" or $item == "obsidian" or $item == "xp" or $item == "cobblestone" or $item == "apple" or $item == "pearl") {
            $stmt = $this->db->query("SELECT * FROM drops WHERE player='$player';");
            $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
            return $stmt[$item];
        } else {
            $this->getLogger()->alert($item . " was not found in database! (function: getDropStatus)");
        }
    }

    public function setDropStatus(String $player, String $item, int $status)
    {
        if ($item == "diamond" or $item == "iron" or $item == "gold" or $item == "emerald" or $item == "coal" or $item == "redstone" or $item == "gunpowder" or $item == "bookshelf" or $item == "obsidian" or $item == "xp" or $item == "cobblestone" or $item == "apple" or $item == "pearl") {
            $this->db->query("UPDATE drops SET '$item' = '$status' WHERE player='$player';");
        } else {
            $this->getLogger()->alert($item . " was not found in database! (function: setchangeStatus)");
        }
    }

    public function changeDropStatusForAll(String $player, int $status)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO drops (player, diamond, iron, gold, emerald, coal, redstone, gunpowder, bookshelf, obsidian, xp, cobblestone, apple, pearl) VALUES (:player, :diamond, :iron, :gold, :emerald, :coal, :redstone, :gunpowder, :bookshelf, :obsidian, :xp, :cobblestone, :apple, :pearl);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":diamond", $status);
        $stmt->bindValue(":iron", $status);
        $stmt->bindValue(":gold", $status);
        $stmt->bindValue(":emerald", $status);
        $stmt->bindValue(":coal", $status);
        $stmt->bindValue(":redstone", $status);
        $stmt->bindValue(":gunpowder", $status);
        $stmt->bindValue(":bookshelf", $status);
        $stmt->bindValue(":obsidian", $status);
        $stmt->bindValue(":xp", $status);
        $stmt->bindValue(":cobblestone", $status);
        $stmt->bindValue(":apple", $status);
        $stmt->bindValue(":pearl", $status);
        $result = $stmt->execute();
    }

    public function enableGuildDrop(String $player)
    {
        $this->db->query("UPDATE drops SET 'diamond' = '0' WHERE player='$player';");
        $this->db->query("UPDATE drops SET 'gold' = '0' WHERE player='$player';");
        $this->db->query("UPDATE drops SET 'iron' = '0' WHERE player='$player';");
        $this->db->query("UPDATE drops SET 'emerald' = '0' WHERE player='$player';");
        $this->db->query("UPDATE drops SET 'coal' = '0' WHERE player='$player';");
    }

    public function getDropStatusAsString(String $player, String $item)
    {
        if ($item == "diamond" or $item == "iron" or $item == "gold" or $item == "emerald" or $item == "coal" or $item == "redstone" or $item == "gunpowder" or $item == "bookshelf" or $item == "obsidian" or $item == "xp" or $item == "cobblestone" or $item == "apple" or $item == "pearl") {
            if ($this->getDropStatus($player, $item) == 0) {
                return "§aWLACZONY";
            } else {
                return "§cWYLACZONY";
            }
        } else {
            $this->getLogger()->alert($item . " was not found in database! (function: getDropStatusInString)");
        }
    }

    public function getTurboDropStatusAsString(String $player)
    {
        if ($this->hasTurbo($player)) {
            return "§aWLACZONY";
        } else {
            return "§cWYLACZONY";
        }
    }

    public function hasTurbo(String $player)
    {
        $stmt = $this->db->query("SELECT * FROM turbodrop WHERE player='$player';");
        $stmt = $stmt->fetchArray(SQLITE3_ASSOC);
        return $stmt["timestamp"] > 0;
    }

    public function isPickaxe(Item $item)
    {
        return ($item->getId() == Item::DIAMOND_PICKAXE or $item->getId() == Item::IRON_PICKAXE or $item->getId() == Item::STONE_PICKAXE or $item->getId() == Item::GOLDEN_PICKAXE or $item->getId() == Item::WOODEN_PICKAXE);
    }

    public function addPlayerToEnderchest(Player $player)
    {
        if (!is_dir("enderchests")) {
            @mkdir($this->getDataFolder() . "enderchests");
        }
        $contents = [];
        $data = serialize($contents);
        $path = $this->getDataFolder() . "enderchests/" . $player->getName() . ".dat";
        if (file_exists($path)) {
            unlink($path);
        }
        file_put_contents($path, $data);
    }

    public function setEnderchestContents(Player $player, array $contents)
    {
        $data = serialize($contents);
        $path = $this->getDataFolder() . "enderchests/" . $player->getName() . ".dat";
        file_put_contents($path, $data);
    }

    public function getEnderchestContents(Player $player)
    {
        $path = $this->getDataFolder() . "enderchests/" . $player->getName() . ".dat";
        return unserialize(file_get_contents($path));
    }

    public function removeEnderchestContents(Player $player)
    {
        $path = $this->getDataFolder() . "enderchests/" . $player->getName() . ".dat";
        @unlink($path);
    }

    public function openEffectsGUI(Player $player)
    {
        $gui = new EffectsListener($this, "§l§bEFEKTY");
        $gui->addContents();
        $gui->sendTo($player);
    }

    public function openTopsGUI(Player $player)
    {
        $gui = new TopsListener($this, "§l§bTOPKI");
        $gui->addDefaultContents();
        $gui->sendTo($player);
    }

    public function getNumberOfHomes(String $player)
    {
        $home = $this->db->query("SELECT COUNT(*) as count FROM home WHERE player='$player';");
        $array = $home->fetchArray();
        return $array["count"];
    }

    public function getAllHome(String $player)
    {
        $home = $this->db->query("SELECT * FROM home WHERE player='$player';");
        $string = "";
        while ($row = $home->fetchArray(SQLITE3_ASSOC)) {
            $string = $string . $row["name"] . ", ";
        }
        return $string;
    }

    public function getHome(String $player, $home)
    {
        $home = $this->db->query("SELECT * FROM home WHERE player='$player' AND name='$home';");
        $array = $home->fetchArray(SQLITE3_ASSOC);
        $this->getX = $array["x"];
        $this->getY = $array["y"];
        $this->getZ = $array["z"];
        $this->getWorld = $array["world"];
    }

    public function getIdHome(String $player, $home)
    {
        $home = $this->db->query("SELECT * FROM home WHERE player='$player' AND name='$home';");
        $array = $home->fetchArray();
        return $array["id"];
    }

    public function homeExists(String $player, $home)
    {
        $home = $this->db->query("SELECT * FROM home WHERE player='$player' AND name='$home';");
        $array = $home->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function setMuted(Player $player, int $time)
    {
        $name = $player->getName();
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO mute (player, timestamp) VALUES (:player, :time);");
        $stmt->bindValue(":player", $name);
        $stmt->bindValue(":time", $time);
        $result = $stmt->execute();
    }

    public function isMuted(String $player)
    {
        $result = $this->db->query("SELECT * FROM mute WHERE player='$player';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return (empty($array) == false && $array["timestamp"] > 1);
    }

    public function getMuteTime(String $player)
    {
        $result = $this->db->query("SELECT * FROM mute WHERE player='$player';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["timestamp"];
    }

    public function unmute(String $player)
    {
        $this->db->query("DELETE FROM mute WHERE player='$player';");
    }

    public function logPlayer(Player $player)
    {
        $path = $this->getDataFolder() . "iplogger/" . $player->getName() . ".yml";
        if (!is_dir("iplogger")) {
            @mkdir($this->getDataFolder() . "iplogger");
        }
        $cfg = new Config($path);
        $cfg->set("Address", $player->getAddress());
        $cfg->set("XUID", $player->getXuid());
        $cfg->set("Model", $player->getDeviceModel());
        $cfg->set("System", $this->getOSAsString($player));
        $cfg->save();
    }

    public function getOSAsString(Player $player)
    {
        if ($player->getDeviceOS() == 7) {
            return "Windows 10";
        } elseif ($player->getDeviceOS() == 1) {
            return "Android";
        } elseif ($player->getDeviceOS() == 2) {
            return "iOS";
        } else {
            return "KONSOLA";
        }
    }

    public function getPlayersFilesCount()
    {
        $path = glob($this->getServer()->getDataPath() . "players/" . "*.dat");
        return count($path);
    }

    public function replacePolishChars($string)
    {
        $replaceto = array('ą' => 'a', 'ę' => 'e', 'ś' => 's', 'ć' => 'c', 'ó' => 'o', 'ń' => 'n', 'ż' => 'z', 'ź' => 'z', 'ł' => 'l', 'Ą' => 'A', 'Ę' => 'E', 'Ś' => 'S', 'Ć' => 'C', 'Ó' => 'O', 'Ń' => 'N', 'Ż' => 'Z', 'Ź' => 'Z', 'Ł' => 'L', 'StoryMC' => 'suchodolski to jebany przegryw na kopa', 'story' => 'suchodolski to jebany przegryw na kopa');
        return str_replace(array_keys($replaceto), array_values($replaceto), $string);
    }

    public function replaceDiscordChars($string)
    {
        $replaceto = array('§r' => '', '§l' => '', '§c' => '', '§6' => '', '§e' => '', '§a' => '', '§b' => '', '§9' => '', '§d' => '', '§8' => '', '@' => '');
        return str_replace(array_keys($replaceto), array_values($replaceto), $string);
    }

    public function getPoints(String $player)
    {
        return $this->api("cloudPoints")->getPoints($player);

    }

    public function api(String $plugin)
    {
        return $this->getServer()->getPluginManager()->getPlugin($plugin);
    }

    public function getFactionAsString(String $player)
    {
        $factions = $this->api("cloudGuilds");
        if ($factions->isInFaction($player)) {
            return "§8[§b" . $factions->getPlayerFaction($player) . "§8] ";
        } else {
            return "";
        }
        return true;
    }

    public function getGroupAsString($player)
    {
        $pureperms = $this->api("PurePerms");
        $player = $pureperms->getPlayer($player);
        if ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "Gracz") {
            $group = "";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "Vip") {
            $group = "§8[§6VIP§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "VipNaZawsze") {
            $group = "§8[§6VIP§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "Svip") {
            $group = "§8[§9SVIP§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "SvipNaZawsze") {
            $group = "§8[§9SVIP§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "Sponsor") {
            $group = "§8[§aSponsor§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "SponsorNaZawsze") {
            $group = "§8[§aSponsor§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "Swagger") {
            $group = "§8[§cS§6w§ea§eg§bg§9e§dr§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "SwaggerNaZawsze") {
            $group = "§8[§cS§6w§ea§eg§bg§9e§dr§r§8]";
            return $group;
        } elseif ($pureperms->getUserDataMgr()->getGroup($player)->getName() == "Pomocnik"
            or $pureperms->getUserDataMgr()->getGroup($player)->getName() == "ChatHelper"
            or $pureperms->getUserDataMgr()->getGroup($player)->getName() == "Moderator"
            or $pureperms->getUserDataMgr()->getGroup($player)->getName() == "Admin"
            or $pureperms->getUserDataMgr()->getGroup($player)->getName() == "Wlasciciel") {
            $group = "§8[§c" . $pureperms->getUserDataMgr()->getGroup($player)->getName() . "§r§8]";
            return $group;
        }
        return true;
    }

    public function setNameTag($player)
    {
        $faction = $this->getFactionAsString($player->getName());
        $group = $this->getGroupAsString($player->getName());
        $points = $this->getPoints($player->getName());
        $os = $this->getOSAsString($player);
        $nametag = $faction . "" . $group . " §f" . $player->getDisplayName() . "\n§b" . $os . "\n§f" . $points . " §bPKT";
        $player->setNameTag($nametag);
    }

    public function getGroup($player)
    {
        $pureperms = $this->api("PurePerms");
        $player = $pureperms->getPlayer($player);
        return $pureperms->getUserDataMgr()->getGroup($player)->getName();
    }
}