<?php

namespace cloudmc\GUIListeners;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\item\Item;
use cloudmc\Main;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\CompoundTag;

class SchowekListener
{

    public $plugin;
    public $menu;

    public function __construct(Main $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function addContents(Player $player): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $name = $player->getName();
        $result = $this->plugin->db->query("SELECT * FROM limits WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        $pearlscount = $array["pearl"];
        $goldenscount = $array["golden"];
        $enchantedcount = $array["enchanted"];

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        #$inv->setItem(20, $item);
        $inv->setItem(21, $item);
        #$inv->setItem(22, $item);
        $inv->setItem(23, $item);
        #$inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        #$inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 1);
        $item->setCustomName("§l§7ILOSC KOXOW:§b " . $enchantedcount);
        $item->setLore(["§l ",
            "§l§aKliknij, aby wyplacic 1 koxa"]);
        $inv->setItem(20, $item);

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName("§l§7ILOSC REFILI:§b " . $goldenscount);
        $item->setLore(["§l ",
            "§l§aKliknij, aby wyplacic 1 refila"]);
        $inv->setItem(22, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 1);
        $item->setCustomName("§l§7ILOSC PEREL:§b " . $pearlscount);
        $item->setLore(["§l ",
            "§l§aKliknij, aby wyplacic 1 perle"]);
        $inv->setItem(24, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bWyplac limit");
        $inv->setItem(40, $item);
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $name = $player->getName();
        $result = $this->plugin->db->query("SELECT * FROM limits WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        $pearlscount = $array["pearl"];
        $goldenscount = $array["golden"];
        $enchantedcount = $array["enchanted"];

        if ($itemTakenOut->getId() == Item::ENCHANTED_GOLDEN_APPLE) {
            if ($enchantedcount >= 1) {
                $this->plugin->withdrawEnchanted($player, 1);
                $this->addContents($player);
            }
        }
        if ($itemTakenOut->getId() == Item::GOLDEN_APPLE) {
            if ($goldenscount >= 1) {
                $this->plugin->withdrawGolden($player, 1);
                $this->addContents($player);
            }
        }
        if ($itemTakenOut->getId() == Item::ENDER_PEARL) {
            if ($pearlscount >= 1) {
                $this->plugin->withdrawPearls($player, 1);
                $this->addContents($player);
            }
        }
        if ($itemTakenOut->getId() == Item::TOTEM) {
            $this->plugin->fillEq($player);
            $this->addContents($player);
        }
        return true;
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}