<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\block\BlockIds;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;
use pocketmine\item\TieredTool;
use pocketmine\Player;

class AnvilListener
{

    public $plugin;
    public $menu;

    public function __construct(Main $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        if ($itemTakenOut->getId() == Item::ANVIL) {
            $item = $player->getInventory()->getItemInHand();
            $tierIds = [
                TieredTool::TIER_WOODEN => BlockIds::WOODEN_PLANKS,
                TieredTool::TIER_STONE => BlockIds::COBBLESTONE,
                TieredTool::TIER_IRON => ItemIds::IRON_INGOT,
                TieredTool::TIER_GOLD => ItemIds::GOLD_INGOT,
                TieredTool::TIER_DIAMOND => ItemIds::DIAMOND
            ];
            if ($item instanceof TieredTool) {
                if ($player->getXpLevel() >= 30) {
                    if ($player->getInventory()->contains(Item::get($tierIds[$item->getTier()], 0, $this->getCost($item)))) {
                        $player->getInventory()->removeItem(Item::get($tierIds[$item->getTier()], 0, $this->getCost($item)));
                        $player->removeWindow($inventoryAction->getInventory());
                        $player->sendMessage($this->plugin->formatMessage("Naprawiono przedmiot w rece (Pobrano: " . $this->getCost($item) . " " . Item::get($tierIds[$item->getTier()])->getName() . " z ekwipunku)", true));
                        $player->getInventory()->setItemInHand($item->setDamage(0));
                        $player->setXpLevel($player->getXpLevel() - 30);
                    } else {
                        $player->removeWindow($inventoryAction->getInventory());
                        $player->sendMessage($this->plugin->formatMessage("Aby naprawic ten przedmiot potrzebujesz " . $this->getCost($item) . " " . Item::get($tierIds[$item->getTier()])->getName(), false));
                    }
                } else {
                    $player->removeWindow($inventoryAction->getInventory());
                    $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 levela, aby naprawic przedmiot w rece!", false));
                }
            } else {
                $player->removeWindow($inventoryAction->getInventory());
                $player->sendMessage($this->plugin->formatMessage("Nie mozesz naprawic tego przedmiotu!", false));
            }
        }
        if ($itemTakenOut->getId() == Item::DIAMOND_PICKAXE) {
            if ($player->hasPermission("repair.use.all")) {
                foreach ($player->getInventory()->getContents() as $index => $item) {
                    if ($item instanceof TieredTool or $item instanceof Armor) {
                        if ($item->getDamage() > 0) {
                            $player->getInventory()->setItem($index, $item->setDamage(0));
                        }
                    }
                }
                foreach ($player->getArmorInventory()->getContents() as $index => $item) {
                    if ($item instanceof Armor) {
                        if ($item->getDamage() > 0) {
                            $player->getArmorInventory()->setItem($index, $item->setDamage(0));
                        }
                    }
                }
                $player->removeWindow($inventoryAction->getInventory());
                $player->sendMessage($this->plugin->formatMessage("Naprawiono wszystkie przedmioty w ekwipunku!", true));
            } else {
                $player->removeWindow($inventoryAction->getInventory());
                $player->sendMessage($this->plugin->formatMessage("Nie mozesz tego wykonac!", false));
            }
        }
        if ($itemTakenOut->getId() == Item::DIAMOND_PICKAXE) {
            $player->removeWindow($inventoryAction->getInventory());
            $api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
            if ($player->getInventory()->getItemInHand()->getId() != 0) {
                if (!$api === null || !$api->isDisabled()) {
                    $form = $api->createCustomForm(function (Player $player, ?array $data) {
                        if (isset($data[0])) {
                            switch ($data[0]) {
                                case 0:
                                    if ($player->getXpLevel() >= 30) {
                                        $item = $player->getInventory()->getItemInHand();
                                        $item->setCustomName($data[0]);
                                        $player->getInventory()->setItemInHand($item);
                                        $player->sendMessage($this->plugin->formatMessage("Zmieniono nazwe przedmiotu na " . $data[0], true));
                                        $player->setXpLevel($player->getXpLevel() - 30);
                                    } else {
                                        $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby zmienic nazwe!", false));
                                    }
                                    break;
                            }
                        }
                    });
                    $form->setTitle("§l§8» §bZmiana nazwy przedmiotu");
                    $form->addInput("§l§8» §bWpisz nazwe przedmiotu");
                    $form->sendToPlayer($player);
                }
            } else {
                $player->removeWindow($inventoryAction->getInventory());
                $player->sendMessage($this->plugin->formatMessage("Nie posiadasz przedmiotu w rece!", false));
            }
        }
        if ($itemTakenOut->getId() == Item::DIAMOND_HELMET) {
            if ($player->getInventory()->contains(Item::get(Item::DIAMOND, 0, 64))) {
                $i = 0;
                foreach ($player->getArmorInventory()->getContents() as $item) {
                    if ($item instanceof Armor) {
                        $i++;
                    }
                }
                if ($i >= 1) {
                    if ($player->getXpLevel() >= 30) {
                        foreach ($player->getArmorInventory()->getContents() as $index => $item) {
                            if ($item instanceof Armor) {
                                if ($item->getDamage() > 0) {
                                    $player->getArmorInventory()->setItem($index, $item->setDamage(0));
                                }
                            }
                        }
                        $player->removeWindow($inventoryAction->getInventory());
                        $player->getInventory()->removeItem(Item::get(Item::DIAMOND, 0, 64));
                        $player->setXpLevel($player->getXpLevel() - 30);
                        $player->sendMessage($this->plugin->formatMessage("Naprawiono ubrana zbroje!", true));
                    } else {
                        $player->removeWindow($inventoryAction->getInventory());
                        $player->sendMessage($this->plugin->formatMessage("Aby naprawic ubrana zbroje potrzebujesz 30 poziomu!", false));
                    }
                } else {
                    $player->removeWindow($inventoryAction->getInventory());
                    $player->sendMessage($this->plugin->formatMessage("Potrzebujesz przynajmniej 1 ubranej rzeczy na sobie, aby naprawic zbroje!", false));
                }
            } else {
                $player->removeWindow($inventoryAction->getInventory());
                $player->sendMessage($this->plugin->formatMessage("Aby naprawic ubrana zbroje potrzebujesz 64 diamenty!", false));
            }
        }
        if ($itemTakenOut->getId() == -161) {
            $this->addContents($player);
        }
        return true;
    }

    public function getCost(Item $item)
    {
        if ($item instanceof TieredTool) {
            if ($item->getDamage() / $item->getMaxDurability() * 100 <= 25) {
                return 1;
            } elseif ($item->getDamage() / $item->getMaxDurability() * 100 <= 50) {
                return 2;
            } elseif ($item->getDamage() / $item->getMaxDurability() * 100 <= 75) {
                return 3;
            } elseif ($item->getDamage() / $item->getMaxDurability() * 100 <= 100) {
                return 4;
            } else {
                return 0;
            }
        }
    }

    public function addContents(Player $player): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();
        $tierIds = [
            TieredTool::TIER_WOODEN => BlockIds::WOODEN_PLANKS,
            TieredTool::TIER_STONE => BlockIds::COBBLESTONE,
            TieredTool::TIER_IRON => ItemIds::IRON_INGOT,
            TieredTool::TIER_GOLD => ItemIds::GOLD_INGOT,
            TieredTool::TIER_DIAMOND => ItemIds::DIAMOND
        ];

        if ($player->getInventory()->getItemInHand() instanceof TieredTool) {
            $item = Item::get(Item::ANVIL, 0, 1);
            $item->setCustomName("§l§8§bNapraw narzedzie w rece");
            $item->setLore(["§l ",
                "§l§8§7Wymagania: §b30 XP LVL, " . $this->getCost($player->getInventory()->getItemInHand()) . " " . Item::get($tierIds[$player->getInventory()->getItemInHand()->getTier()])->getName(),
                "§l§8§aKliknij, aby naprawic narzedzie w rece"]);
            $inv->setItem(20, $item);
        } else {
            $item = Item::get(Item::ANVIL, 0, 1);
            $item->setCustomName("§l§8§cNarzedzia w rece nieda sie naprawic!");
            $inv->setItem(20, $item);
        }

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        #$inv->setItem(20, $item);
        $inv->setItem(21, $item);
        #$inv->setItem(22, $item);
        $inv->setItem(23, $item);
        #$inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->setCustomName("§l§8§bNapraw wszystkie przedmioty w ekwipunku (+ zbroja)");
        $item->setLore(["§l ",
            "§l§8§7Wymagania: §bPermisja do repair all",
            "§l§8§aKliknij, aby naprawic wszystkie przedmioty w ekwipunku"]);
        $inv->setItem(24, $item);

        $item = Item::get(Item::DIAMOND_HELMET, 0, 1);
        $item->setCustomName("§l§8§bNapraw ubrana zbroje");
        $item->setLore(["§l ",
            "§l§8§7Wymagania: §b60 XP LVL, 10 Diamond",
            "§l§8§aKliknij, aby naprawic ubrana zbroje"]);
        $inv->setItem(22, $item);
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}