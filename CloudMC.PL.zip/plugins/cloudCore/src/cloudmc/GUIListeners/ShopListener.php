<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class ShopListener
{

    public $plugin;
    public $menu;

    public function __construct(Main $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public
    function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        if ($nbt->hasTag("menu", StringTag::class)) {
            if ($nbt->getTagValue("menu", StringTag::class) == "shop") {
                $this->addShop();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "sell") {
                $this->addSell();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "back") {
                $this->addContents();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "sety") {
                $this->addSety();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "narzedzia") {
                $this->addNarzedzia();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "limity") {
                $this->addLimity();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "przebijanie") {
                $this->addPrzebijanie();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "bloki") {
                $this->addBloki();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "dodatki") {
                $this->addDodatki();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "drzewa") {
                $this->addDrzewa();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "welna") {
                $this->addWelna();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "beton") {
                $this->addBeton();
            } elseif ($nbt->getTagValue("menu", StringTag::class) == "terracota") {
                $this->addTerracota();
            }
        }
        if ($nbt->hasTag("exp", StringTag::class)) {
            $cost = $nbt->getTagValue("exp", StringTag::class);
            if ($player->getXpLevel() >= 100) {
                $player->setXpLevel($player->getXpLevel() - 100);
                $this->plugin->addMoney($player->getName(), 1);
            }
        }
        if ($nbt->hasTag("cobblestone", StringTag::class)) {
            $cost = $nbt->getTagValue("cobblestone", StringTag::class);
            if ($player->getInventory()->contains(Item::get(4, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(4, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.01);
            }
        }
        if ($nbt->hasTag("diamond", StringTag::class)) {
            $cost = $nbt->getTagValue("diamond", StringTag::class);
            if ($player->getInventory()->contains(Item::get(264, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(264, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.04);
            }
        }
        if ($nbt->hasTag("iron", StringTag::class)) {
            $cost = $nbt->getTagValue("iron", StringTag::class);
            if ($player->getInventory()->contains(Item::get(265, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(265, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.03);
            }
        }
        if ($nbt->hasTag("gold", StringTag::class)) {
            $cost = $nbt->getTagValue("gold", StringTag::class);
            if ($player->getInventory()->contains(Item::get(266, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(266, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.06);
            }
        }
        if ($nbt->hasTag("emerald", StringTag::class)) {
            $cost = $nbt->getTagValue("emerald", StringTag::class);
            if ($player->getInventory()->contains(Item::get(388, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(388, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.05);
            }
        }
        if ($nbt->hasTag("coal", StringTag::class)) {
            $cost = $nbt->getTagValue("coal", StringTag::class);
            if ($player->getInventory()->contains(Item::get(263, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(263, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.02);
            }
        }
        if ($nbt->hasTag("redstone", StringTag::class)) {
            $cost = $nbt->getTagValue("redstone", StringTag::class);
            if ($player->getInventory()->contains(Item::get(331, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(331, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.02);
            }
        }
        if ($nbt->hasTag("pearl", StringTag::class)) {
            $cost = $nbt->getTagValue("pearl", StringTag::class);
            if ($player->getInventory()->contains(Item::get(368, 0, 16))) {
                $player->getInventory()->removeItem(Item::get(368, 0, 16));
                $this->plugin->addMoney($player->getName(), 0.01);
            }
        }
        if ($nbt->hasTag("apple", StringTag::class)) {
            $cost = $nbt->getTagValue("apple", StringTag::class);
            if ($player->getInventory()->contains(Item::get(260, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(260, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.02);
            }
        }
        if ($nbt->hasTag("bookshelf", StringTag::class)) {
            $cost = $nbt->getTagValue("bookshelf", StringTag::class);
            if ($player->getInventory()->contains(Item::get(47, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(47, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.02);
            }
        }
        if ($nbt->hasTag("obsidian", StringTag::class)) {
            $cost = $nbt->getTagValue("obsidian", StringTag::class);
            if ($player->getInventory()->contains(Item::get(49, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(49, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.02);
            }
        }
        if ($nbt->hasTag("dirt", StringTag::class)) {
            $cost = $nbt->getTagValue("dirt", StringTag::class);
            if ($player->getInventory()->contains(Item::get(3, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(3, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.01);
                $this->plugin->addSpendMoney($player->getName(), 0.01);
            }
        }
        if ($nbt->hasTag("sand", StringTag::class)) {
            $cost = $nbt->getTagValue("sand", StringTag::class);
            if ($player->getInventory()->contains(Item::get(12, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(12, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.01);
            }
        }
        if ($nbt->hasTag("birch", StringTag::class)) {
            $cost = $nbt->getTagValue("birch", StringTag::class);
            if ($player->getInventory()->contains(Item::get(17, 2, 64))) {
                $player->getInventory()->removeItem(Item::get(17, 2, 64));
                $this->plugin->addMoney($player->getName(), 0.03);
            }
        }
        if ($nbt->hasTag("dark", StringTag::class)) {
            $cost = $nbt->getTagValue("dark", StringTag::class);
            if ($player->getInventory()->contains(Item::get(162, 1, 64))) {
                $player->getInventory()->removeItem(Item::get(162, 1, 64));
                $this->plugin->addMoney($player->getName(), 0.03);
            }
        }
        if ($nbt->hasTag("oak", StringTag::class)) {
            $cost = $nbt->getTagValue("oak", StringTag::class);
            if ($player->getInventory()->contains(Item::get(17, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(17, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.03);
            }
        }
        if ($nbt->hasTag("cactus", StringTag::class)) {
            $cost = $nbt->getTagValue("cactus", StringTag::class);
            if ($player->getInventory()->contains(Item::get(81, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(81, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.02);
            }
        }
        if ($nbt->hasTag("beacon", StringTag::class)) {
            $cost = $nbt->getTagValue("beacon", StringTag::class);
            if ($player->getInventory()->contains(Item::get(138, 0, 1))) {
                $player->getInventory()->removeItem(Item::get(138, 0, 1));
                $this->plugin->addMoney($player->getName(), 40);
            }
        }
        if ($nbt->hasTag("head", StringTag::class)) {
            $cost = $nbt->getTagValue("head", StringTag::class);
            if ($player->getInventory()->contains(Item::get(397, 3, 1))) {
                $player->getInventory()->removeItem(Item::get(397, 3, 1));
                $this->plugin->addMoney($player->getName(), 0.05);
            }
        }
        if ($nbt->hasTag("tnt", StringTag::class)) {
            $cost = $nbt->getTagValue("tnt", StringTag::class);
            if ($player->getInventory()->contains(Item::get(46, 0, 64))) {
                $player->getInventory()->removeItem(Item::get(46, 0, 64));
                $this->plugin->addMoney($player->getName(), 0.05);
            }
        }
        if ($nbt->hasTag("rzucak", StringTag::class)) {
            $cost = $nbt->getTagValue("rzucak", StringTag::class);
            if ($player->getInventory()->contains(Item::get(52, 0, 1))) {
                $player->getInventory()->removeItem(Item::get(52, 0, 1));
                $this->plugin->addMoney($player->getName(), 5);
            }
        }
        if ($nbt->hasTag("helm1", StringTag::class)) {
            $cost = $nbt->getTagValue("helm1", StringTag::class);
            $item = Item::get(Item::DIAMOND_HELMET, 0, 1);
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
            if ($player->getInventory()->contains($item)) {
                $player->getInventory()->removeItem($item);
                $this->plugin->addMoney($player->getName(), 0.05);
            }
        }
        if ($nbt->hasTag("zbroja1", StringTag::class)) {
            $cost = $nbt->getTagValue("zbroja1", StringTag::class);
            $item = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
            if ($player->getInventory()->contains($item)) {
                $player->getInventory()->removeItem($item);
                $this->plugin->addMoney($player->getName(), 0.05);
            }
        }
        if ($nbt->hasTag("spodnie1", StringTag::class)) {
            $cost = $nbt->getTagValue("spodnie1", StringTag::class);
            $item = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
            if ($player->getInventory()->contains($item)) {
                $player->getInventory()->removeItem($item);
                $this->plugin->addMoney($player->getName(), 0.05);
            }
        }
        if ($nbt->hasTag("buty1", StringTag::class)) {
            $cost = $nbt->getTagValue("buty1", StringTag::class);
            $item = Item::get(Item::DIAMOND_BOOTS, 0, 1);
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
            if ($player->getInventory()->contains($item)) {
                $player->getInventory()->removeItem($item);
                $this->plugin->addMoney($player->getName(), 0.05);
            }
        }
        if ($nbt->hasTag("kilof1", StringTag::class)) {
            $cost = $nbt->getTagValue("kilof1", StringTag::class);
            $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 6));
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
            $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FORTUNE), 3));
            if ($player->getInventory()->contains($item)) {
                $player->getInventory()->removeItem($item);
                $this->plugin->addMoney($player->getName(), 15);
            }
        }
        if ($nbt->hasTag("helm", StringTag::class)) {
            $cost = $nbt->getTagValue("helm", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                $item = Item::get(Item::DIAMOND_HELMET, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.50);
                $this->plugin->addSpendMoney($player->getName(), 0.50);
            }
        }
        if ($nbt->hasTag("zbroja", StringTag::class)) {
            $cost = $nbt->getTagValue("zbroja", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                $item = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.50);
                $this->plugin->addSpendMoney($player->getName(), 0.50);
            }
        }
        if ($nbt->hasTag("spodnie", StringTag::class)) {
            $cost = $nbt->getTagValue("spodnie", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                $item = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.50);
                $this->plugin->addSpendMoney($player->getName(), 0.50);
            }
        }
        if ($nbt->hasTag("buty", StringTag::class)) {
            $cost = $nbt->getTagValue("buty", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                $item = Item::get(Item::DIAMOND_BOOTS, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.50);
                $this->plugin->addSpendMoney($player->getName(), 0.50);
            }
        }
        if ($nbt->hasTag("miecz", StringTag::class)) {
            $cost = $nbt->getTagValue("miecz", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 5));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("kilof", StringTag::class)) {
            $cost = $nbt->getTagValue("kilof", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("siekiera", StringTag::class)) {
            $cost = $nbt->getTagValue("siekiera", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::DIAMOND_AXE, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("lopata", StringTag::class)) {
            $cost = $nbt->getTagValue("lopata", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::DIAMOND_SHOVEL, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("kox", StringTag::class)) {
            $cost = $nbt->getTagValue("kox", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 2) {
                $item = Item::get(466, 0, 1);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 2);
                $this->plugin->addSpendMoney($player->getName(), 2);
            }
        }
        if ($nbt->hasTag("refil", StringTag::class)) {
            $cost = $nbt->getTagValue("refil", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("perla", StringTag::class)) {
            $cost = $nbt->getTagValue("perla", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::ENDER_PEARL, 0, 16);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("bow", StringTag::class)) {
            $cost = $nbt->getTagValue("bow", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::BOW, 0, 1);
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 5));
                $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FLAME), 1));
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("strzaly", StringTag::class)) {
            $cost = $nbt->getTagValue("strzaly", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(Item::ARROW, 0, 16);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("tntblock", StringTag::class)) {
            $cost = $nbt->getTagValue("tntblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::TNT, 0, 16);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("rzucane", StringTag::class)) {
            $cost = $nbt->getTagValue("rzucane", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 20.00) {
                $item = Item::get(Item::MOB_SPAWNER, 0, 1);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 20);
                $this->plugin->addSpendMoney($player->getName(), 20);
            }
        }
        if ($nbt->hasTag("zapalniczka", StringTag::class)) {
            $cost = $nbt->getTagValue("zapalniczka", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(Item::FLINT_AND_STEEL, 0, 1);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("nick", StringTag::class)) {
            $cost = $nbt->getTagValue("nick", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 500) {
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "usluga kolorowy " . $player->getName() . "");
                $this->plugin->reduceMoney($player->getName(), 500);
                $this->plugin->addSpendMoney($player->getName(), 500);
            }
        }
        if ($nbt->hasTag("turbo", StringTag::class)) {
            $cost = $nbt->getTagValue("turbo", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 50) {
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "drop turbo dodaj " . $player->getName() . " 5m");
                $this->plugin->reduceMoney($player->getName(), 50);
                $this->plugin->addSpendMoney($player->getName(), 50);
            }
        }
        if ($nbt->hasTag("pc", StringTag::class)) {
            $cost = $nbt->getTagValue("pc", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 50) {
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 1 " . $player->getName() . "");
                $this->plugin->reduceMoney($player->getName(), 50);
                $this->plugin->addSpendMoney($player->getName(), 50);
            }
        }
        if ($nbt->hasTag("emeraldblock", StringTag::class)) {
            $cost = $nbt->getTagValue("emeraldblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 4) {
                $item = Item::get(Item::EMERALD_BLOCK, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 4);
                $this->plugin->addSpendMoney($player->getName(), 4);
            }
        }
        if ($nbt->hasTag("diamondblock", StringTag::class)) {
            $cost = $nbt->getTagValue("diamondblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 5) {
                $item = Item::get(Item::DIAMOND_BLOCK, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 5);
                $this->plugin->addSpendMoney($player->getName(), 5);
            }
        }
        if ($nbt->hasTag("ironblock", StringTag::class)) {
            $cost = $nbt->getTagValue("ironblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 4.00) {
                $item = Item::get(Item::IRON_BLOCK, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 4.00);
                $this->plugin->addSpendMoney($player->getName(), 4.00);
            }
        }
        if ($nbt->hasTag("goldblock", StringTag::class)) {
            $cost = $nbt->getTagValue("goldblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 8) {
                $item = Item::get(Item::GOLD_BLOCK, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 8);
                $this->plugin->addSpendMoney($player->getName(), 8);
            }
        }
        if ($nbt->hasTag("obsidianblock", StringTag::class)) {
            $cost = $nbt->getTagValue("obsidianblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(Item::OBSIDIAN, 0, 64);
                $item->setCustomName("§8§l» §bBlok Obsydianu");
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("stonebricksblock", StringTag::class)) {
            $cost = $nbt->getTagValue("stonebricksblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::STONE_BRICKS, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("brickblock", StringTag::class)) {
            $cost = $nbt->getTagValue("brickblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(Item::BRICK_BLOCK, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("glassblock", StringTag::class)) {
            $cost = $nbt->getTagValue("glassblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(Item::GLASS, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("coalblock", StringTag::class)) {
            $cost = $nbt->getTagValue("coalblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 4) {
                $item = Item::get(Item::COAL_BLOCK, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 4);
                $this->plugin->addSpendMoney($player->getName(), 4);
            }
        }
        if ($nbt->hasTag("grassblock", StringTag::class)) {
            $cost = $nbt->getTagValue("grassblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(Item::GRASS, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("slimeblock", StringTag::class)) {
            $cost = $nbt->getTagValue("slimeblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(Item::SLIME_BLOCK, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("oaklogblock", StringTag::class)) {
            $cost = $nbt->getTagValue("oaklogblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(17, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("iceblock", StringTag::class)) {
            $cost = $nbt->getTagValue("iceblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(79, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("stoneblock", StringTag::class)) {
            $cost = $nbt->getTagValue("stoneblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(1, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("sprucelogblock", StringTag::class)) {
            $cost = $nbt->getTagValue("sprucelogblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(17, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("birchlogblock", StringTag::class)) {
            $cost = $nbt->getTagValue("birchlogblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(17, 2, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("junglelogblock", StringTag::class)) {
            $cost = $nbt->getTagValue("junglelogblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(17, 3, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("acacialogblock", StringTag::class)) {
            $cost = $nbt->getTagValue("acacialogblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(162, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("darkoaklogblock", StringTag::class)) {
            $cost = $nbt->getTagValue("darkoaklogblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(162, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("leavesblock", StringTag::class)) {
            $cost = $nbt->getTagValue("leavesblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(18, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("snowblock", StringTag::class)) {
            $cost = $nbt->getTagValue("snowblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(80, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("netherbricksblock", StringTag::class)) {
            $cost = $nbt->getTagValue("netherbricksblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(112, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.25);
                $this->plugin->addSpendMoney($player->getName(), 0.25);
            }
        }
        if ($nbt->hasTag("heybalesblock", StringTag::class)) {
            $cost = $nbt->getTagValue("heybalesblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                $item = Item::get(170, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("netherbricksblockxd", StringTag::class)) {
            $cost = $nbt->getTagValue("netherbricksblockxd", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(112, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("rednetherbricksblock", StringTag::class)) {
            $cost = $nbt->getTagValue("rednetherbricksblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(215, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("quartzblock", StringTag::class)) {
            $cost = $nbt->getTagValue("quartzblock", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(155, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool", StringTag::class)) {
            $cost = $nbt->getTagValue("wool", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool1", StringTag::class)) {
            $cost = $nbt->getTagValue("wool1", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool2", StringTag::class)) {
            $cost = $nbt->getTagValue("wool2", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool3", StringTag::class)) {
            $cost = $nbt->getTagValue("wool3", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 3, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool4", StringTag::class)) {
            $cost = $nbt->getTagValue("wool4", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 4, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool5", StringTag::class)) {
            $cost = $nbt->getTagValue("wool5", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 5, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool6", StringTag::class)) {
            $cost = $nbt->getTagValue("wool6", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 6, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool7", StringTag::class)) {
            $cost = $nbt->getTagValue("wool7", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 7, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool8", StringTag::class)) {
            $cost = $nbt->getTagValue("wool8", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 8, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool9", StringTag::class)) {
            $cost = $nbt->getTagValue("wool9", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 9, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool10", StringTag::class)) {
            $cost = $nbt->getTagValue("wool10", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 10, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool11", StringTag::class)) {
            $cost = $nbt->getTagValue("wool11", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 11, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool12", StringTag::class)) {
            $cost = $nbt->getTagValue("wool12", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 12, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool13", StringTag::class)) {
            $cost = $nbt->getTagValue("wool13", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 13, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool14", StringTag::class)) {
            $cost = $nbt->getTagValue("wool14", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 14, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("wool15", StringTag::class)) {
            $cost = $nbt->getTagValue("wool15", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(35, 15, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete1", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete1", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete2", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete2", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete3", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete3", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 3, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete4", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete4", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 4, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete5", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete5", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 5, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete6", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete6", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 6, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete7", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete7", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 7, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete8", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete8", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 8, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete9", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete9", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 9, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete10", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete10", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 10, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete11", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete11", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 11, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete12", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete12", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 12, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete13", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete13", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 13, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete14", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete14", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 14, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Concrete15", StringTag::class)) {
            $cost = $nbt->getTagValue("Concrete15", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(236, 15, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota1", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota1", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota2", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota2", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 1, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota3", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota3", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 3, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota4", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota4", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 4, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota5", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota5", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 5, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota6", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota6", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 6, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota7", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota7", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 7, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota8", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota8", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 8, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota9", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota9", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 9, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota10", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota10", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 10, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota11", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota11", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 11, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota12", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota12", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 12, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota13", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota13", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 13, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota14", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota14", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 14, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("Terracota15", StringTag::class)) {
            $cost = $nbt->getTagValue("Terracota15", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(159, 15, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("redstonelamp", StringTag::class)) {
            $cost = $nbt->getTagValue("redstonelamp", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(124, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("liany", StringTag::class)) {
            $cost = $nbt->getTagValue("liany", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(106, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("netherrack", StringTag::class)) {
            $cost = $nbt->getTagValue("netherrack", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(87, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("redsandstone", StringTag::class)) {
            $cost = $nbt->getTagValue("redsandstone", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(179, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        if ($nbt->hasTag("endstonebricks", StringTag::class)) {
            $cost = $nbt->getTagValue("endstonebricks", StringTag::class);
            if ($this->plugin->getMoney($player->getName()) >= 0.10) {
                $item = Item::get(206, 0, 64);
                $player->getInventory()->addItem($item);
                $this->plugin->reduceMoney($player->getName(), 0.10);
                $this->plugin->addSpendMoney($player->getName(), 0.10);
            }
        }
        return true;
    }

    public function addContents(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        #$inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        #$inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::DIAMOND, 0, 1);
        $item->setCustomName("§8§l» §bKup itemy");
        $item->setLore(["§l ",
            "§8§l» §aKlinij, aby kupic itemy"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "shop"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(Item::EMERALD, 0, 1);
        $item->setCustomName("§8§l» §bSprzedaj itemy");
        $item->setLore(["§l ",
            "§8§l» §aKlinij, aby sprzedac itemy"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "sell"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);
    }

    public function addShop(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        $inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        $inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        $inv->setItem(15, $item);
        #$inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        #$inv->setItem(30, $item);
        $inv->setItem(31, $item);
        #$inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bZbroje");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby zakupic czesci zbroji"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "sety"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bNarzedzia");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby zakupic narzedzia"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "narzedzia"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(466, 0, 1);
        $item->setCustomName("§8§l» §bKoxy, refy, perly");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby zakupic koxy, perly i refy"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "limity"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::TNT, 0, 1);
        $item->setCustomName("§8§l» §bPrzebijanie");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby zakupic rzeczy potrzebne do przebijania"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "przebijanie"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do menu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do menu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "back"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);

        $item = Item::get(Item::EMERALD_BLOCK, 0, 1);
        $item->setCustomName("§8§l» §bBloki");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby zakupic bloki"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "bloki"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(403, 0, 1);
        $item->setCustomName("§8§l» §bDodatki");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby zakupic dodatki na serwerze"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "dodatki"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);
    }

    public function addSell()
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        #$inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        #$inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        #$inv->setItem(15, $item);
        #$inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        #$inv->setItem(19, $item);
        #$inv->setItem(20, $item);
        #$inv->setItem(21, $item);
        #$inv->setItem(22, $item);
        #$inv->setItem(23, $item);
        #$inv->setItem(24, $item);
        #$inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        #$inv->setItem(28, $item);
        #$inv->setItem(29, $item);
        #$inv->setItem(30, $item);
        #$inv->setItem(31, $item);
        #$inv->setItem(32, $item);
        #$inv->setItem(33, $item);
        #$inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        #$inv->setItem(37, $item);
        #$inv->setItem(38, $item);
        #$inv->setItem(39, $item);
        #$inv->setItem(40, $item);
        #$inv->setItem(41, $item);
        #$inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::DIAMOND, 0, 64);
        $item->setCustomName("§8§l» §b64 Diamenty");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.04$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("diamond"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::IRON_INGOT, 0, 64);
        $item->setCustomName("§8§l» §b64 Zelaza");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.03$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("iron"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::GOLD_INGOT, 0, 64);
        $item->setCustomName("§8§l» §b64 Zlota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.06$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("gold"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::EMERALD, 0, 64);
        $item->setCustomName("§8§l» §b64 Emeraldy");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.05$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("emerald"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::REDSTONE, 0, 64);
        $item->setCustomName("§8§l» §b64 Redstone");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.02$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("redstone"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::COAL, 0, 64);
        $item->setCustomName("§8§l» §b64 Wegla");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.02$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("coal"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 16);
        $item->setCustomName("§8§l» §b16 Perel");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.01$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("pearl"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(Item::APPLE, 0, 64);
        $item->setCustomName("§8§l» §b64 Jablka");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.02$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("apple"));
        $item->setNamedTag($nbt);
        $inv->setItem(19, $item);

        $item = Item::get(Item::BOOKSHELF, 0, 64);
        $item->setCustomName("§8§l» §b64 Polek z ksiazkami");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.02$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("bookshelf"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(Item::OBSIDIAN, 0, 64);
        $item->setCustomName("§8§l» §b64 Obsydianu");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.02$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("obsidian"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::COBBLESTONE, 0, 64);
        $item->setCustomName("§8§l» §b64 Cobblestone");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.01$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("cobblestone"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(Item::DIRT, 0, 64);
        $item->setCustomName("§8§l» §b64 Dirta");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.01$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("dirt"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::SAND, 0, 64);
        $item->setCustomName("§8§l» §b64 Piasku");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.01$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("sand"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(17, 2, 64);
        $item->setCustomName("§8§l» §b64 Brzozowego drzewa");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.03$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("birch"));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(162, 1, 64);
        $item->setCustomName("§8§l» §b64 Ciemnego drzewa");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.03$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("dark"));
        $item->setNamedTag($nbt);
        $inv->setItem(28, $item);

        $item = Item::get(17, 0, 64);
        $item->setCustomName("§8§l» §b64 Zwyklego drzewa");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.03$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("oak"));
        $item->setNamedTag($nbt);
        $inv->setItem(29, $item);

        $item = Item::get(81, 0, 64);
        $item->setCustomName("§8§l» §b64 Kaktusy");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.02$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("cactus"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(138, 0, 1);
        $item->setCustomName("§8§l» §bBeacon");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b40.00$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("beacon"));
        $item->setNamedTag($nbt);
        $inv->setItem(31, $item);

        $item = Item::get(46, 0, 1);
        $item->setCustomName("§8§l» §b64 TNT");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.05$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("tnt"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(52, 0, 1);
        $item->setCustomName("§8§l» §bRzucak");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b5.00$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("rzucak"));
        $item->setNamedTag($nbt);
        $inv->setItem(33, $item);

        $item = Item::get(Item::MOB_HEAD, 3, 1);
        $item->setCustomName("§8§l» §bGlowa Gracza");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.05$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("head"));
        $item->setNamedTag($nbt);
        $inv->setItem(34, $item);

        $item = Item::get(384, 0, 1);
        $item->setCustomName("§8§l» §b100 LVL EXPA");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b1.00$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("exp"));
        $item->setNamedTag($nbt);
        $inv->setItem(37, $item);

        $item = Item::get(Item::DIAMOND_HELMET, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowy helm 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.05$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("helm1"));
        $item->setNamedTag($nbt);
        $inv->setItem(38, $item);

        $item = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowa zbroja 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.05$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("zbroja1"));
        $item->setNamedTag($nbt);
        $inv->setItem(39, $item);

        $item = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowe spodnie 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.05$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("spodnie1"));
        $item->setNamedTag($nbt);
        $inv->setItem(40, $item);

        $item = Item::get(Item::DIAMOND_BOOTS, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowe buty 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.05$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("buty1"));
        $item->setNamedTag($nbt);
        $inv->setItem(41, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 6));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FORTUNE), 3));
        $item->setCustomName("§8§l» §bKilof 6/3/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b15$",
            "§8§l» §aKliknij, aby sprzedac"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("kilof1"));
        $item->setNamedTag($nbt);
        $inv->setItem(42, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do menu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do menu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "back"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);

    }

    public function addSety(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        $inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        $inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        $inv->setItem(15, $item);
        #$inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::DIAMOND_HELMET, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowy helm 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.50$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("helm"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowa zbroja 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.50$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("zbroja", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowe spodnie 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.50$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("spodnie", "64"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::DIAMOND_BOOTS, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowe buty 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.50$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("buty"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do menu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "shop"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);
    }

    public function addNarzedzia(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        $inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        $inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        $inv->setItem(15, $item);
        #$inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        #$inv->setItem(30, $item);
        $inv->setItem(31, $item);
        #$inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
        $item->setCustomName("§8§l» §bDiamentowy miecz 5/2");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("miecz"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowy kilof 5/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("kilof"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::DIAMOND_AXE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowa siekiera 5/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("siekiera"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::DIAMOND_SHOVEL, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§8§l» §bDiamentowa lopata 5/3");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("lopata", "32"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(Item::BOW, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FLAME), 1));
        $item->setCustomName("§8§l» §bLUK 5/1");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("bow"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(Item::ARROW, 0, 16);
        $item->setCustomName("§8§l» §b16 Strzal");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("strzaly"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "shop"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);
    }

    public function addLimity(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        #$inv->setItem(11, $item);
        $inv->setItem(12, $item);
        #$inv->setItem(13, $item);
        $inv->setItem(14, $item);
        #$inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(466, 0, 1);
        $item->setCustomName("§8§l» §bEnchantowane zlote jablko");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b2.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("kox"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName("§8§l» §bZlote jablko");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("refil"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 16);
        $item->setCustomName("§8§l» §b16 Ender Perel");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("perla"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "shop"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);
    }

    public function addPrzebijanie(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        #$inv->setItem(11, $item);
        $inv->setItem(12, $item);
        #$inv->setItem(13, $item);
        $inv->setItem(14, $item);
        #$inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::TNT, 0, 16);
        $item->setCustomName("§8§l» §b16 TNT");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.25$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("tntblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::MOB_SPAWNER, 0, 1);
        $item->setCustomName("§8§l» §bRzucane TNT");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b20.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("rzucane"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::FLINT_AND_STEEL, 0, 1);
        $item->setCustomName("§8§l» §bZapalniczka");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("zapalniczka"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "shop"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);
    }

    public function addBloki(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::EMERALD_BLOCK, 0, 64);
        $item->setCustomName("§8§l» §b64 Emerald Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b4.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("emeraldblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::DIAMOND_BLOCK, 0, 64);
        $item->setCustomName("§8§l» §b64 Diamond Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b5.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("diamondblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::IRON_BLOCK, 0, 64);
        $item->setCustomName("§8§l» §b64 Iron Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b4.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("ironblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::GOLD_BLOCK, 0, 64);
        $item->setCustomName("§8§l» §b64 Gold Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b8.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("goldblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::OBSIDIAN, 0, 64);
        $item->setCustomName("§8§l» §b64 Obsidian");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("obsidianblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(Item::GLASS, 0, 64);
        $item->setCustomName("§8§l» §b64 Glass");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("glassblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::STONE_BRICKS, 0, 64);
        $item->setCustomName("§8§l» §b64 Stone Bricks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("stonebricksblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(Item::BRICK_BLOCK, 0, 64);
        $item->setCustomName("§8§l» §b64 Bricks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("brickblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(19, $item);

        $item = Item::get(Item::COAL_BLOCK, 0, 64);
        $item->setCustomName("§8§l» §b64 Coal Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b4.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("coalblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::GRASS, 0, 64);
        $item->setCustomName("§8§l» §b64 Grass");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("grassblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(80, 0, 64);
        $item->setCustomName("§8§l» §b64 Snow Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("snowblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(Item::ICE, 0, 64);
        $item->setCustomName("§8§l» §b64 Ice Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("iceblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::SLIME_BLOCK, 0, 64);
        $item->setCustomName("§8§l» §b64 Slime Blocks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("slimeblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(Item::BEACON, 0, 1);
        $item->setCustomName("§8§l» §b1 Beacon");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b200$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("beaconblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(124, 0, 64);
        $item->setCustomName("§8§l» §b64 Redstone Lamp");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("redstonelamp"));
        $item->setNamedTag($nbt);
        $inv->setItem(28, $item);

        $item = Item::get(Item::STONE, 0, 64);
        $item->setCustomName("§8§l» §b64 STONE");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("stoneblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(29, $item);

        $item = Item::get(215, 0, 64);
        $item->setCustomName("§8§l» §b64 Red Nether Bricks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("rednetherbricksblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(18, 0, 64);
        $item->setCustomName("§8§l» §b64 Leaves");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("leavesblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(112, 0, 64);
        $item->setCustomName("§8§l» §b64 Nether Brick");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("netherbricksblockxd"));
        $item->setNamedTag($nbt);
        $inv->setItem(33, $item);

        $item = Item::get(87, 0, 64);
        $item->setCustomName("§8§l» §b64 Netherrack");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("netherrack"));
        $item->setNamedTag($nbt);
        $inv->setItem(34, $item);

        $item = Item::get(155, 0, 64);
        $item->setCustomName("§8§l» §b64 Quartz");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("quartzblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(31, $item);

        $item = Item::get(106, 0, 64);
        $item->setCustomName("§8§l» §b64 Vines");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("liany"));
        $item->setNamedTag($nbt);
        $inv->setItem(37, $item);

        $item = Item::get(179, 0, 64);
        $item->setCustomName("§8§l» §b64 Red Sandstone");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("redsandstone"));
        $item->setNamedTag($nbt);
        $inv->setItem(38, $item);

        $item = Item::get(206, 0, 64);
        $item->setCustomName("§8§l» §b64 End Stone Bricks");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("endstonebricks"));
        $item->setNamedTag($nbt);
        $inv->setItem(39, $item);

        $item = Item::get(159, 0, 1);
        $item->setCustomName("§8§l» §bTerracota");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby otworzyc menu z glina"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "terracota"));
        $item->setNamedTag($nbt);
        $inv->setItem(40, $item);

        $item = Item::get(236, 0, 1);
        $item->setCustomName("§8§l» §bConcrete");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby otworzyc menu z betonem"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "beton"));
        $item->setNamedTag($nbt);
        $inv->setItem(41, $item);

        $item = Item::get(Item::WOOL, 0, 1);
        $item->setCustomName("§8§l» §bWool");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby otworzyc menu z welna"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "welna"));
        $item->setNamedTag($nbt);
        $inv->setItem(42, $item);

        $item = Item::get(17, 0, 1);
        $item->setCustomName("§8§l» §bDrzewa");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby otworzyc menu z drzewami"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "drzewa"));
        $item->setNamedTag($nbt);
        $inv->setItem(43, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "shop"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);

    }

    public
    function addDodatki(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        #$inv->setItem(11, $item);
        $inv->setItem(12, $item);
        #$inv->setItem(13, $item);
        $inv->setItem(14, $item);
        #$inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(403, 0, 1);
        $item->setCustomName("§8§l» §bTurboDrop 5 minut");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b50.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("turbo"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(146, 0, 1);
        $item->setCustomName("§8§l» §b1 Premium Case");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b50.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("pc"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(403, 0, 1);
        $item->setCustomName("§8§l» §bKolorowy nick");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b500.00$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("nick"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "shop"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);
    }

    public function addDrzewa(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        #$inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        #$inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        #$inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(17, 1, 64);
        $item->setCustomName("§8§l» §b64 Spruce Log");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("sprucelogblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(17, 0, 64);
        $item->setCustomName("§8§l» §b64 Oak Log");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("oaklogblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(17, 2, 64);
        $item->setCustomName("§8§l» §b64 Birch Log");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("birchlogblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(17, 3, 64);
        $item->setCustomName("§8§l» §b64 Jungle Log");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("junglelogblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(162, 0, 64);
        $item->setCustomName("§8§l» §b64 Acacia Log");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("acacialogblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(162, 1, 64);
        $item->setCustomName("§8§l» §b64 Dark Oak Log");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("darkoaklogblock"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "bloki"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);
    }

    public function addWelna(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "bloki"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);

        $item = Item::get(Item::WOOL, 0, 64);
        $item->setCustomName("§8§l» §bWhite Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::WOOL, 1, 64);
        $item->setCustomName("§8§l» §bOrange Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool1"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::WOOL, 2, 64);
        $item->setCustomName("§8§l» §bMagenta Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool2"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::WOOL, 3, 64);
        $item->setCustomName("§8§l» §bLight Blue Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool3"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::WOOL, 4, 64);
        $item->setCustomName("§8§l» §bYellow Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool4"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::WOOL, 5, 64);
        $item->setCustomName("§8§l» §bLime Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool5"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::WOOL, 6, 64);
        $item->setCustomName("§8§l» §bPink Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool6"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(Item::WOOL, 7, 64);
        $item->setCustomName("§8§l» §bGray Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool7"));
        $item->setNamedTag($nbt);
        $inv->setItem(19, $item);

        $item = Item::get(Item::WOOL, 8, 64);
        $item->setCustomName("§8§l» §bLight Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool8"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(Item::WOOL, 9, 64);
        $item->setCustomName("§8§l» §bCyan Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool9"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::WOOL, 10, 64);
        $item->setCustomName("§8§l» §bPurple Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool10"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(Item::WOOL, 11, 64);
        $item->setCustomName("§8§l» §bBlue Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool11"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::WOOL, 12, 64);
        $item->setCustomName("§8§l» §bBrown Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool12"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::WOOL, 13, 64);
        $item->setCustomName("§8§l» §bGreen Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool13"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(Item::WOOL, 14, 64);
        $item->setCustomName("§8§l» §bRed Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool14"));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(Item::WOOL, 15, 64);
        $item->setCustomName("§8§l» §bBlack Wool");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("wool15"));
        $item->setNamedTag($nbt);
        $inv->setItem(28, $item);
    }

    public function addBeton(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "bloki"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);

        $item = Item::get(236, 0, 64);
        $item->setCustomName("§8§l» §bWhite Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(236, 1, 64);
        $item->setCustomName("§8§l» §bOrange Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete1"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(236, 2, 64);
        $item->setCustomName("§8§l» §bMagenta Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete2"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(236, 3, 64);
        $item->setCustomName("§8§l» §bLight Blue Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete3"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(236, 4, 64);
        $item->setCustomName("§8§l» §bYellow Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete4"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(236, 5, 64);
        $item->setCustomName("§8§l» §bLime Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete5"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(236, 6, 64);
        $item->setCustomName("§8§l» §bPink Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete6"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(236, 7, 64);
        $item->setCustomName("§8§l» §bGray Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete7"));
        $item->setNamedTag($nbt);
        $inv->setItem(19, $item);

        $item = Item::get(236, 8, 64);
        $item->setCustomName("§8§l» §bLight Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete8"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(236, 9, 64);
        $item->setCustomName("§8§l» §bCyan Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete9"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(236, 10, 64);
        $item->setCustomName("§8§l» §bPurple Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete10"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(236, 11, 64);
        $item->setCustomName("§8§l» §bBlue Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete11"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(236, 12, 64);
        $item->setCustomName("§8§l» §bBrown Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete12"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(236, 13, 64);
        $item->setCustomName("§8§l» §bGreen Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete13"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(236, 14, 64);
        $item->setCustomName("§8§l» §bRed Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete14"));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(236, 15, 64);
        $item->setCustomName("§8§l» §bBlack Concrete");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Concrete15"));
        $item->setNamedTag($nbt);
        $inv->setItem(28, $item);
    }

    public function addTerracota(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(21, $item);
        $inv->setItem(22, $item);
        $inv->setItem(23, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §bPowrot do sklepu");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby powrocic do sklepu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "bloki"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);

        $item = Item::get(159, 0, 64);
        $item->setCustomName("§8§l» §bWhite Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(159, 1, 64);
        $item->setCustomName("§8§l» §bOrange Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota1"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(159, 2, 64);
        $item->setCustomName("§8§l» §bMagenta Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota2"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(159, 3, 64);
        $item->setCustomName("§8§l» §bLight Blue Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota3"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(159, 4, 64);
        $item->setCustomName("§8§l» §bYellow Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota4"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(159, 5, 64);
        $item->setCustomName("§8§l» §bLime Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota5"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(159, 6, 64);
        $item->setCustomName("§8§l» §bPink Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota6"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(159, 7, 64);
        $item->setCustomName("§8§l» §bGray Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota7"));
        $item->setNamedTag($nbt);
        $inv->setItem(19, $item);

        $item = Item::get(159, 8, 64);
        $item->setCustomName("§8§l» §bLight Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota8"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(159, 9, 64);
        $item->setCustomName("§8§l» §bCyan Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota9"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(159, 11, 64);
        $item->setCustomName("§8§l» §bPurple Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota10"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(159, 11, 64);
        $item->setCustomName("§8§l» §bBlue Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota11"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(159, 12, 64);
        $item->setCustomName("§8§l» §bBrown Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota12"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(159, 13, 64);
        $item->setCustomName("§8§l» §bGreen Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota13"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(159, 14, 64);
        $item->setCustomName("§8§l» §bRed Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota14"));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(159, 15, 64);
        $item->setCustomName("§8§l» §bBlack Terracota");
        $item->setLore(["§l ",
            "§8§l» §7Cena: §b0.10$",
            "§8§l» §aKliknij, aby kupic"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("Terracota15"));
        $item->setNamedTag($nbt);
        $inv->setItem(28, $item);
    }

    public
    function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}