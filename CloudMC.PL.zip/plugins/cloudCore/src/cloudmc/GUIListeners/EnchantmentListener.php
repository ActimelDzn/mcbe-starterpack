<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\block\Block;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Armor;
use pocketmine\item\Axe;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Hoe;
use pocketmine\item\Item;
use pocketmine\item\Pickaxe;
use pocketmine\item\Shovel;
use pocketmine\item\Sword;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class EnchantmentListener
{

    public $plugin;
    public $menu;
    public $position;

    public function __construct(Main $pg, String $name, Vector3 $position)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
        $this->position = $position;
    }

    public function addToolsEnchantments()
    {
        $inv = $this->menu->getInventory();

        $inv->clearAll(false);
        $this->addContents();

        $position = $this->position;

        $pos1 = new Vector3($position->getX() - 2, $position->getY(), $position->getZ() + 2);
        $pos2 = new Vector3($position->getX() + 2, $position->getY() + 2, $position->getZ() - 2);
        $bookshelfs = $this->getBookshelfsCount($pos1, $pos2);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l§7Ilosc biblioteczek:§b " . $bookshelfs);

        $inv->setItem(10, $item);
        $inv->setItem(16, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bWydajnosc I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b5 XP LVL",
            "§l§7Wymagane biblioteczki: §b4",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("efficiency", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bWydajnosc II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b6",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("efficiency", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bWydajnosc III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b15 XP LVL",
            "§l§7Wymagane biblioteczki: §b8",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("efficiency", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bWydajnosc IV");
        $item->setLore(["§l ",
            "§l§7Koszt: §b20 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("efficiency", "4"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bWydajnosc V");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("efficiency", "5"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b5",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b20 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bSzczescie I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b5",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fortune", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bSzczescie II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b20 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fortune", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(31, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bSzczescie III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fortune", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bJedwabny Dotyk I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("silk_touch", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(40, $item);
    }

    public function addContents(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $position = $this->position;

        $pos1 = new Vector3($position->getX() - 2, $position->getY(), $position->getZ() + 2);
        $pos2 = new Vector3($position->getX() + 2, $position->getY() + 2, $position->getZ() - 2);
        $bookshelfs = $this->getBookshelfsCount($pos1, $pos2);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l§7Ilosc biblioteczek:§b " . $bookshelfs);
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);
    }

    private function getBookshelfsCount(Vector3 $pos1, Vector3 $pos2)
    {
        $i = 0;
        for ($x = min($pos1->getX(), $pos2->getX()); $x <= max($pos1->getX(), $pos2->getX()); $x++) {
            for ($y = min($pos1->getY(), $pos2->getY()); $y <= max($pos1->getY(), $pos2->getY()); $y++) {
                for ($z = min($pos1->getZ(), $pos2->getZ()); $z <= max($pos1->getZ(), $pos2->getZ()); $z++) {
                    if ($this->plugin->getServer()->getDefaultLevel()->getBlock(new Vector3($x, $y, $z))->getId() == Block::BOOKSHELF) {
                        $i++;
                    }
                }
            }
        }
        return $i;
    }

    public function addWeaponsEnchantments()
    {
        $inv = $this->menu->getInventory();

        $inv->clearAll(false);
        $this->addContents();

        $position = $this->position;

        $pos1 = new Vector3($position->getX() - 2, $position->getY(), $position->getZ() + 2);
        $pos2 = new Vector3($position->getX() + 2, $position->getY() + 2, $position->getZ() - 2);
        $bookshelfs = $this->getBookshelfsCount($pos1, $pos2);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l§7Ilosc biblioteczek:§b " . $bookshelfs);
        $inv->setItem(10, $item);
        $inv->setItem(16, $item);
        $inv->setItem(19, $item);
        $inv->setItem(20, $item);
        $inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(28, $item);
        $inv->setItem(31, $item);
        $inv->setItem(34, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOstrosc I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b5 XP LVL",
            "§l§7Wymagane biblioteczki: §b4",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("sharpness", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOstrosc II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b6",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("sharpness", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOstrosc III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b15 XP LVL",
            "§l§7Wymagane biblioteczki: §b8",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("sharpness", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOstrosc IV");
        $item->setLore(["§l ",
            "§l§7Koszt: §b20 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("sharpness", "4"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOstrosc V");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("sharpness", "5"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b5",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b20 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bZaklety Ogien I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b15 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fire_aspect", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(29, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bZaklety Ogien II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fire_aspect", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOdrzut I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b15 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("knockback", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOdrzut II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("knockback", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(33, $item);
    }

    public function addArmorEnchantments()
    {
        $inv = $this->menu->getInventory();

        $inv->clearAll(false);
        $this->addContents();

        $position = $this->position;

        $pos1 = new Vector3($position->getX() - 2, $position->getY(), $position->getZ() + 2);
        $pos2 = new Vector3($position->getX() + 2, $position->getY() + 2, $position->getZ() - 2);
        $bookshelfs = $this->getBookshelfsCount($pos1, $pos2);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l§7Ilosc biblioteczek:§b " . $bookshelfs);

        $inv->setItem(10, $item);
        $inv->setItem(13, $item);
        $inv->setItem(16, $item);
        $inv->setItem(10, $item);
        $inv->setItem(19, $item);
        $inv->setItem(22, $item);
        $inv->setItem(25, $item);
        $inv->setItem(28, $item);
        $inv->setItem(31, $item);
        $inv->setItem(34, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b5 XP LVL",
            "§l§7Wymagane biblioteczki: §b4",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("protection", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b6",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("protection", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b15 XP LVL",
            "§l§7Wymagane biblioteczki: §b8",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("protection", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona IV");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("protection", "4"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Ogniem I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b5 XP LVL",
            "§l§7Wymagane biblioteczki: §b4",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fireprotection", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Ogniem II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b6",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fireprotection", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Ogniem III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b15 XP LVL",
            "§l§7Wymagane biblioteczki: §b8",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fireprotection", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Ogniem IV");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fireprotection", "4"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Wybuchami I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b5 XP LVL",
            "§l§7Wymagane biblioteczki: §b4",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("blastprotection", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(29, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Wybuchami II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b6",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("blastprotection", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Wybuchami III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b15 XP LVL",
            "§l§7Wymagane biblioteczki: §b8",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("blastprotection", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bOchrona przed Wybuchami IV");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("blastprotection", "4"));
        $item->setNamedTag($nbt);
        $inv->setItem(33, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc I");
        $item->setLore(["§l ",
            "§l§7Koszt: §b10 XP LVL",
            "§l§7Wymagane biblioteczki: §b5",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(39, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc II");
        $item->setLore(["§l ",
            "§l§7Koszt: §b20 XP LVL",
            "§l§7Wymagane biblioteczki: §b10",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(40, $item);

        $item = Item::get(Item::ENCHANTED_BOOK, 0, 1);
        $item->setCustomName("§l§bNiezniszczalnosc III");
        $item->setLore(["§l ",
            "§l§7Koszt: §b30 XP LVL",
            "§l§7Wymagane biblioteczki: §b15",
            "§l§aKliknij, aby nadac enchant!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("unbreaking", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(41, $item);
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $hand = $player->getInventory()->getItemInHand();
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        $position = $this->position;
        $pos1 = new Vector3($position->getX() - 2, $position->getY(), $position->getZ() + 2);
        $pos2 = new Vector3($position->getX() + 2, $position->getY() + 2, $position->getZ() - 2);
        $bookshelfs = $this->getBookshelfsCount($pos1, $pos2);
        if ($player->getLevel()->getBlock($this->position)->getId() == Block::ENCHANTING_TABLE) {
            if ($hand instanceof Pickaxe or $hand instanceof Axe or $hand instanceof Hoe or $hand instanceof Shovel) {
                if ($nbt->hasTag("efficiency", StringTag::class)) {
                    $level = $nbt->getTagValue("efficiency", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 4) {
                            if ($player->getXpLevel() >= 5) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 5);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 5 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 6) {
                            if ($player->getXpLevel() >= 10) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 10);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 10 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 3) {
                        if ($bookshelfs >= 8) {
                            if ($player->getXpLevel() >= 15) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 15);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 15 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 4) {
                        if ($bookshelfs >= 10) {
                            if ($player->getXpLevel() >= 20) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 20);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 20 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 5) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
                if ($nbt->hasTag("fortune", StringTag::class)) {
                    $level = $nbt->getTagValue("fortune", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 5) {
                            if ($player->getXpLevel() >= 10) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FORTUNE), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 10);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 10 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 10) {
                            if ($player->getXpLevel() >= 20) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FORTUNE), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 20);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 20 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 3) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(18), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
                if ($nbt->hasTag("silk_touch", StringTag::class)) {
                    $level = $nbt->getTagValue("silk_touch", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SILK_TOUCH), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
            }
            if ($hand instanceof Sword) {
                if ($nbt->hasTag("sharpness", StringTag::class)) {
                    $level = $nbt->getTagValue("sharpness", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 4) {
                            if ($player->getXpLevel() >= 5) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 5);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 5 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 6) {
                            if ($player->getXpLevel() >= 10) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 10);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 10 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 3) {
                        if ($bookshelfs >= 8) {
                            if ($player->getXpLevel() >= 15) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 15);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 15 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 4) {
                        if ($bookshelfs >= 10) {
                            if ($player->getXpLevel() >= 20) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 20);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 20 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 5) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
                if ($nbt->hasTag("fire_aspect", StringTag::class)) {
                    $level = $nbt->getTagValue("fire_aspect", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 10) {
                            if ($player->getXpLevel() >= 15) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_ASPECT), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 15);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 15 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_ASPECT), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
                if ($nbt->hasTag("knockback", StringTag::class)) {
                    $level = $nbt->getTagValue("knockback", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 10) {
                            if ($player->getXpLevel() >= 15) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::KNOCKBACK), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 15);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 15 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::KNOCKBACK), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
            }
            if ($hand instanceof Armor) {
                if ($nbt->hasTag("protection", StringTag::class)) {
                    $level = $nbt->getTagValue("protection", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 4) {
                            if ($player->getXpLevel() >= 5) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 5);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 5 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 6) {
                            if ($player->getXpLevel() >= 10) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 10);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 10 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 3) {
                        if ($bookshelfs >= 8) {
                            if ($player->getXpLevel() >= 15) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 15);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 15 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 4) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
                if ($nbt->hasTag("fireprotection", StringTag::class)) {
                    $level = $nbt->getTagValue("fireprotection", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 4) {
                            if ($player->getXpLevel() >= 5) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 5);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 5 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 6) {
                            if ($player->getXpLevel() >= 10) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 10);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 10 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 3) {
                        if ($bookshelfs >= 8) {
                            if ($player->getXpLevel() >= 15) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 15);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 15 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 4) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
                if ($nbt->hasTag("blastprotection", StringTag::class)) {
                    $level = $nbt->getTagValue("blastprotection", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 4) {
                            if ($player->getXpLevel() >= 5) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::BLAST_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 5);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 5 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 6) {
                            if ($player->getXpLevel() >= 10) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::BLAST_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 10);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 10 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 3) {
                        if ($bookshelfs >= 8) {
                            if ($player->getXpLevel() >= 15) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::BLAST_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 15);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 15 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 4) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::BLAST_PROTECTION), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
            }
            if ($hand instanceof Pickaxe or $hand instanceof Axe or $hand instanceof Hoe or $hand instanceof Shovel or $hand instanceof Sword or $hand instanceof Armor) {
                if ($nbt->hasTag("unbreaking", StringTag::class)) {
                    $level = $nbt->getTagValue("unbreaking", StringTag::class);
                    if ($level == 1) {
                        if ($bookshelfs >= 5) {
                            if ($player->getXpLevel() >= 10) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 10);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 10 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 2) {
                        if ($bookshelfs >= 10) {
                            if ($player->getXpLevel() >= 20) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 20);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 20 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                    if ($level == 3) {
                        if ($bookshelfs >= 15) {
                            if ($player->getXpLevel() >= 30) {
                                $hand->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), $level));
                                $player->getInventory()->setItemInHand($hand);
                                $player->setXpLevel($player->getXpLevel() - 30);
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Potrzebujesz 30 poziomu, aby nadac ten enchant!", false));
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Wokol enchantu niema wystarczajacej ilosci bookshelfow, aby nadac enchant!", false));
                        }
                    }
                }
            }
            if ($itemTakenOut->getId() == Item::BOOKSHELF) {
                $this->addContents();
            }
        } else {
            $player->removeWindow($inventoryAction->getInventory());
        }
        return true;
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}