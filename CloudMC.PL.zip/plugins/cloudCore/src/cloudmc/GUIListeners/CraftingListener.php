<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class CraftingListener
{

    public $plugin;
    public $menu;

    public function __construct(Main $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        if ($itemTakenOut->getId() == Item::TOTEM) {
            if ($nbt->hasTag("page", StringTag::class)) {
                $page = $nbt->getTagValue("page", StringTag::class);
                $this->getPage($page + 1);
            }
            if ($nbt->hasTag("back", StringTag::class)) {
                $this->addDefaultContents();
            }
        }
        if ($itemTakenOut->getId() == Item::END_STONE) {
            if ($nbt->hasTag("stonefarm", StringTag::class)) {
                $type = $nbt->getTagValue("stonefarm", StringTag::class);
                if ($type == "1") {
                    if ($player->getInventory()->contains(Item::get(Item::COBBLESTONE, 0, 8)) &&
                        $player->getInventory()->contains(Item::get(Item::IRON_INGOT, 0, 1))) {
                        $player->getInventory()->removeItem(Item::get(Item::COBBLESTONE, 0, 8));
                        $player->getInventory()->removeItem(Item::get(Item::IRON_INGOT, 0, 1));
                        $this->plugin->addStoneFarm($player, 1, 1);
                    }
                } elseif ($type == "2") {
                    if ($player->getInventory()->contains(Item::get(Item::COBBLESTONE, 0, 8)) &&
                        $player->getInventory()->contains(Item::get(Item::DIAMOND, 0, 1))) {
                        $player->getInventory()->removeItem(Item::get(Item::COBBLESTONE, 0, 8));
                        $player->getInventory()->removeItem(Item::get(Item::DIAMOND, 0, 1));
                        $this->plugin->addStoneFarm($player, 1, 2);
                    }
                } elseif ($type == "3") {
                    if ($player->getInventory()->contains(Item::get(Item::COBBLESTONE, 0, 8)) &&
                        $player->getInventory()->contains(Item::get(Item::DIAMOND_PICKAXE, 0, 1))) {
                        $player->getInventory()->removeItem(Item::get(Item::COBBLESTONE, 0, 8));
                        $player->getInventory()->removeItem(Item::get(Item::DIAMOND_PICKAXE, 0, 1));
                        $this->plugin->addStoneFarm($player, 1, 3);
                    }
                }
            }
        }
        return true;
    }

    public function getPage(int $page)
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);
        if ($page == 1 or $page == 0) {
            $this->addDefaultContents();
        }
        if ($page == 2) {
            $item = Item::get(Item::COBBLESTONE, 0, 1);
            $item->setCustomName("§l§8» §b1x COBBLESTONE");
            $inv->setItem(10, $item);
            $inv->setItem(11, $item);
            $inv->setItem(12, $item);
            $inv->setItem(21, $item);
            $inv->setItem(30, $item);
            $inv->setItem(29, $item);
            $inv->setItem(28, $item);
            $inv->setItem(19, $item);

            $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
            $item->setCustomName("§l§8» §b1x DIAMENTOWY KILOF");
            $inv->setItem(20, $item);

            $item = Item::get(Item::END_STONE, 0, 1);
            $item->setCustomName("§l§8» §bSuperszybka Stoniarka");
            $item->setLore(["§l ",
                "§l§8» §7Czas odnowienia:§b 0.5s",
                "§l§8» §aKliknij, aby scraftowac!"]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("stonefarm", "3"));
            $item->setNamedTag($nbt);
            $inv->setItem(38, $item);

            $item = Item::get(Item::ENDER_CHEST, 0, 1);
            $item->setCustomName("§l§8» §bEnderchest");
            $item->setLore(["§l ",
                "§l§8» §aOtworz crafting, aby scraftowac ten przedmiot!"]);
            $inv->setItem(42, $item);

            $item = Item::get(Item::OBSIDIAN, 0, 1);
            $item->setCustomName("§l§8» §b1x OBSIDIAN");
            $inv->setItem(14, $item);
            $inv->setItem(23, $item);
            $inv->setItem(32, $item);
            $inv->setItem(33, $item);
            $inv->setItem(34, $item);
            $inv->setItem(25, $item);
            $inv->setItem(16, $item);
            $inv->setItem(15, $item);

            $item = Item::get(Item::ENDER_PEARL, 0, 1);
            $item->setCustomName("§l§8» §b1x PERLA");
            $inv->setItem(24, $item);

            $item = Item::get(Item::TOTEM, 0, 1);
            $item->setCustomName("§l§8» §bNastepna strona");
            $item->setLore(["§l§8» §aKliknij, aby otworzyc nastepna strone"]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("page", "2"));
            $item->setNamedTag($nbt);
            $inv->setItem(53, $item);

            $item = Item::get(Item::TOTEM, 0, 1);
            $item->setCustomName("§l§8» §bWroc na poczatek");
            $item->setLore(["§l§8» §aKliknij, aby wrocic na poczatek"]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("back", "true"));
            $item->setNamedTag($nbt);
            $inv->setItem(45, $item);
        }
        if ($page == 3) {
            $item = Item::get(Item::OBSIDIAN, 0, 1);
            $item->setCustomName("§l§8» §b1x OBSIDIAN");
            $inv->setItem(10, $item);
            $inv->setItem(11, $item);
            $inv->setItem(12, $item);
            $inv->setItem(21, $item);
            $inv->setItem(30, $item);
            $inv->setItem(29, $item);
            $inv->setItem(28, $item);
            $inv->setItem(19, $item);

            $item = Item::get(Item::DIAMOND, 0, 1);
            $item->setCustomName("§l§8» §b1x DIAMENT");
            $inv->setItem(20, $item);

            $item = Item::get(Item::IRON_ORE, 0, 1);
            $item->setCustomName("§l§8» §bBoyFarmer");
            $item->setLore(["§l ",
                "§l§8» §aOtworz crafting, aby scraftowac ten przedmiot!"]);
            $inv->setItem(38, $item);

            $item = Item::get(Item::STONE, 0, 1);
            $item->setCustomName("§l§8» §b1x STONE");
            $inv->setItem(14, $item);
            $inv->setItem(32, $item);
            $inv->setItem(33, $item);
            $inv->setItem(34, $item);
            $inv->setItem(16, $item);
            $inv->setItem(15, $item);

            $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
            $item->setCustomName("§l§8» §b1x DIAMOND");
            $inv->setItem(23, $item);
            $inv->setItem(25, $item);

            $item = Item::get(Item::DIAMOND, 0, 1);
            $item->setCustomName("§l§8» §b1x DIAMENTOWY KILOF");
            $inv->setItem(24, $item);

            $item = Item::get(Item::DIAMOND_ORE, 0, 1);
            $item->setCustomName("§l§8» §bKopaczFos");
            $item->setLore(["§l ",
                "§l§8» §aOtworz crafting, aby scraftowac ten przedmiot!"]);
            $inv->setItem(42, $item);

            $item = Item::get(Item::TOTEM, 0, 1);
            $item->setCustomName("§l§8» §bWroc na poczatek");
            $item->setLore(["§l§8» §aKliknij, aby wrocic na poczatek"]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("back", "true"));
            $item->setNamedTag($nbt);
            $inv->setItem(45, $item);
        }
    }

    public function addDefaultContents(): void
    {
        $inv = $this->menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(Item::COBBLESTONE, 0, 1);
        $item->setCustomName("§l§8» §b1x COBBLESTONE");
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(21, $item);
        $inv->setItem(30, $item);
        $inv->setItem(29, $item);
        $inv->setItem(28, $item);
        $inv->setItem(19, $item);

        $item = Item::get(Item::IRON_INGOT, 0, 1);
        $item->setCustomName("§l§8» §b1x ZELAZO");
        $inv->setItem(20, $item);

        $item = Item::get(Item::END_STONE, 0, 1);
        $item->setCustomName("§l§8» §bNormalna Stoniarka");
        $item->setLore(["§l ",
            "§l§8» §7Czas odnowienia:§b 2s",
            "§l§8» §aKliknij, aby scraftowac!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("stonefarm", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(38, $item);

        $item = Item::get(Item::COBBLESTONE, 0, 1);
        $item->setCustomName("§l§8» §b1x COBBLESTONE");
        $inv->setItem(14, $item);
        $inv->setItem(23, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(25, $item);
        $inv->setItem(16, $item);
        $inv->setItem(15, $item);


        $item = Item::get(Item::DIAMOND, 0, 1);
        $item->setCustomName("§l§8» §b1x DIAMENT");
        $inv->setItem(24, $item);

        $item = Item::get(Item::END_STONE, 0, 1);
        $item->setCustomName("§l§8» §bSzybka Stoniarka");
        $item->setLore(["§l ",
            "§l§8» §7Czas odnowienia:§b 1s",
            "§l§8» §aKliknij, aby scraftowac!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("stonefarm", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(42, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§8» §bNastepna strona");
        $item->setLore(["§l§8» §aKliknij, aby otworzyc nastepna strone"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("page", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);
    }
}