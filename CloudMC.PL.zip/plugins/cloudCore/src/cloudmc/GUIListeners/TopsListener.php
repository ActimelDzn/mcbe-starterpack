<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\scheduler\ClosureTask;

class TopsListener
{

    public $plugin;
    public $menu;
    public $target;
    public $cloudpoints;

    public function __construct(Main $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        if ($nbt->hasTag("menu", StringTag::class)) {
            if ($itemTakenOut->getId() == Item::MOB_HEAD) {
                if ($itemTakenOut->getDamage() == 3) {
                    $this->addTopPointsContents();
                } elseif ($itemTakenOut->getDamage() == 2) {
                    $this->addTopAssistsContents();
                } elseif ($itemTakenOut->getDamage() == 0) {
                    $this->addTopDeathsContents();
                }
            }
            if ($itemTakenOut->getId() == Item::DIAMOND_SWORD) {
                $this->addTopKillsContents();
            }
            if ($itemTakenOut->getId() == Item::CHEST) {
                $this->addTopPremiumContents();
            }
            if ($itemTakenOut->getId() == Item::DIAMOND_AXE) {
                $this->addTopMoneyContents();
            }
            if ($itemTakenOut->getId() == Item::GOLDEN_APPLE) {
                $this->addTopGoldenAppleContents();
            }
            if ($itemTakenOut->getId() == Item::APPLEENCHANTED) {
                $this->addTopEnchantedGoldenAppleContents();
            }
            if ($itemTakenOut->getId() == Item::ENDER_PEARL) {
                $this->addTopEnderPearlContents();
            }
            if ($itemTakenOut->getId() == Item::DIAMOND_SHOVEL) {
                $this->addTopSpendMoneyContents();
            }
        } elseif ($itemTakenOut->getId() == Item::TOTEM) {
            $this->addDefaultContents();
        }
        if ($itemTakenOut->getId() == -161) {
            $player->removeWindow($inventoryAction->getInventory());
        }
        if ($nbt->hasTag("username", StringTag::class)) {
            $name = $nbt->getTagValue("username", StringTag::class);
            $cloudpoints = $this->plugin->api("cloudPoints");
            $this->system = $cloudpoints;
            $this->target = $name;
            $player->removeWindow($inventoryAction->getInventory());
            $this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function (int $currentTick) use ($player) : void {
                $this->system->openStats($player->getName(), $this->target);
            }), 5);
        }
        return true;
    }

    public function addTopPointsContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $cloudpoints = $this->plugin->api("cloudPoints");
        $players = $cloudpoints->db->query("SELECT * FROM stats ORDER BY points DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::MOB_HEAD, 3, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Punkty:§b " . $row[1]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopAssistsContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $cloudpoints = $this->plugin->api("cloudPoints");
        $players = $cloudpoints->db->query("SELECT * FROM stats ORDER BY assists DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::MOB_HEAD, 2, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Asysty:§b " . $row[4]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopDeathsContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $cloudpoints = $this->plugin->api("cloudPoints");
        $players = $cloudpoints->db->query("SELECT * FROM stats ORDER BY deaths DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::MOB_HEAD, 0, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Smierci:§b " . $row[3]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopKillsContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $cloudpoints = $this->plugin->api("cloudPoints");
        $players = $cloudpoints->db->query("SELECT * FROM stats ORDER BY kills DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::DIAMOND_SWORD, 0, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Zabojstwa:§b " . $row[2]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopPremiumContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $players = $this->plugin->db->query("SELECT * FROM premiumcase ORDER BY pc DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::CHEST, 0, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Otworzone Premium Case'y:§b " . $row[1]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopMoneyContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $players = $this->plugin->db->query("SELECT * FROM shop ORDER BY money DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::DIAMOND_AXE, 0, $i);
            $row[1] = round($row[1], 2);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Monety:§b " . $row[1] . "$"]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopGoldenAppleContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $players = $this->plugin->db->query("SELECT * FROM golden ORDER BY goldenapple DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::GOLDEN_APPLE, 0, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Zjedzone refile:§b " . $row[1]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopEnchantedGoldenAppleContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $players = $this->plugin->db->query("SELECT * FROM enchantedgolden ORDER BY enchantedgoldenapple DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::APPLEENCHANTED, 0, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Zjedzone koxy:§b " . $row[1]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopEnderPearlContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $players = $this->plugin->db->query("SELECT * FROM pearl ORDER BY enderpearl DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::ENDER_PEARL, 0, $i);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Rzucone perly:§b " . $row[1]]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addTopSpendMoneyContents()
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        #$inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bPowrot do menu");
        $item->setLore(["§l",
            "§l§aKliknij, aby otworzyc menu topek"]);
        $inv->setItem(49, $item);
        $players = $this->plugin->db->query("SELECT * FROM spendmoney ORDER BY monety DESC LIMIT 25");
        $i = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $i++;
            $item = Item::get(Item::DIAMOND_SHOVEL, 0, $i);
            $row[1] = round($row[1], 2);
            $item->setCustomName("§l§7Gracz: §b" . $row[0] . " §8[§b" . $i . "§8]");
            $item->setLore([
                "§l ",
                "§l§7Wydane Monety:§b " . $row[1] . "$"]);
            $nbt = ($item->getNamedTag() ?? new CompoundTag());
            $nbt->setTag(new StringTag("username", $row[0]));
            $item->setNamedTag($nbt);
            $inv->setItem($i - 1, $item);
        }
    }

    public function addDefaultContents(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        #$inv->setItem(20, $item);
        #$inv->setItem(21, $item);
        #$inv->setItem(22, $item);
        #$inv->setItem(23, $item);
        #$inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        #$inv->setItem(29, $item);
        #$inv->setItem(30, $item);
        #$inv->setItem(31, $item);
        #$inv->setItem(32, $item);
        #$inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::MOB_HEAD, 3, 1);
        $item->setCustomName("§l§bTopka Punktow");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke punktow"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::MOB_HEAD, 2, 1);
        $item->setCustomName("§l§bTopka Asyst");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke asyst"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(Item::MOB_HEAD, 0, 1);
        $item->setCustomName("§l§bTopka Smierci");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke smierci"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
        $item->setCustomName("§l§bTopka Zabojstw");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke zabojstw"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(Item::DIAMOND_AXE, 0, 1);
        $item->setCustomName("§l§bTopka Monet");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke monet"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(Item::CHEST, 0, 1);
        $item->setCustomName("§l§bTopka Otworzonych PremiumCase'ow");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke otworzonych premium case'ow"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(29, $item);

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName("§l§bTopka Zjedzonych Refili");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke zjedzonych refili"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 1);
        $item->setCustomName("§l§bTopka Rzuconych Perel");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke rzuconych perel"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(31, $item);

        $item = Item::get(466, 0, 1);
        $item->setCustomName("§l§bTopka Zjedzonych Koxow");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke zjedzonych koxow"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(277, 0, 1);
        $item->setCustomName("§l§bTopka Wydanych pieniedzy");
        $item->setLore(["§l",
            "§l§aKliknij, aby zobaczyc topke wydanych pieniedzy"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("menu", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(33, $item);
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}