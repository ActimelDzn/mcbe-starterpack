<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class EffectsListener
{

    public $plugin;
    public $menu;

    public function __construct(Main $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        $totem = $this->menu->getInventory()->getItem(53);
        $nbt2 = ($totem->getNamedTag() ?? new CompoundTag());
        if ($nbt2->hasTag("effects", StringTag::class) && $nbt2->getTagValue("effects", StringTag::class) == 1) {
            if ($nbt->hasTag("haste", StringTag::class)) {
                $level = $nbt->getTagValue("haste", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 20 * 60 * 5, $level - 1));
                        $this->plugin->reduceMoney($player->getName(), 0.25);
                        $this->plugin->addSpendMoney($player->getName(), 0.25);
                    }
                } elseif ($level == 2) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 20 * 60 * 5, $level - 1));
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                    }
                } elseif ($level == 3) {
                    if ($this->plugin->getMoney($player->getName()) >= 1.00) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 20 * 60 * 5, $level - 1));
                        $this->plugin->reduceMoney($player->getName(), 1);
                        $this->plugin->addSpendMoney($player->getName(), 1);
                    }
                }
            }
            if ($nbt->hasTag("speed", StringTag::class)) {
                $level = $nbt->getTagValue("speed", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 60 * 5, $level - 1));
                        $this->plugin->reduceMoney($player->getName(), 0.25);
                        $this->plugin->addSpendMoney($player->getName(), 0.25);
                    }
                } elseif ($level == 2) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 60 * 5, $level - 1));
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                    }
                } elseif ($level == 3) {
                    if ($this->plugin->getMoney($player->getName()) >= 1.00) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 60 * 5, $level - 1));
                        $this->plugin->reduceMoney($player->getName(), 1);
                        $this->plugin->addSpendMoney($player->getName(), 1);
                    }
                }
            }
            if ($nbt->hasTag("strength", StringTag::class)) {
                $level = $nbt->getTagValue("strength", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 60 * 5, 1));
                        $this->plugin->reduceMoney($player->getName(), 0.25);
                        $this->plugin->addSpendMoney($player->getName(), 0.25);
                    }
                } elseif ($level == 2) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 60 * 5, 2));
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                    }
                }
            }
            if ($nbt->hasTag("nightvision", StringTag::class)) {
                $level = $nbt->getTagValue("nightvision", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 20 * 60 * 5, $level - 1));
                        $this->plugin->reduceMoney($player->getName(), 0.25);
                        $this->plugin->addSpendMoney($player->getName(), 0.25);
                    }
                }
            }
            if ($nbt->hasTag("invisibility", StringTag::class)) {
                $level = $nbt->getTagValue("invisibility", StringTag::class);
                if ($level == 1) {

                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 20 * 60 * 5, $level - 1));
                    $this->plugin->reduceMoney($player->getName(), 0.25);
                    $this->plugin->addSpendMoney($player->getName(), 0.25);
                }
            }
        }
        if ($nbt->hasTag("fireresistance", StringTag::class)) {
            $level = $nbt->getTagValue("fireresistance", StringTag::class);
            if ($level == 1) {
                if ($this->plugin->getMoney($player->getName()) >= 0.25) {
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 20 * 60 * 5, $level - 1));
                    $this->plugin->reduceMoney($player->getName(), 0.25);
                    $this->plugin->addSpendMoney($player->getName(), 0.50);
                }
            }
        }
        if ($nbt->hasTag("jumpboost", StringTag::class)) {
            $level = $nbt->getTagValue("jumpboost", StringTag::class);
            if ($level == 2) {
                if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 20 * 60 * 5, $level - 1));
                    $this->plugin->reduceMoney($player->getName(), 0.50);
                    $this->plugin->addSpendMoney($player->getName(), 0.50);
                }
            }
        } else {
            if ($nbt->hasTag("haste2", StringTag::class)) {
                $level = $nbt->getTagValue("haste2", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Haste I dla calej gildii!", true));
                            }
                        }
                    }
                } elseif ($level == 2) {
                    if ($this->plugin->getMoney($player->getName()) >= 1) {
                        $this->plugin->reduceMoney($player->getName(), 1);
                        $this->plugin->addSpendMoney($player->getName(), 1);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Haste II dla calej gildii!", true));
                            }
                        }
                    }
                } elseif ($level == 3) {
                    if ($this->plugin->getMoney($player->getName()) >= 2) {
                        $this->plugin->reduceMoney($player->getName(), 2);
                        $this->plugin->addSpendMoney($player->getName(), 2);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Haste III dla calej gildii!", true));
                            }
                        }
                    }
                }
            }
            if ($nbt->hasTag("speed2", StringTag::class)) {
                $level = $nbt->getTagValue("speed2", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Szybkosc I dla calej gildii!", true));
                            }
                        }
                    }
                } elseif ($level == 2) {
                    if ($this->plugin->getMoney($player->getName()) >= 1) {
                        $this->plugin->reduceMoney($player->getName(), 1);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Szybkosc II dla calej gildii!", true));
                            }
                        }
                    }
                } elseif ($level == 3) {
                    if ($this->plugin->getMoney($player->getName()) >= 2) {
                        $this->plugin->reduceMoney($player->getName(), 2);
                        $this->plugin->addSpendMoney($player->getName(), 2);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Szybkosc III dla calej gildii!", true));
                            }
                        }
                    }
                }
            }
            if ($nbt->hasTag("strength2", StringTag::class)) {
                $level = $nbt->getTagValue("strength2", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 60 * 5, 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Sila I dla calej gildii!", true));
                            }
                        }
                    }
                } elseif ($level == 2) {
                    if ($this->plugin->getMoney($player->getName()) >= 1) {
                        $this->plugin->reduceMoney($player->getName(), 1);
                        $this->plugin->addSpendMoney($player->getName(), 1);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 60 * 5, 2));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Sila II dla calej gildii!", true));
                            }
                        }
                    }
                }
            }
            if ($nbt->hasTag("nightvision2", StringTag::class)) {
                $level = $nbt->getTagValue("nightvision2", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Widzenie w Ciemnosci I dla calej gildii!", true));
                            }
                        }
                    }
                }
            }
            if ($nbt->hasTag("invisibility2", StringTag::class)) {
                $level = $nbt->getTagValue("invisibility2", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Niewidzialnosc I dla calej gildii!", true));
                            }
                        }
                    }
                }
            }
            if ($nbt->hasTag("fireresistance2", StringTag::class)) {
                $level = $nbt->getTagValue("fireresistance2", StringTag::class);
                if ($level == 1) {
                    if ($this->plugin->getMoney($player->getName()) >= 0.50) {
                        $this->plugin->reduceMoney($player->getName(), 0.50);
                        $this->plugin->addSpendMoney($player->getName(), 0.50);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Ochrona przed Ogniem I dla calej gildii!", true));
                            }
                        }
                    }
                }
            }
            if ($nbt->hasTag("jumpboost2", StringTag::class)) {
                $level = $nbt->getTagValue("jumpboost2", StringTag::class);
                if ($level == 2) {
                    if ($this->plugin->getMoney($player->getName()) >= 1) {
                        $this->plugin->reduceMoney($player->getName(), 1);
                        $this->plugin->addSpendMoney($player->getName(), 1);
                        $factions = $this->plugin->api("cloudGuilds");
                        $faction = $factions->getPlayerFaction($player->getName());
                        $array = $factions->db->query("SELECT * FROM master WHERE faction='$faction';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"])) {
                                $this->plugin->getServer()->getPlayer($row["player"])->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 20 * 60 * 5, $level - 1));
                                $this->plugin->getServer()->getPlayer($row["player"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " zakupil efekt Jump Boost II dla calej gildii!", true));
                            }
                        }
                    }
                }
            }
        }
        if ($itemTakenOut->getId() == Item::TOTEM) {
            if ($nbt->hasTag("effects", StringTag::class)) {
                if ($nbt->getTagValue("effects", StringTag::class) == "1") {
                    if ($this->plugin->api("cloudGuilds")->isInFaction($player->getName())) {
                        $this->addFactionEffectsContents();
                    }
                } elseif ($nbt->getTagValue("effects", StringTag::class) == "0") {
                    $this->addContents();
                }
            }
        }
        if ($itemTakenOut->getId() == Item::CONCRETE && $itemTakenOut->getDamage() == 14) {
            $player->removeWindow($inventoryAction->getInventory());
        }
        return true;
    }

    public function addFactionEffectsContents()
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();
        $menu->setName("§l§bEFEKTY GILDYJNE");

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        $inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        $inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        $inv->setItem(15, $item);
        #$inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        #$inv->setItem(19, $item);
        $inv->setItem(20, $item);
        #$inv->setItem(21, $item);
        $inv->setItem(22, $item);
        #$inv->setItem(23, $item);
        $inv->setItem(24, $item);
        #inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        #$inv->setItem(28, $item);
        $inv->setItem(29, $item);
        #$inv->setItem(30, $item);
        $inv->setItem(31, $item);
        #$inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        #$inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::GOLDEN_PICKAXE, 0, 1);
        $item->setCustomName("§b§lHASTE I");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("haste2", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::IRON_PICKAXE, 0, 1);
        $item->setCustomName("§l§bHASTE II ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 1.00$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("haste2", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(19, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->setCustomName("§l§bHASTE III ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 2.00$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("haste2", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(28, $item);

        $item = Item::get(Item::SUGAR, 0, 1);
        $item->setCustomName("§l§bSZYBKOSC I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 2:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("speed2", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::SUGAR, 0, 1);
        $item->setCustomName("§l§bSZYBKOSC II ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 2:00",
            "§l§7Koszt:§b 1.00$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("speed2", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::SUGAR, 0, 1);
        $item->setCustomName("§l§bSZYBKOSC III ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 2:00",
            "§l§7Koszt:§b 2.00$",
            "§l§cEFEKT JEST WYLACZONY!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("speed2off", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(Item::IRON_SWORD, 0, 1);
        $item->setCustomName("§l§bSILA I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 3:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("strength2", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
        $item->setCustomName("§l§bSILA II ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 3:00",
            "§l§7Koszt:§b 1.00$",
            "§l§aKliknij, aby kupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("strength2", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::ENDER_EYE, 0, 1);
        $item->setCustomName("§l§bWIDZENIE W CIEMNOSCI I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 8:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("nightvision2", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(34, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 1);
        $item->setCustomName("§l§bNIEWIDZIALNOSC I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 0.50$",
            "§l§cEFEKT JEST WYLACZONY!"]);
        /* $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("invisibility", "1"));
        $item->setNamedTag($nbt); */
        $inv->setItem(16, $item);

        $item = Item::get(Item::MAGMA_CREAM, 0, 1);
        $item->setCustomName("§l§bOCHRONA PRZED OGNIEM I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 8:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fireresistance2", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(Item::RABBIT_FOOT, 0, 1);
        $item->setCustomName("§l§bWYSOKIE SKAKNIE II ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 4:00",
            "§l§7Koszt:§b 1.00$",
            "§l§aKliknij, aby zakupic efekt dla calej gildii"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("jumpboost2", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bEFEKTY POJEDYNCZE ");
        $item->setLore(["§l ",
            "§l§aKliknij, aby otworzyc efekty pojedyncze"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("effects", "0"));
        $item->setNamedTag($nbt);
        $this->menu->getInventory()->setItem(45, $item);

    }

    public function addContents(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        $inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        $inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        $inv->setItem(15, $item);
        #$inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        #$inv->setItem(19, $item);
        $inv->setItem(20, $item);
        #$inv->setItem(21, $item);
        $inv->setItem(22, $item);
        #$inv->setItem(23, $item);
        $inv->setItem(24, $item);
        #inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        #$inv->setItem(28, $item);
        $inv->setItem(29, $item);
        #$inv->setItem(30, $item);
        $inv->setItem(31, $item);
        #$inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        #$inv->setItem(53, $item);

        $item = Item::get(Item::GOLDEN_PICKAXE, 0, 1);
        $item->setCustomName("§l§b§lHASTE I");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 0.25$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("haste", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::IRON_PICKAXE, 0, 1);
        $item->setCustomName("§l§bHASTE II");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("haste", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(19, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->setCustomName("§l§bHASTE III");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 1.00$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("haste", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(28, $item);

        $item = Item::get(Item::SUGAR, 0, 1);
        $item->setCustomName("§l§bSZYBKOSC I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 2:00",
            "§l§7Koszt:§b 0.25$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("speed", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::SUGAR, 0, 1);
        $item->setCustomName("§l§bSZYBKOSC II ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 2:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("speed", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::SUGAR, 0, 1);
        $item->setCustomName("§l§bSZYBKOSC III ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 2:00",
            "§l§7Koszt:§b 1.00$",
            "§l§cEFEKT JEST WYLACZONY!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("speedoff", "3"));
        $item->setNamedTag($nbt);
        $inv->setItem(30, $item);

        $item = Item::get(Item::IRON_SWORD, 0, 1);
        $item->setCustomName("§l§bSILA I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 3:00",
            "§l§7Koszt:§b 0.25$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("strength", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
        $item->setCustomName("§l§bSILA II ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 3:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby kupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("strength", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::ENDER_EYE, 0, 1);
        $item->setCustomName("§l§bWIDZENIE W CIEMNOSCI I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 8:00",
            "§l§7Koszt:§b 0.25$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("nightvision", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(34, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 1);
        $item->setCustomName("§l§bNIEWIDZIALNOSC I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 5:00",
            "§l§7Koszt:§b 0.25$",
            "§l§cEFEKT JEST WYLACZONY!"]);
        $inv->setItem(16, $item);

        $item = Item::get(Item::MAGMA_CREAM, 0, 1);
        $item->setCustomName("§l§bOCHRONA PRZED OGNIEM I ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 8:00",
            "§l§7Koszt:§b 0.25$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("fireresistance", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(Item::RABBIT_FOOT, 0, 1);
        $item->setCustomName("§l§bWYSOKIE SKAKNIE II ");
        $item->setLore(["§l ",
            "§l§7Czas Trwania:§b 4:00",
            "§l§7Koszt:§b 0.50$",
            "§l§aKliknij, aby zakupic efekt"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("jumpboost", "2"));
        $item->setNamedTag($nbt);
        $inv->setItem(32, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§l§bEFEKTY GILDYJNE ");
        $item->setLore(["§l ",
            "§l§aKliknij, aby otworzyc efekty gildyjne",
            "§l ",
            "§l§bMusisz posiadac gildie, aby otworzyc efekty gildyjne!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("effects", "1"));
        $item->setNamedTag($nbt);
        $inv->setItem(53, $item);

    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}