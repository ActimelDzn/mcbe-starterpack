<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class EnderChestListener
{

    public $plugin, $menu, $player;


    public function __construct(Main $pg, Player $player, String $name)
    {
        $this->player = $player;
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->setName($name)->setInventoryCloseListener(function (Player $player): void {
            $this->plugin->setEnderchestContents($player, $this->menu->getInventory()->getContents(true));
            $this->plugin->enderchest[$player->getName()] = 0;
        });
        $this->plugin = $pg;
    }

    public function addContents(Player $player): void
    {
        $inv = $this->menu->getInventory();
        $inv->setContents($this->plugin->getEnderchestContents($player));
        if (!$player->hasPermission("enderchest.bigger")) {
            for ($i = 27; $i <= 53; $i++) {
                if ($inv->getItem($i)->getId() == Item::AIR) {
                    $item = Item::get(-161, 0, 1);
                    $item->setCustomName("§8§l» §bZABLOKOWANE");
                    $item->setLore(["§l ",
                        "§8§l» §7Zakup range §bpremium, §7aby odblokowac ten slot!"]);
                    $nbt = ($item->getNamedTag() ?? new CompoundTag());
                    $nbt->setTag(new StringTag("blocked", "true"));
                    $item->setNamedTag($nbt);
                    $inv->setItem($i, $item);
                }
            }
        } else {
            foreach ($this->plugin->getEnderchestContents($player) as $index => $item) {
                $nbt = ($item->getNamedTag() ?? new CompoundTag());
                if ($nbt->hasTag("blocked", StringTag::class)) {
                    $inv->setItem($index, Item::get(Item::AIR, 0, 1));
                }
            }
        }
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}