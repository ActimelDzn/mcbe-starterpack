<?php

namespace cloudmc\GUIListeners;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class DropListener
{

    public $plugin;
    public $menu;

    public function __construct(Main $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        if ($nbt->hasTag("enable", StringTag::class)) {
            $this->plugin->changeDropStatusForAll($player->getName(), 0);
            $this->addDrop($player);
        }
        if ($nbt->hasTag("disable", StringTag::class)) {
            $this->plugin->changeDropStatusForAll($player->getName(), 1);
            $this->addDrop($player);
        }
        if ($nbt->hasTag("guild", StringTag::class)) {
            $this->plugin->enableGuildDrop($player->getName());
            $this->addDrop($player);
        }
        if ($nbt->hasTag("diamond", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "diamond");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("iron", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "iron");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("gold", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "gold");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("emerald", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "emerald");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("coal", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "coal");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("redstone", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "redstone");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("lapis", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "lapis");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("apple", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "apple");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("pearl", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "pearl");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("gunpowder", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "gunpowder");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("bookshelf", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "bookshelf");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("obsidian", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "obsidian");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("xp", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "xp");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("cobblestone", StringTag::class)) {
            $this->plugin->switchDropStatus($player->getName(), "cobblestone");
            $this->addDrop($player);
        }
        if ($nbt->hasTag("turbo", StringTag::class)) {
            $this->addDrop($player);
        }
        if ($itemTakenOut->getId() == Item::IRON_PICKAXE) {
            $this->addDrop($player);
        }
        if ($itemTakenOut->getId() == Item::TRAPPED_CHEST) {
            $this->addPremiumCase($player);
        }
        if ($itemTakenOut->getId() == Item::TOTEM) {
            $this->addContents($player);
        }
        return true;
    }

    public function addContents(Player $player): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();
        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(10, $item);
        $inv->setItem(11, $item);
        $inv->setItem(12, $item);
        $inv->setItem(13, $item);
        $inv->setItem(14, $item);
        $inv->setItem(15, $item);
        $inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        #$inv->setItem(20, $item);
        $inv->setItem(21, $item);
        #$inv->setItem(22, $item);
        $inv->setItem(23, $item);
        #$inv->setItem(24, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        $inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(146, 0, 1);
        $item->setCustomName("§l§bDROP Z PREMIUM CASE");
        $inv->setItem(20, $item);

        $item = Item::get(257, 0, 1);
        $item->setCustomName("§l§bDROP Z KAMIENIA");
        $inv->setItem(22, $item);

        $item = Item::get(129, 0, 1);
        $item->setCustomName("§l§bDROP Z COBBLEXOW §r§8[§l§cOFF§r§8]");
        $inv->setItem(24, $item);
    }

    public function addPremiumCase(): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();

        $inv->clearAll(false);

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        #$inv->setItem(10, $item);
        #$inv->setItem(11, $item);
        #$inv->setItem(12, $item);
        #$inv->setItem(13, $item);
        #$inv->setItem(14, $item);
        #$inv->setItem(15, $item);
        #$inv->setItem(16, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        #$inv->setItem(19, $item);
        #$inv->setItem(20, $item);
        #$inv->setItem(21, $item);
        #$inv->setItem(22, $item);
        #$inv->setItem(23, $item);
        #$inv->setItem(24, $item);
        #$inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        #$inv->setItem(30, $item);
        #$inv->setItem(31, $item);
        #$inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(37, $item);
        $inv->setItem(38, $item);
        $inv->setItem(39, $item);
        #$inv->setItem(40, $item);
        $inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(43, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::EMERALD, 0, 1);
        $item->setCustomName("§l§bEmeraldy (128-256)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(10, $item);

        $item = Item::get(Item::DIAMOND, 0, 1);
        $item->setCustomName("§l§bDiamenty (128-256)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(11, $item);

        $item = Item::get(Item::IRON_INGOT, 0, 1);
        $item->setCustomName("§l§bZelazo (128-256)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(12, $item);

        $item = Item::get(Item::GOLD_INGOT, 0, 1);
        $item->setCustomName("§l§bZloto (128-256)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(13, $item);

        $item = Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 1);
        $item->setCustomName("§l§bKoxy (8-16)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(14, $item);

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName("§l§bRefile (8-16)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(15, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 1);
        $item->setCustomName("§l§bPerly (8-16)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(16, $item);

        $item = Item::get(Item::DIAMOND_HELMET, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§l§bDiamentowy helm 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Szansa na drop: §b7.14%"]);
        $inv->setItem(19, $item);

        $item = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§l§bDiamentowa klata 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Szansa na drop: §b7.14%"]);
        $inv->setItem(20, $item);

        $item = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§l§bDiamentowe spodnie 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Szansa na drop: §b7.14%"]);
        $inv->setItem(21, $item);

        $item = Item::get(Item::DIAMOND_BOOTS, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->setCustomName("§l§bDiamentowe buty 4/3");
        $item->setLore(["§l ",
            "§8§l» §7Szansa na drop: §b7.14%"]);
        $inv->setItem(22, $item);

        $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FIRE_ASPECT), 2));
        $item->setCustomName("§l§bMiecz 5/2");
        $item->setLore(["§l ",
            "§8§l» §7Szansa na drop: §b7.14%"]);
        $inv->setItem(23, $item);

        $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 5));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::KNOCKBACK), 2));
        $item->setCustomName("§l§bMiecz KNOCK 1");
        $item->setLore(["§l ",
            "§8§l» §7Szansa na drop: §b7.14%"]);
        $inv->setItem(24, $item);

        $item = Item::get(Item::TNT, 0, 1);
        $item->setCustomName("§l§bTNT (32-64)");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 7.14%"]);
        $inv->setItem(25, $item);

        $item = Item::get(Item::BEACON, 0, 1);
        $item->setCustomName("§l§bBeacon");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 0.47%"]);
        $inv->setItem(30, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 6));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
        $item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FORTUNE), 3));
        $item->setCustomName("§l§bKilof 6/3/3");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 0.47%"]);
        $inv->setItem(31, $item);

        $item = Item::get(Item::MONSTER_SPAWNER, 0, 1);
        $item->setCustomName("§l§bRzucak");
        $item->setLore(["",
            "§l§7Szansa na drop:§b 0.47%"]);
        $inv->setItem(32, $item);

        $item = Item::get(450, 0, 1);
        $item->setCustomName("§l§bWROC DO MENU DROPOW");
        $inv->setItem(40, $item);
    }

    public function addDrop(Player $player): void
    {
        $menu = $this->menu;
        $inv = $menu->getInventory();
        $inv->clearAll(false);
        $noturbo = explode(",", $this->plugin->getConfig()->get("NoTurbo"));

        $item = Item::get(95, 0, 1);
        $item->setCustomName("§l");
        $inv->setItem(0, $item);
        $inv->setItem(1, $item);
        $inv->setItem(2, $item);
        $inv->setItem(3, $item);
        $inv->setItem(4, $item);
        $inv->setItem(5, $item);
        $inv->setItem(6, $item);
        $inv->setItem(7, $item);
        $inv->setItem(8, $item);
        $inv->setItem(9, $item);
        $inv->setItem(17, $item);
        $inv->setItem(18, $item);
        $inv->setItem(19, $item);
        $inv->setItem(25, $item);
        $inv->setItem(26, $item);
        $inv->setItem(27, $item);
        $inv->setItem(28, $item);
        $inv->setItem(29, $item);
        $inv->setItem(30, $item);
        $inv->setItem(31, $item);
        $inv->setItem(32, $item);
        $inv->setItem(33, $item);
        $inv->setItem(34, $item);
        $inv->setItem(35, $item);
        $inv->setItem(36, $item);
        $inv->setItem(40, $item);
        #$inv->setItem(41, $item);
        $inv->setItem(42, $item);
        $inv->setItem(44, $item);
        $inv->setItem(45, $item);
        $inv->setItem(46, $item);
        $inv->setItem(47, $item);
        $inv->setItem(48, $item);
        $inv->setItem(49, $item);
        $inv->setItem(50, $item);
        $inv->setItem(51, $item);
        $inv->setItem(52, $item);
        $inv->setItem(53, $item);

        $item = Item::get(Item::DIAMOND, 0, 1);
        $item->setCustomName("§l§bDiamenty");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(3 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "diamond"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("diamond", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(10, $item);

        $item = Item::get(Item::IRON_INGOT, 0, 1);
        $item->setCustomName("§l§bZelazo");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(2 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "iron"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("iron", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(11, $item);

        $item = Item::get(Item::GOLD_INGOT, 0, 1);
        $item->setCustomName("§l§bZloto");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(5 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "gold"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("gold", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(12, $item);

        $item = Item::get(Item::EMERALD, 0, 1);
        $item->setCustomName("§l§bSzmaragdy");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(4 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "emerald"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("emerald", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(13, $item);

        $item = Item::get(Item::COAL, 0, 1);
        $item->setCustomName("§l§bWegiel");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(9 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "coal"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("coal", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(14, $item);

        $item = Item::get(Item::REDSTONE, 0, 1);
        $item->setCustomName("§l§bRedstone");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(10 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "redstone"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("redstone", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(15, $item);

        $item = Item::get(Item::APPLE, 0, 1);
        $item->setCustomName("§l§bJablka");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(6 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "apple"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("apple", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(20, $item);

        $item = Item::get(Item::BOOKSHELF, 0, 1);
        $item->setCustomName("§l§bPolka z ksiazkami");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(8 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "bookshelf"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("bookshelf", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(21, $item);

        $item = Item::get(Item::OBSIDIAN, 0, 1);
        $item->setCustomName("§l§bObsydian");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(7 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "obsidian"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("obsidian", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(22, $item);

        $item = Item::get(Item::BOTTLE_O_ENCHANTING, 0, 1);
        $item->setCustomName("§l§bDoswiadczenie");
        $item->setLore(["§l",
            "§l§7Szansa: §b100%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "xp"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("xp", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(23, $item);

        $item = Item::get(Item::COBBLESTONE, 0, 1);
        $item->setCustomName("§l§bBruk");
        $item->setLore(["§l",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "cobblestone"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("cobblestone", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);

        $item = Item::get(Item::ENDER_PEARL, 0, 1);
        $item->setCustomName("§l§bEnderPerla");
        $item->setLore(["§l",
            "§l§7Szansa: §b" . round(6 / $noturbo[1] * 100, 2) . "%",
            "§l§7Status: " . $this->plugin->getDropStatusAsString($player->getName(), "pearl"),
            "§l§aKliknij, aby zmienic!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("pearl", "true"));
        $item->setNamedTag($nbt);
        $inv->setItem(16, $item);

        $item = Item::get(Item::TERRACOTTA, 14, 1);
        $item->setCustomName("§l§bWylacz wszystko");
        $item->setLore(["§l",
            "§l§aKliknij, aby wylaczyc wszystko!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("disable", "all"));
        $item->setNamedTag($nbt);
        $inv->setItem(37, $item);

        $item = Item::get(Item::TERRACOTTA, 4, 1);
        $item->setCustomName("§l§eWlacz drop itemow na gildie");
        $item->setLore(["§l",
            "§l§aKliknij, aby wlaczyc drop itemow na gildie!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("guild", "all"));
        $item->setNamedTag($nbt);
        $inv->setItem(38, $item);

        $item = Item::get(Item::TERRACOTTA, 5, 1);
        $item->setCustomName("§l§aWlacz wszystko");
        $item->setLore(["§l",
            "§l§aKliknij, aby wlaczyc wszystko!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("enable", "all"));
        $item->setNamedTag($nbt);
        $inv->setItem(39, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $item->setCustomName("§l§bTurboDrop");
        $item->setLore(["§l",
            "§l§7Status: " . $this->plugin->getTurboDropStatusAsString($player->getName()),
            "§l§aKliknij, aby odswiezyc!"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("turbo", "true"));
        $item->setNamedTag($nbt);
        $item->setNamedTagEntry(new ListTag(Item::TAG_ENCH));
        $inv->setItem(41, $item);

        $item = Item::get(450, 0, 1);
        $item->setCustomName("§l§bWROC DO MENU DROPOW");
        $inv->setItem(43, $item);
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}