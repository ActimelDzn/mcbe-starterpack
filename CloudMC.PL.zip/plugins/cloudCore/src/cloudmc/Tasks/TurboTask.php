<?php

namespace cloudmc\Tasks;

use cloudmc\Main;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class TurboTask extends Task
{

    private $plugin;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick)
    {
        $array = $this->plugin->db->query("SELECT * FROM turbodrop;");
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            $playerName = $row["player"];
            $time = $row["timestamp"];
            if ($time == 0) {
                $this->plugin->db->query("UPDATE turbodrop SET timestamp = '-1' WHERE player='$playerName';");
                if ($this->plugin->getServer()->getPlayer($playerName) instanceof Player) {
                    $this->plugin->getServer()->getPlayer($playerName)->sendMessage($this->plugin->formatMessage("Twoj turbodrop wyczerpal sie!", false));
                    $this->plugin->getServer()->getPlayer($playerName)->sendPopup("\n§8[§b§lTurbo§8]§r§b 0§7d. §b0§7h. §b0§7min. §b0§7s.");
                    if ($this->plugin->getConfig()->get("TurboHaste") == true) {
                        if ($this->plugin->getServer()->getPlayer($playerName)->hasEffect(Effect::HASTE)) {
                            if ($this->plugin->getServer()->getPlayer($playerName)->getEffect(Effect::HASTE)->getDuration() <= 20 * 14) {
                                $this->plugin->getServer()->getPlayer($playerName)->removeEffect(Effect::HASTE);
                            }
                        }
                    }
                }
            }
            if ($time > 0) {
                $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp - '1' WHERE player='$playerName';");
                if ($this->plugin->getServer()->getPlayer($playerName) instanceof Player) {
                    $this->plugin->getServer()->getPlayer($playerName)->sendPopup("\n§8[§b§lTurbo§8]§r§b " . floor(($time) / 86400) . "§7d. §b" . floor((($time) % 86400) / 3600) . "§7h. §b" . floor(((($time) % 86400) % 3600) / 60) . "§7min. §b" . floor(((($time) % 86400) % 3600) % 60) . "§7s.");
                    if ($this->plugin->getConfig()->get("TurboHaste") == true) {
                        if (!$this->plugin->getServer()->getPlayer($playerName)->hasEffect(Effect::HASTE) or $this->plugin->getServer()->getPlayer($playerName)->getEffect(Effect::HASTE)->getDuration() <= 20 * 4) {
                            $effect = new EffectInstance(Effect::getEffect(Effect::HASTE));
                            $effect->setDuration(20 * 14);
                            $effect->setAmplifier(1);
                            $this->plugin->getServer()->getPlayer($playerName)->addEffect($effect);
                        }
                    }
                }
            }
        }
    }
}

