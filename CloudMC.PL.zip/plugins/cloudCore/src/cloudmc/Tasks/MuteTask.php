<?php

namespace cloudmc\Tasks;

use cloudmc\Main;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class MuteTask extends Task
{

    private $plugin;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRun(int $currentTick)
    {
        $muted = $this->getPlugin()->db->query("SELECT * FROM mute;");
        while ($row = $muted->fetchArray(SQLITE3_ASSOC)) {
            $name = $row["player"];
            if ($this->getPlugin()->isMuted($name)) {
                $this->getPlugin()->db->query("UPDATE mute SET timestamp = timestamp - '1' WHERE player='$name';");
            } else {
                $this->getPlugin()->unmute($name);
            }
        }
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function getServer()
    {
        return $this->getPlugin()->getServer();
    }
}

