<?php

namespace cloudmc\Tasks;

use cloudmc\Main;
use pocketmine\entity\Effect;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class SpawnTask extends Task
{

    private $plugin, $player, $time;

    public function __construct(Main $plugin, Player $player, int $time)
    {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->time = $time;
    }

    public function onRun(int $currentTick)
    {
        if ($this->getServer()->getPlayer($this->getPlayer()->getName()) instanceof Player) {
            if ($this->getPlugin()->spawn[$this->getPlayer()->getName()] == 0) {
                if ($this->getTime() > 1) {
                    $this->updateTime();
                    $this->getPlayer()->addTitle("§l§7Teleportacja za §b" . $this->getTime() . " §7sekund", "§7Nie ruszaj sie!");
                } else {
                    $this->updateTime();
                    if ($this->getPlayer()->hasEffect(Effect::BLINDNESS)) {
                        $this->getPlayer()->removeEffect(Effect::BLINDNESS);
                    }
                    $this->getPlayer()->getLevel()->broadcastLevelSoundEvent($this->getPlayer()->getPosition()->asVector3(), LevelSoundEventPacket::SOUND_LAUNCH);
                    $this->getPlayer()->addTitle("§l§7Teleportacja udana!");
                    $this->getPlayer()->teleport($this->getServer()->getDefaultLevel()->getSpawnLocation()->asVector3());
                    $this->getPlugin()->spawn[$this->getPlayer()->getName()] = 1;
                    $this->getHandler()->cancel();
                }
            } else {
                $this->getHandler()->cancel();
            }
        } else {
            $this->getHandler()->cancel();
        }
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }

    public function getPlayer()
    {
        return $this->player;
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function getTime()
    {
        return $this->time;
    }

    public function updateTime()
    {
        $this->time--;
    }
}
