<?php

namespace cloudmc\Tasks;

use cloudmc\Main;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\plugin\Plugin;
use pocketmine\scheduler\Task;

class TimeTask extends Task
{

    private $plugin;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick)
    {
        $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "time set 0");
        #$this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "clearlagg clearall");
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }
}
