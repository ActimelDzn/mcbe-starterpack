<?php

namespace cloudmc\Tasks;

use cloudmc\Main;
use pocketmine\entity\Effect;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class TPATask extends Task
{

    private $plugin, $position, $target, $time;

    public function __construct(Main $plugin, Player $target, Position $position, int $time)
    {
        $this->plugin = $plugin;
        $this->position = $position;
        $this->target = $target;
        $this->time = $time;
    }

    public function onRun(int $currentTick)
    {
        if ($this->getServer()->getPlayer($this->getTarget()->getName()) instanceof Player) {
            if ($this->getPlugin()->tpastatus[$this->getTarget()->getName()] == 0) {
                if ($this->getTime() > 1) {
                    $this->updateTime();
                    $this->getTarget()->addTitle("§l§7Teleportacja za §b" . $this->getTime() . " §7sekund ", "§7Nie ruszaj sie!");
                } else {
                    $this->updateTime();
                    if ($this->getTarget()->hasEffect(Effect::BLINDNESS)) {
                        $this->getTarget()->removeEffect(Effect::BLINDNESS);
                    }
                    $this->getTarget()->getLevel()->broadcastLevelSoundEvent($this->getTarget()->getPosition()->asVector3(), LevelSoundEventPacket::SOUND_LAUNCH);
                    $this->getTarget()->addTitle("§l§7Teleportacja udana!");
                    $this->getTarget()->teleport($this->getPosition()->asVector3());
                    $this->getPlugin()->tpastatus[$this->getTarget()->getName()] = 1;
                    $this->getHandler()->cancel();
                }
            } else {
                $this->getHandler()->cancel();
            }
        } else {
            $this->getHandler()->cancel();
        }
    }

    public function getServer()
    {
        return $this->getPlugin()->getServer();
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function getTarget()
    {
        return $this->target;
    }

    public function getTime()
    {
        return $this->time;
    }

    public function updateTime()
    {
        $this->time--;
    }

    public function getPosition()
    {
        return $this->position;
    }
}

