<?php

namespace cloudmc\Tasks;

use cloudmc\Main;
use pocketmine\scheduler\Task;

class BroadcastTask extends Task
{

    private $plugin, $time;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
        $this->time = $this->getPlugin()->getConfig()->get("Broadcast");
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function onRun(int $currentTick)
    {
        $this->updateTime();
        if ($this->getTime() == 450) {
            $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Regulamin serwera znajdziesz na naszej stronie §bhttps://cloudmc.pl§7", true));
        }
        if ($this->getTime() == 360) {
            $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Wszystkie niezbedne informacje znajdziesz pod §b/pomoc", true));
        }
        if ($this->getTime() == 270) {
            $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Polub nasz fanpage na facebooku: §bhttps://cloudmc.pl/fanpage", true));
        }
        if ($this->getTime() == 180) {
            $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Dolacz do naszej grupy dla graczy: §bhttps://cloudmc.pl/grupa", true));
        }
        if ($this->getTime() == 90) {
            $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Dolacz na naszego discorda: §bhttps://cloudmc.pl/discord", true));
        }
        if ($this->getTime() == 0) {
            $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Chcesz kupic range lub inne dodatki? Wejdz na strone §bhttps://cloudmc.pl", true));
            $this->setTime($this->getPlugin()->getConfig()->get("Broadcast"));
        }
    }

    public function updateTime()
    {
        $this->time--;
    }

    public function getTime()
    {
        return $this->time;
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }

    public function setTime(int $time)
    {
        $this->time = $time;
    }
}