<?php

namespace cloudmc\Tasks;

use cloudmc\Main;
use pocketmine\block\Block;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class StoneTask extends Task
{

    private $plugin, $position;

    public function __construct(Main $plugin, Position $position)
    {
        $this->plugin = $plugin;
        $this->position = $position;
    }

    public function onRun(int $currentTick)
    {
        $world = $this->getServer()->getDefaultLevel();
        $world->setBlock($this->getPosition()->asVector3(), Block::get(Block::STONE, 0));
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }

    public function getPosition()
    {
        return $this->position;
    }

    public function getPlugin()
    {
        return $this->plugin;
    }
}