<?php

namespace cloudmc\Blocks;

use pocketmine\block\EnderChest as EnderchestResistance;

class EnderChest extends EnderchestResistance
{

    public function getHardness(): float
    {
        return 35;
    }

    public function getBlastResistance(): float
    {
        return 62;
    }
}
