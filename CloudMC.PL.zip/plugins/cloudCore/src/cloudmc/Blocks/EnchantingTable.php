<?php

namespace cloudmc\Blocks;

use pocketmine\block\EnchantingTable as EnchantingTableResistance;

class EnchantingTable extends EnchantingTableResistance
{

    public function getHardness(): float
    {
        return 35;
    }

    public function getBlastResistance(): float
    {
        return 62;
    }
}
