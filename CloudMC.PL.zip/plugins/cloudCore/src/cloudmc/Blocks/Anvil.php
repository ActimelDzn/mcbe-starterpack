<?php

namespace cloudmc\Blocks;

use pocketmine\block\Anvil as AnvilResistance;

class Anvil extends AnvilResistance
{

    public function getHardness(): float
    {
        return 35;
    }

    public function getBlastResistance(): float
    {
        return 62;
    }
}
