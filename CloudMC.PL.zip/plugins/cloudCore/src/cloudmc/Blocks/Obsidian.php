<?php

namespace cloudmc\Blocks;

use pocketmine\block\Obsidian as ObsidianResistance;

class Obsidian extends ObsidianResistance
{

    public function getHardness(): float
    {
        return 35;
    }

    public function getBlastResistance(): float
    {
        return 62;
    }
}
