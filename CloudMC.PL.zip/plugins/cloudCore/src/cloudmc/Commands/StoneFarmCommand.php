<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class StoneFarmCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Dodaje stoniarki do ekwipunku");
        $this->setUsage("/stonefarm [give] [poziom] [nick]");
        $this->setPermission("stonefarm.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /stonefarm [give] [poziom] [ilosc] [nick]", false));
        } elseif (count($args) == 4) {
            if ($args[0] == "give") {
                if (is_numeric($args[1])) {
                    if (is_numeric($args[2])) {
                        if ($this->plugin->getServer()->getPlayer($args[3]) instanceof Player) {
                            $this->plugin->addStoneFarm($this->plugin->getServer()->getPlayer($args[3]), $args[2], $args[1]);
                            $this->plugin->getServer()->getPlayer($args[3])->sendMessage($this->plugin->formatMessage("Dodano " . $args[2] . " stoniarek poziomu " . $args[1] . " do ekwipunku gracza " . $this->plugin->getServer()->getPlayer($args[3])->getName() . " pomyslnie.", true));
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                        }
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Ilosc musi byc numeryczna!", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Poziom musi byc numeryczny! (1-3)", false));
                }
            }
        }
        return true;
    }
}
