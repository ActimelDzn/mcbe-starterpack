<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class UslugaCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Nadaje uslugi dla graczy");
        $this->setUsage("Uzycie: /usluga [vip/svip/sponsor/sponsornz/turbo/turbo2/pc8/pc16/pc32/pc64/pc128/pc256/kolorowy] [nick]");
        $this->setPermission("usluga.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (count($args) < 2) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /usluga [vip/vipnz/svip/svipnz/sponsor/sponsornz/turbo/turbo2/turbo3pc8/pc16/pc32/pc64/pc128/pc372/pc744/pc1488/kolorowy/kolorowynz] [nick]", false));
        } elseif (count($args) == 2) {
            if ($args[0] == "vip") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Vip dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lVIP!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " Vip");
            }
            if ($args[0] == "vipnz") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Vip dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lVIP na ZAWSZE!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " VipNaZawsze");
            }
            if ($args[0] == "svip") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Svip dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lSVIP");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " Svip");
            }
            if ($args[0] == "svipnz") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Svip dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lSVIP na ZAWSZE!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " SvipNaZawsze");
            }
            if ($args[0] == "sponsor") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Sponsor dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lSPONSOR");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " Sponsor");
            }
            if ($args[0] == "sponsornz") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Sponsor dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lSPONSOR na ZAWSZE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " SponsorNaZawsze");
            }
            if ($args[0] == "swagger") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Sponsor dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lSWAGGER");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " Swagger");
            }
            if ($args[0] == "swaggernz") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano range Sponsor dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lSWAGGER na ZAWSZE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $args[1] . " SwaggerNaZawsze");
            }
            if ($args[0] == "turbo") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano turbodrop 30m dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lTURBO DROP 30 min");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "drop turbo dodaj " . $args[1] . " 30m");
            }
            if ($args[0] == "turbo2") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano turbodrop 1h dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lTURBO DROP 60 MIN");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "drop turbo dodaj " . $args[1] . " 60m");
            }
            if ($args[0] == "turbo3") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano turbodrop 3H dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lTURBO DROP 180 MIN");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "drop turbo dodaj " . $args[1] . " 180m");
            }
            if ($args[0] == "pc8") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l8 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 8 " . $args[1] . "");
            }
            if ($args[0] == "pc16") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l16 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 16 " . $args[1] . "");
            }
            if ($args[0] == "pc32") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l32 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 32 " . $args[1] . "");
            }
            if ($args[0] == "pc64") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l64 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 64 " . $args[1] . "");
            }
            if ($args[0] == "pc128") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l128 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 128 " . $args[1] . "");
            }
            if ($args[0] == "pc372") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l372 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 372 " . $args[1] . "");
            }
            if ($args[0] == "pc744") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l744 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 744 " . $args[1] . "");
            }
            if ($args[0] == "pc1488") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§l1488 PREMIUM CASE");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "pc give 1488 " . $args[1] . "");
            }
            if ($args[0] == "unban") {
                $sender->sendMessage($this->plugin->formatMessage("Nadano pc dla gracza " . $args[1], true));
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lUNBAN");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                $cloudbans = $this->plugin->api("cloudBans");
                $cloudbans->unban($args[1]);
            }
            if ($args[0] == "kolorowy") {
                if ($this->plugin->stringExistsInColoredName($args[1])) {
                    $sender->sendMessage($this->plugin->formatMessage("Nadano kolorowy nick dla gracza " . $args[1], true));
                    $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                    $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lKOLOROWY NICK");
                    $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                    $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                    $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                    $displayname = $this->plugin->makeRainbow($args[1]);
                    $this->plugin->db->query("UPDATE colorednames SET status = '0' WHERE player='$args[1]';");
                    $this->plugin->db->query("UPDATE colorednames SET displayname = '$displayname' WHERE player='$args[1]';");
                    if ($this->plugin->getServer()->getPlayer($args[1]) instanceof Player) {
                        $this->plugin->getServer()->getPlayer($args[1])->setDisplayName($displayname);
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Ten gracz nigdy nie odwiedzil serwera!", false));
                }
            }
            if ($args[0] == "kolorowynz") {
                if ($this->plugin->stringExistsInColoredName($args[1])) {
                    $sender->sendMessage($this->plugin->formatMessage("Nadano kolorowy nick dla gracza " . $args[1], true));
                    $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                    $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Gracz §b§l" . $args[1] . " §r§7zakupil usluge: §b§lKOLOROWY NICK na ZAWSZE!");
                    $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Dziekujemy za wsparcie serwera!");
                    $this->plugin->getServer()->broadcastMessage("§l§b* §r§7Nasza strona internetowa: §b§lwww.cloudmc.pl");
                    $this->plugin->getServer()->broadcastMessage("§8[ §7----------- §8[§l§bItemShop§r§8] §7----------- §8]");
                    $displayname = $this->plugin->makeRainbow($args[1]);
                    $this->plugin->db->query("UPDATE colorednames SET status = '0' WHERE player='$args[1]';");
                    $this->plugin->db->query("UPDATE colorednames SET displayname = '$displayname' WHERE player='$args[1]';");
                    if ($this->plugin->getServer()->getPlayer($args[1]) instanceof Player) {
                        $this->plugin->getServer()->getPlayer($args[1])->setDisplayName($displayname);
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Ten gracz nigdy nie odwiedzil serwera!", false));
                }
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /usluga [vip/svip/sponsor/sponsornz/turbo/turbo2/pc8/pc16/pc32/pc64/pc128/pc256/kolorowy] [nick]"));
        }
        return true;
    }
}