<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\command\ConsoleCommandSender;

class SprawdzCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Komendy do sprawdzania");
        $this->setPermission("sprawdz.use");
        $this->setAliases(["spr"]);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage("§8[ §7----------- §8[§l§bSprawdzanie§r§8] §7----------- §8]");
            $sender->sendMessage("§l§b* §r§7/sprawdz [nick] - teleportuje gracza do sprawdzarki");
            $sender->sendMessage("§l§b* §r§7/sprawdz czysty [nick] - teleportuje gracza na poprzednia pozycje i taguje czystym");
            $sender->sendMessage("§8[ §7----------- §8[§l§bSprawdzanie§r§8] §7----------- §8]");
        } elseif (count($args) == 1) {
            if ($this->plugin->getServer()->getPlayer($args[0]) instanceof Player) {
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "tp " . $args[0] . " 1 55 -75");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "tp " . $sender->getName() . " 1 55 -75");
                $sender->sendMessage($this->plugin->formatMessage("Sprawdzasz: " . $this->plugin->getServer()->getPlayer($args[0])->getName(), true));
            }
        } elseif (count($args) == 2) {
            if ($args[0] == "czysty") {
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "tp " . $args[1] . " 0 78 0");
                $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "tp " . $sender->getName() . " 0 78 0");
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty! Uzycie: /sprawdz", false));
        }
        return true;
    }
}