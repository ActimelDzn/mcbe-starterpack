<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class TpaCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Wysyla prosbe o teleportacje");
        $this->setUsage("/tpa [nick]");
        $this->setPermission("tpa.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz sie teleportowac podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Poprawne uzycie: /tpa <nick>", false));
        } elseif (count($args) == 1) {
            if ($this->plugin->getServer()->getPlayer($args[0]) instanceof Player) {
                if ($this->plugin->getServer()->getPlayer($args[0])->getName() != $sender->getName()) {
                    $this->plugin->tpa[$this->plugin->getServer()->getPlayer($args[0])->getName()] = $sender->getName();
                    $this->plugin->getServer()->getPlayer($args[0])->sendMessage($this->plugin->formatMessage("Gracz " . $sender->getName() . " wysyla prosbe o teleportacje! Wpisz /tpaccept aby zaakceptowac lub /tpadecline aby odrzucic!", true));
                    $sender->sendMessage($this->plugin->formatMessage("Wyslano prosbe o teleportacje do " . $this->plugin->getServer()->getPlayer($args[0])->getName(), true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie mozesz teleportowac sie do samego siebie!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty!", false));
        }
        return true;
    }
}
