<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class SetyCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Pozwala zablokowac crafting diamentowych zbroji");
        $this->setUsage("/sety [on/off]");
        $this->setPermission("sety.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /sety [on/off]", false));
        } elseif (count($args) == 1) {
            if ($args[0] == "on") {
                if ($this->plugin->getConfig()->get("SetyStatus") == "off") {
                    $this->plugin->getConfig()->set("SetyStatus", "on");
                    $this->plugin->getConfig()->save();
                    $this->plugin->getConfig()->reload();
                    $sender->sendMessage($this->plugin->formatMessage("Wlaczono craftowanie diamentowych zbroji", true));
                    foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                        $p->addTitle("§l§7DIAMENTOWE ZBROJE", "§l§aWLACZONE");
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Sety sa juz wlaczone!", false));
                }
            }
            if ($args[0] == "off") {
                if ($this->plugin->getConfig()->get("SetyStatus") == "on") {
                    $this->plugin->getConfig()->set("SetyStatus", "off");
                    $this->plugin->getConfig()->save();
                    $this->plugin->getConfig()->reload();
                    $sender->sendMessage($this->plugin->formatMessage("Wylaczono craftowanie diamentowych zbroji", true));
                    foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                        $p->addTitle("§l§7DIAMENTOWE ZBROJE", "§l§cWYLACZONE");
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Sety sa juz wylaczone!", false));
                }
            }
        }
        return true;
    }
}
