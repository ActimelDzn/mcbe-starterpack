<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;
use pocketmine\item\Item;

class SellAllCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Sprzedawanie wszystkich itemow na raz");
        $this->setUsage("/sellall");
        $this->setPermission("sellall.use");
        $this->plugin = $plugin;
    }


    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Komenda jest wylaczona."));
        }
        return true;
    }
}
