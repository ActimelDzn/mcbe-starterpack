<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class FeedCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Uzupelnia glod");
        $this->setUsage("/feed [nick]");
        $this->setPermission("food.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz uleczyc jedzenia podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            $sender->setFood($sender->getMaxFood());
            $sender->sendMessage($this->plugin->formatMessage("Twoj glod zostal uzupelniony!", true));
        } elseif (count($args) == 1) {
            $target = $this->plugin->getServer()->getPlayer($args[0]);
            if ($sender->hasPermission("feed.use.others")) {
                if ($target instanceof Player) {
                    $target->setFood($target->getMaxFood());
                    $target->sendMessage($this->plugin->formatMessage("Twoj glod zostal uzupelniony!", true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie mozesz uzupelniac glodu innym!", false));
            }
        }
        return true;
    }
}
