<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class GamemodeCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Pozwala zmienic tryb gry");
        $this->setUsage("/cgm [0/3]");
        $this->setPermission("sprawdz.use");
        $this->setAliases(["cgamemode"]);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz zmienic trybu gry podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /cgm [0/3]", false));
        } elseif (count($args) == 1) {
            if ($args[0] == "0") {
                $sender->sendMessage($this->plugin->formatMessage("Wlaczono tryb survival", true));
                $sender->setGamemode(0);
            }
            if ($args[0] == "3") {
                $sender->sendMessage($this->plugin->formatMessage("Wlaczono tryb spectator", true));
                $sender->setGamemode(3);
            }
        }
        return true;
    }
}
