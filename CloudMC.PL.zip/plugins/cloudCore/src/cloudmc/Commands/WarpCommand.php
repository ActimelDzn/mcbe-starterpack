<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\Tasks\WarpTask;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;

class WarpCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Teleportuje na warpy");
        $this->setUsage("/warp [nazwa]");
        $this->setPermission("warp.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz isc na warp podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /warp [pvp, stoniarki, grupowe]", false));
        } elseif (count($args) == 1) {
            if ($args[0] == "pvp") {
                if (!$sender->hasPermission("ac.warp.override")) {
                    $this->plugin->warp[$sender->getName()] = 0;
                    $task = new WarpTask($this->plugin, $sender, new Position(-85 - 0.5, 71, 13 + 0.5), $this->plugin->getConfig()->get("WarpCooldownTime"));
                    $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
                    $sender->addTitle("§l§7Teleportacja za\n§b" . $this->plugin->getConfig()->get("WarpCooldownTime") . " §7sekund", "§cNie ruszaj sie!");
                    $sender->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20 * $this->plugin->getConfig()->get("WarpCooldownTime"), 0));
                } else {
                    $sender->teleport(new Vector3(-85 - 0.5, 71, 13 + 0.5));
                }
            }
            if ($args[0] == "stoniarki") {
                if (!$sender->hasPermission("ac.warp.override")) {
                    $this->plugin->warp[$sender->getName()] = 0;
                    $task = new WarpTask($this->plugin, $sender, new Position(-2 - 0.5, 71, 12 - 0.5), $this->plugin->getConfig()->get("WarpCooldownTime"));
                    $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
                    $sender->addTitle("§l§7Teleportacja za\n§b" . $this->plugin->getConfig()->get("WarpCooldownTime") . " §cNie ruszaj sie!");
                    $sender->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20 * $this->plugin->getConfig()->get("WarpCooldownTime"), 0));
                } else {
                    $sender->teleport(new Vector3(-2 - 0.5, 71, 12 - 0.5));
                }
            }
            if ($args[0] == "grupowe") {
                if (!$sender->hasPermission("ac.warp.override")) {
                    $this->plugin->warp[$sender->getName()] = 0;
                    $task = new WarpTask($this->plugin, $sender, new Position(-46 - 0.5, 87, -21 + 0.5), $this->plugin->getConfig()->get("WarpCooldownTime"));
                    $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
                    $sender->addTitle("§l§7Teleportacja za\n§b" . $this->plugin->getConfig()->get("WarpCooldownTime") . " §7sekund", "§cNie ruszaj sie!");
                    $sender->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20 * $this->plugin->getConfig()->get("WarpCooldownTime"), 0));
                } else {
                    $sender->teleport(new Vector3(-46 - 0.5, 87, -21 + 0.5));
                }
            }
        }
        return true;
    }
}