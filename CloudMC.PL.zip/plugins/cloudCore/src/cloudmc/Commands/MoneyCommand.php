<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class MoneyCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Zarzadzanie monetami");
        $this->setUsage("/monety [przeslij] [ilosc] [nick]");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (empty($args) or count($args) == 1) {
            $money = $this->plugin->getMoney($sender->getName());
            $money = round($money, 2);
            $sender->sendMessage($this->plugin->formatMessage("Twoje monety:§b $money " . "$", false));
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /monety <przeslij> <ilosc> <nick>", false));
        } elseif (count($args) == 3) {
            if ($args[0] == "przeslij") {
                if (is_numeric($args[1])) {
                    if (strlen($args[1]) < 6) {
                        if ($args[1] >= 0.10) {
                            if ($this->plugin->getMoney($sender->getName()) >= $args[1]) {
                                if ($this->plugin->getServer()->getPlayer($args[2]) instanceof Player) {
                                    $this->plugin->reduceMoney($sender->getName(), $args[1]);
                                    $this->plugin->addMoney($args[2], $args[1]);
                                    $sender->sendMessage($this->plugin->formatMessage("Przeslano§b " . $args[1] . "$" . "§7 graczowi§b " . $this->plugin->getServer()->getPlayer($args[2])->getName(), true));
                                    $this->plugin->getServer()->getPlayer($args[2])->sendMessage($this->plugin->formatMessage("Otrzymales§b " . $args[1] . "$" . "§7 od§b " . $sender->getName()));
                                } else {
                                    $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                                }
                            } else {
                                $money = $this->plugin->getMoney($sender->getName());
                                $sender->sendMessage($this->plugin->formatMessage("Nie posiadasz tylu monet (Twoje monety:§b " . $money . "$" . "§7)", false));
                            }
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Ilosc przesylanych monet nie moze byc mniejsza niz 0.10!", false));
                        }
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Ilosc przesylanych monet moze miec maksymalnie 4 liczby!", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Ilosc monet musi byc numeryczna!", false));
                }
            }
        }
        return true;
    }
}
