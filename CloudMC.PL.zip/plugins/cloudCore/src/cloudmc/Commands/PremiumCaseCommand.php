<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;

class PremiumCaseCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Rozdaje premiumcase");
        $this->setUsage("/pc [give/all] [ilosc] [nick]");
        $this->setPermission("premiumcase.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (empty($args) or count($args) == 1) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /pc <give/all> <ilosc> <nick>", false));
        } elseif (count($args) == 2) {
            if ($args[0] == "all") {
                if (is_numeric($args[1])) {
                    if ($args[1] <= 128) {
                        $sender->sendMessage($this->plugin->formatMessage("Rozdano " . $args[1] . " premiumcase graczom na serwerze!", true));
                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Wszyscy gracze na serwerze otrzymali " . $args[1] . " premiumcase od " . $sender->getName(), true));
                        foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                            $item = Item::get(Item::TRAPPED_CHEST, 0, $args[1]);
                            $item->setCustomName($this->plugin->getConfig()->get("PremiumCaseCustomName"));
                            $item->setLore(["§8> §l§fPodarowane od: " . $sender->getDisplayName() . "§r"]);
                            $nbt = ($item->getNamedTag() ?? new CompoundTag());
                            $nbt->setTag(new StringTag("premiumcase", "true"));
                            $item->setNamedTag($nbt);
                            if ($p->getInventory()->canAddItem($item)) {
                                $p->getInventory()->addItem($item);
                            } else {
                                $p->getLevel()->dropItem(new Vector3($p->getX(), $p->getY(), $p->getZ()), $item);
                            }
                            $p->addTitle("§7Wszyscy otrzymali " . $args[1] . " premiumcase od " . $sender->getName());
                        }
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Ilosc premiumcase nie moze byc wieksza niz 128!", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Ilosc premiumcase musi byc numeryczna!", false));
                }
            }
        } elseif (count($args) == 3) {
            if ($args[0] == "give") {
                if (is_numeric($args[1])) {
                    if ($args[1] <= 2500) {
                        if ($this->plugin->getServer()->getPlayer($args[2]) instanceof Player) {
                            $sender->sendMessage($this->plugin->formatMessage("Podarowano " . $args[1] . " premiumcase graczowi " . $this->plugin->getServer()->getPlayer($args[2])->getName(), true));
                            $item = Item::get(Item::TRAPPED_CHEST, 0, $args[1]);
                            $item->setCustomName($this->plugin->getConfig()->get("PremiumCaseCustomName"));
                            $nbt = ($item->getNamedTag() ?? new CompoundTag());
                            $nbt->setTag(new StringTag("premiumcase", "true"));
                            $item->setNamedTag($nbt);
                            if ($this->plugin->getServer()->getPlayer($args[2])->getInventory()->canAddItem($item)) {
                                $this->plugin->getServer()->getPlayer($args[2])->getInventory()->addItem($item);
                            } else {
                                $this->plugin->getServer()->getPlayer($args[2])->getLevel()->dropItem(new Vector3($this->plugin->getServer()->getPlayer($args[2])->getX(), $this->plugin->getServer()->getPlayer($args[2])->getY(), $this->plugin->getServer()->getPlayer($args[2])->getZ()), $item);
                            }
                            $this->plugin->getServer()->getPlayer($args[2])->sendMessage($this->plugin->formatMessage("§7Otrzymales " . $args[1] . " premiumcase od " . $sender->getName()));
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                        }
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Ilosc premiumcase nie moze byc wieksza niz 2500!", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Ilosc premiumcase musi byc numeryczna!", false));
                }
            }
        }
        return true;
    }
}
