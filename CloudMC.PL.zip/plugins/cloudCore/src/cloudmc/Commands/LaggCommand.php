<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\entity\object\ItemEntity;
use pocketmine\item\Item;
use pocketmine\math\Vector3;

class LaggCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Zabija wszystkie ItemEntity z mapy");
        $this->setUsage("/lagg clear");
        $this->setPermission("lagg.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /lagg clear", false));
        } elseif (count($args) == 1) {
            if ($args[0] == "clear") {
                $level = $this->plugin->getServer()->getDefaultLevel();
                $i = 0;
                foreach ($level->getEntities() as $entity) {
                    if ($entity instanceof ItemEntity) {
                        $item = $entity->getItem();
                        $entity->flagForDespawn();
                        $i++;
                    }
                }
                $sender->sendMessage($this->plugin->formatMessage("Poprawnie usunieto " . $i . " przedmiotow z ziemi z zaladowanych chunkow!", true));
            }
        } elseif (count($args) > 1) {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty!", false));
        }
        return true;
    }
}