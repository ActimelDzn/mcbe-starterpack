<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\GUIListeners\EnderChestListener;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class EnderchestCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Otwiera enderchest");
        $this->setUsage("/enderchest");
        $this->setPermission("enderchest.use");
        $this->setAliases(["ec"]);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz otworzyc enderchesta podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            if (!isset($this->plugin->enderchest[$sender->getName()]) or $this->plugin->enderchest[$sender->getName()] == 0) {
                $ec = new EnderChestListener($this->plugin, $sender, "§l§bEnderchest");
                $this->plugin->enderchest[$sender->getName()] = 1;
                $ec->addContents($sender);
                $ec->sendTo($sender);
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty. Uzycie: /ec", false));
        }
        return true;
    }
}
