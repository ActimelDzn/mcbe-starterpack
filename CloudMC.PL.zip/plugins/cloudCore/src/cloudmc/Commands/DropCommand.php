<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\GUIListeners\DropListener;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class DropCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Ustawienia dropu");
        $this->setUsage("/drop [turbo] [dodaj/usun/reload] [nick/all] [czas]");
        $this->setPermission("drop.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (empty($args)) {
            if ($sender instanceof Player) {
                $gui = new DropListener($this->plugin, "§l§bDROP");
                $gui->addContents($sender);
                $gui->sendTo($sender);
            } else {
                $this->plugin->getLogger()->alert("Ta komende mozesz uzyc tylko w grze!");
            }
        } elseif (count($args) == 1) {
            if ($args[0] == "reload" or $args[0] == "przeladuj") {
                if ($sender->hasPermission("drop.reload")) {
                    $this->plugin->getConfig()->reload();
                    $sender->sendMessage($this->plugin->formatMessage("Przeladowano config.yml!", true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie posiadsz wystarczajacych permisji aby zreloadowac config.yml!", false));
                }
            }
            if ($args[0] == "turbo") {
                if ($sender->hasPermission("drop.reload")) {
                    $sender->sendMessage($this->plugin->formatMessage("Uzycie: /drop turbo dodaj/usun <nick/all> <czas>", false));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie posiadsz wystarczajacych permisji aby przegladac ta komende!", false));
                }
            }
        } elseif (count($args) == 2) {
            if ($args[0] == "turbo") {
                if ($sender->hasPermission("drop.reload")) {
                    if ($args[1] == "dodaj") {
                        $sender->sendMessage($this->plugin->formatMessage("Uzycie: /drop turbo dodaj <nick/all> <czas>", false));
                    }
                    if ($args[1] == "usun") {
                        $sender->sendMessage($this->plugin->formatMessage("Uzycie: /drop turbo usun <nick>", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie posiadsz wystarczajacych permisji aby przegladac ta komende!", false));
                }
            }
        } elseif (count($args) == 3) {
            if ($args[0] == "turbo") {
                if ($sender->hasPermission("drop.reload")) {
                    if ($args[1] == "dodaj") {
                        $sender->sendMessage($this->plugin->formatMessage("Uzycie: /drop turbo dodaj <nick/all> <czas>", false));
                    }
                    if ($args[1] == "usun") {
                        if ($this->plugin->hasTurbo($args[2])) {
                            $this->plugin->db->query("UPDATE turbodrop SET timestamp = '0' WHERE player='$args[2]';");
                            $sender->sendMessage($this->plugin->formatMessage("Usunieto turbodrop " . $args[2] . " pomyslnie", false));
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Ten gracz nie posiada turbodropu!", false));
                        }
                        if ($args[2] == "all") {
                            $array = $this->plugin->db->query("SELECT * FROM turbodrop;");
                            while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                                $playerName = $row["player"];
                                $this->plugin->db->query("UPDATE turbodrop SET timestamp = '0' WHERE player='$playerName';");
                                $sender->sendMessage($this->plugin->formatMessage("Usunieto turbodrop wszystkim graczom pomyslnie", false));
                            }
                        }
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie posiadsz wystarczajacych permisji aby przegladac ta komende!", false));
                }
            }
        } elseif (count($args) == 4) {
            if ($args[0] == "turbo") {
                if ($sender->hasPermission("drop.reload")) {
                    if ($args[1] == "dodaj") {
                        if ($args[2] != "all") {
                            if ($this->plugin->getServer()->getPlayer($args[2]) instanceof Player) {
                                $playerName = $this->plugin->getServer()->getPlayer($args[2])->getName();
                                $time = substr($args[3], -1);
                                if ($time == "s") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                    $sender->sendMessage($this->plugin->formatMessage("Nadano turbodrop dla " . $playerName . " na czas " . substr($args[3], 0, -1) . " sekund", true));
                                } elseif ($time == "m") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $timetotask = $timetotask * 60;
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                    $sender->sendMessage($this->plugin->formatMessage("Nadano turbodrop dla " . $playerName . " na czas " . substr($args[3], 0, -1) . " minut", true));
                                } elseif ($time == "h" or $time == "g") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $timetotask = $timetotask * 60 * 60;
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                    $sender->sendMessage($this->plugin->formatMessage("Nadano turbodrop dla " . $playerName . " na czas " . substr($args[3], 0, -1) . " godzin", true));
                                } elseif ($time == "d") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $timetotask = $timetotask * 60 * 60 * 24;
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                    $sender->sendMessage($this->plugin->formatMessage("Nadano turbodrop dla " . $playerName . " na czas " . substr($args[3], 0, -1) . " dni", true));
                                } else {
                                    $sender->sendMessage($this->plugin->formatMessage("Musisz podac format czasu! (s/m/(h/g))", false));
                                }
                            } else {
                                $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                            }
                        } else {
                            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                                $playerName = $p->getName();
                                $time = substr($args[3], -1);
                                if ($time == "s") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                } elseif ($time == "m") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $timetotask = $timetotask * 60;
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                } elseif ($time == "h" or $time == "g") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $timetotask = $timetotask * 60 * 60;
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                } elseif ($time == "d") {
                                    $timetotask = substr($args[3], 0, -1);
                                    $timetotask = $timetotask * 60 * 60 * 24;
                                    $this->plugin->db->query("UPDATE turbodrop SET timestamp = timestamp + '$timetotask' WHERE player='$playerName';");
                                } else {
                                    $sender->sendMessage($this->plugin->formatMessage("Musisz podac format czasu! (s/m/(h/g))", false));
                                }
                            }
                            $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Wszyscy otrzymali TurboDrop na " . substr($args[3], 0, -1) . substr($args[3], -1) . " od " . $sender->getName(), true));
                        }
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie posiadsz wystarczajacych permisji aby przegladac ta komende!", false));
                }
            }
        }
        return true;
    }
}
