<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\Item;
use pocketmine\Player;

class SetHomeCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Ustawia domy");
        $this->setUsage("/sethome [nazwa]");
        $this->setPermission("sethome.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }

        $x = floor($sender->getX());
        $z = floor($sender->getZ());
        $guilds = $this->plugin->api("cloudGuilds");
        if ($guilds->isInPlot($x, $z)) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz ustawic domu na terenie gildii!", false));
            return false;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz ustawic domu podczas walki!", false));
            return false;
        }
        if (count($args) == 0 || count($args) > 1) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /sethome [nazwa]", false));
        } else {
            if ($this->plugin->homeExists($sender->getName(), $args[0]) == true) {
                $id = $this->plugin->getIdHome($sender->getName(), $args[0]);
                $this->plugin->db->query("DELETE FROM home WHERE id='$id';");
                if ($sender->getInventory()->contains(Item::get(388, 0, 8))) {
                    $sender->getInventory()->removeItem(Item::get(388, 0, 8));
                    $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO home (player, name, x, y, z, world) VALUES (:player, :name, :x, :y, :z, :world);");
                    $stmt->bindValue(":player", $sender->getName());
                    $stmt->bindValue(":name", $args[0]);
                    $stmt->bindValue(":x", $sender->getX());
                    $stmt->bindValue(":y", $sender->getY());
                    $stmt->bindValue(":z", $sender->getZ());
                    $stmt->bindValue(":world", $sender->getLevel()->getName());
                    $result = $stmt->execute();
                    $sender->sendMessage($this->plugin->formatMessage("Dom $args[0] zostal nadpisany (x: " . $sender->getZ() . " y: " . $sender->getY() . " z: " . $sender->getZ() . " swiat: " . $sender->getLevel()->getName() . ").", true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Potrzebujesz 8 szmaragdow, aby nadpisac dom.", false));
                }
            } else {
                if (strlen($args[0]) < 21 && !empty($args[0])) {
                    if (preg_match('/^[a-zA-Z0-9]{1,}$/', $args[0]) == 1) {
                        if ($this->plugin->getNumberOfHomes($sender->getName()) < 1 || $sender->hasPermission("home.gracz")) {
                            if ($this->plugin->getNumberOfHomes($sender->getName()) < 2 || $sender->hasPermission("home.vip")) {
                                if ($this->plugin->getNumberOfHomes($sender->getName()) < 3 || $sender->hasPermission("home.svip")) {
                                    if ($this->plugin->getNumberOfHomes($sender->getName()) < 5 || $sender->hasPermission("home.sponsor")) {
                                        if ($this->plugin->getNumberOfHomes($sender->getName()) < 5 || $sender->hasPermission("home.swagger")) {
                                        if ($sender->getInventory()->contains(Item::get(388, 0, 16))) {
                                            $sender->getInventory()->removeItem(Item::get(388, 0, 16));
                                            $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO home (player, name, x, y, z, world) VALUES (:player, :name, :x, :y, :z, :world);");
                                            $stmt->bindValue(":player", $sender->getName());
                                            $stmt->bindValue(":name", $args[0]);
                                            $stmt->bindValue(":x", $sender->getX());
                                            $stmt->bindValue(":y", $sender->getY());
                                            $stmt->bindValue(":z", $sender->getZ());
                                            $stmt->bindValue(":world", $sender->getLevel()->getName());
                                            $result = $stmt->execute();
                                            $sender->sendMessage($this->plugin->formatMessage("Dom $args[0] zostal zapisany (x: " . number_format($sender->getZ()) . " y: " . number_format($sender->getY()) . " z: " . number_format($sender->getZ()) . " swiat: " . $sender->getLevel()->getName() . ").", true));
                                        } else {
                                            $sender->sendMessage($this->plugin->formatMessage("Potrzebujesz 16 szmaragdow, aby zapisac dom.", false));
                                            }
                                        } else {
                                            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz zapisac nastepnego domu! Mozesz miec ich maksymalnie 10. Rangi platne maja mozliwosc zalozenia wiekszej ilosci domow!", false));
                                        }
                                    } else {
                                        $sender->sendMessage($this->plugin->formatMessage("Nie mozesz zapisac nastepnego domu! Mozesz miec ich maksymalnie 5. Rangi platne maja mozliwosc zalozenia wiekszej ilosci domow!", false));
                                    }
                                } else {
                                    $sender->sendMessage($this->plugin->formatMessage("Nie mozesz zapisac nastepnego domu! Mozesz miec ich maksymalnie 3. Rangi platne maja mozliwosc zalozenia wiekszej ilosci domow!", false));
                                }
                            } else {
                                $sender->sendMessage($this->plugin->formatMessage("Nie mozesz zapisac nastepnego domu! Mozesz miec ich maksymalnie 2. Rangi platne maja mozliwosc zalozenia wiekszej ilosci domow!", false));
                            }
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz zapisac nastepnego domu! Mozesz miec ich maksymalnie 1. Rangi platne maja mozliwosc zalozenia wiekszej ilosci domow!", false));
                        }
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Nazwa domu moze zawierac tylko litery oraz cyfry!", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nazwa domu musi zawierac 1-20 znakow.", false));
                }
            }
        }
        return true;
    }
}
