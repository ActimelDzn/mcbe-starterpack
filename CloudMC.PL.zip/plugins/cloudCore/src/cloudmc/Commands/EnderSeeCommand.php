<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use muqsit\invmenu\InvMenu;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class EnderSeeCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Pokazuje enderchest gracza");
        $this->setUsage("/endersee [nick]");
        $this->setPermission("endersee.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (count($args) == 1) {
            $target = $this->plugin->getServer()->getPlayer($args[0]);
            if ($target instanceof Player) {
                $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
                $menu->readonly();
                $menu->setName("§l§7Enderchest:§b " . $target->getname());
                $inv = $menu->getInventory();
                $inv->setContents($this->plugin->getEnderchestContents($target));
                $menu->send($sender);
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty! Uzycie: /endersee <nick>", false));
        }
        return true;
    }
}
