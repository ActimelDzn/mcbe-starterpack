<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class DelHomeCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Usuwa zapisane domy");
        $this->setUsage("/delhome [nazwa]");
        $this->setPermission("delhome.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (count($args) == 0 || count($args) > 1) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie /delhome [nazwa]"));
        } else {
            if (!empty($args[0])) {
                $player = $sender->getName();
                if ($this->plugin->homeExists($player, $args[0]) == true) {
                    $this->plugin->db->query("DELETE FROM home WHERE player='$player' AND name='$args[0]';");
                    $sender->sendMessage($this->plugin->formatMessage("Dom§b $args[0] §7zostal usuniety!" . true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Dom§b $args[0] §7nie istnieje!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Musisz podac nazwe domu!", false));
            }
        }
        return true;
    }
}
