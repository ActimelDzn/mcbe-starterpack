<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\Item;
use pocketmine\level\particle\FlameParticle;
use pocketmine\Player;

class TopkaCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Otwiera menu z topkami");
        $this->setUsage("/topka");
        $this->setAliases(["top"]);
        $this->setPermission("topka.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $this->plugin->openTopsGUI($sender);
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty: Uzycie: /topka", false));
        }
        return true;
    }
}
