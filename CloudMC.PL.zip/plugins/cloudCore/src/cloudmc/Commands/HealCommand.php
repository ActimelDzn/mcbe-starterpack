<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;
use pocketmine\level\Position;

class HealCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Ulecza wszystkie serduszka");
        $this->setUsage("/heal [nick]");
        $this->setPermission("heal.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz uleczyc serc podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            $sender->setHealth($sender->getMaxHealth());
            $sender->sendMessage($this->plugin->formatMessage("Zostales uleczony!", true));
        } elseif (count($args) == 1) {
            if ($this->plugin->getServer()->getPlayer($args[0]) instanceof Player) {
                if ($sender->hasPermission("heal.use.others")) {
                    $sender->teleport(new Position(0, 100, 0, spawn));
                    $this->plugin->getServer()->getPlayer($args[0])->setHealth($this->plugin->getServer()->getPlayer($args[0])->getMaxHealth());
                    $this->plugin->getServer()->getPlayer($args[0])->sendMessage($this->plugin->formatMessage("Zostales uleczony!", true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie mozesz wlaczyc goda innym!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono gracza o nicku§b " . $args[0] . "§7 na serwerze!", false));
            }
        }
        return true;
    }
}
