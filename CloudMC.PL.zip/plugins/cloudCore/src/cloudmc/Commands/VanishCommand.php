<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class VanishCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Ukrywa gracza przed innymi graczami");
        $this->setUsage("/vanish [nick]");
        $this->setAliases(["v"]);
        $this->setPermission("vanish.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz wlaczyc vanisha podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            $this->plugin->switchVanish($sender);
        } elseif (count($args) == 1) {
            if ($this->plugin->getServer()->getPlayer($args[0]) instanceof Player) {
                if ($this->plugin->playerExists($this->plugin->getServer()->getPlayer($args[0]))) {
                    if ($sender->hasPermission("vanish.use.others")) {
                        $this->plugin->switchVanish($this->plugin->getServer()->getPlayer($args[0]));
                        $sender->sendMessage($this->plugin->formatMessage("Zmieniono status vanish dla " . $this->plugin->getServer()->getPlayer($args[0])->getName() . "!", true));
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Nie mozesz ukrywac innych graczy!", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono gracza o nicku " . $args[0] . " w bazie danych!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono gracza o nicku " . $args[0] . " na serwerze!", false));
            }
        }
        return true;
    }
}
