<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\Player;

class RepairCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Naprawia przedmioty");
        $this->setUsage("/repair [all]");
        $this->setPermission("repair.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz naprawiac przedmiotow podczas walki!", false));
            return false;
        }
        $a = "hand";
        if (isset($args[0])) {
            $a = strtolower($args[0]);
        }
        if (!($a === "hand" || $a === "all")) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie /repair <all>.", false));
            return true;
        }
        if ($a === "all") {
            if ($sender->hasPermission("repair.use.all")) {
                foreach ($sender->getInventory()->getContents() as $index => $item) {
                    if ($this->isRepairable($item)) {
                        if ($item->getDamage() > 0) {
                            $sender->getInventory()->setItem($index, $item->setDamage(0));
                        }
                    }
                }
                foreach ($sender->getArmorInventory()->getContents() as $index => $item) {
                    if ($this->isRepairable($item)) {
                        if ($item->getDamage() > 0) {
                            $sender->getArmorInventory()->setItem($index, $item->setDamage(0));
                        }
                    }
                }
                $sender->sendMessage($this->plugin->formatMessage("Wszystkie przedmioty zostaly naprawione", true));
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie posiadasz permisji do naprawy wszystkich przedmiotow!", false));
            }
        } else {
            $index = $sender->getInventory()->getHeldItemIndex();
            $item = $sender->getInventory()->getItem($index);
            if (!$this->isRepairable($item)) {
                $sender->sendMessage($this->plugin->formatMessage("Tego przedmiotu nie mozna naprawic", false));
                return true;
            }
            if ($item->getDamage() > 0) {
                $sender->getInventory()->setItem($index, $item->setDamage(0));
            }
        }
        $sender->sendMessage($this->plugin->formatMessage("Przedmiot zostal naprawiony!", true));
        return true;
    }

    public function isRepairable(Item $item)
    {
        return $item instanceof Tool || $item instanceof Armor;
    }
}
