<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\GUIListeners\GroupsListener;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class RangiCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Otwiera menu z informacjami o rangach");
        $this->setUsage("/rangi");
        $this->setPermission("rangi.use");
        $this->plugin = $plugin;
    }


    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Opisy rang oraz mozliwosc kupna ich znajdziesz na stronie serwera §bwww.cloudmc.pl"));
        }
        return true;
    }
}
