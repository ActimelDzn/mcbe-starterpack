<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\GUIListeners\EffectsListener;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\Item;
use pocketmine\Player;

class EffectsCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Otwiera menu z efektami");
        $this->setUsage("/efekty");
        $this->setAliases(["efekt"]);
        $this->setPermission("efekty.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $money = $this->plugin->getMoney($sender->getName());
            $money = round($money, 2);
            $gui = new EffectsListener($this->plugin, "§l§bEfekty §8(§bMonety: " . $money . "$" . "§8)");
            $gui->addContents();
            $gui->sendTo($sender);
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty: Uzycie: /efekty", false));
        }
        return true;
    }
}
