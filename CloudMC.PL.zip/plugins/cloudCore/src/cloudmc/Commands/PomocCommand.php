<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\GUIListeners\HelpListener;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class PomocCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Otwiera menu z przydatnymi informacjami");
        $this->setUsage("/pomoc");
        $this->setPermission("pomoc.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage("§8[ §7-------------- §8[§l§bPOMOC§r§8] §7-------------- §8]");
            $sender->sendMessage("§l§b *§r§b /g pomoc <1/2> - §7komendy gildii");
            $sender->sendMessage("§l§b *§r§b /drop - §7informacje o dropie");
            $sender->sendMessage("§l§b *§r§b /efekty - §7efekty serwerowe");
            $sender->sendMessage("§l§b *§r§b /rangi - §7informacje o rangach");
            $sender->sendMessage("§l§b *§r§b /schowek - §7otwiera schowek");
            $sender->sendMessage("§l§b *§r§b /otchlan - §7otwiera otchlan");
            $sender->sendMessage("§l§b *§r§b /sklep - §7Sklep serwerowy");
            $sender->sendMessage("§l§b *§r§b /spawn - §7teleportacja na spawn");
            $sender->sendMessage("§l§b *§r§b /tpa <nick> - §7teleportacja do gracza");
            $sender->sendMessage("§l§b *§r§b /warp - §7teleportacja na warpy");
            $sender->sendMessage("§l§b *§r§b /kit - §7informacja o kitach");
            $sender->sendMessage("§l§b *§r§b /staty - §7statystyki gracza");
            $sender->sendMessage("§l§b *§r§b /monety - §7informacje o monetach");
            $sender->sendMessage("§l§b *§r§b /craftingi - §7craftingi serwerowe");
            $sender->sendMessage("§l§b *§r§b /sethome <nazwa> - §7ustawianie domu");
            $sender->sendMessage("§l§b *§r§b /home <nazwa> - §7teleportowanie do domu");
            $sender->sendMessage("§l§b");
            $sender->sendMessage("§l§b *§r§7 Wszystkie inne informacje (§bRegulamin§7, §bdiscord§7, §bfanpage§7, §bsklep§7 itp.)");
            $sender->sendMessage("§l§b *§r§7 Znajdziesz na stronie serwera §bcloudmc.pl");
            $sender->sendMessage("§8[ §7-------------- §8[§l§bPOMOC§r§8] §7-------------- §8]");
            return true;
        }
    }
}
