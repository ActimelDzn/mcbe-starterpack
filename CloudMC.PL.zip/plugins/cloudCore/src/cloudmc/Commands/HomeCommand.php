<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\Tasks\HomeTask;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\level\Position;
use pocketmine\Player;

class HomeCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Teleportuje na domy");
        $this->setUsage("/home [nazwa]");
        $this->setPermission("home.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz sie teleportowac na dom podczas walki!", false));
            return false;
        }
        $points = $this->plugin->getPoints($sender->getName());
        $pureperms = $this->plugin->api("PurePerms");
        if ($points == 500 && $pureperms->getUserDataMgr()->getGroup($sender)->getName() == "Gracz") {
            $sender->kick("§8[§b§lCloudMC.pl§r§8] §7Ale co ty probujesz? xd");
        }
        if (count($args) == 0) {
            if ($this->plugin->getNumberOfHomes($sender->getName()) > 0) {
                $sender->sendMessage($this->plugin->formatMessage("Lista domow (" . $this->plugin->getNumberOfHomes($sender->getName()) . "): " . substr($this->plugin->getAllHome($sender->getName()), 0, strlen($this->plugin->getAllHome($sender->getName())) - 2) . "."));
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie masz zapisanych domow! Aby zapisac dom uzyj /sethome [nazwa]", false));
            }
        } elseif (count($args) == 1) {
            if (!empty($args[0])) {
                if ($this->plugin->homeExists($sender->getName(), $args[0]) == true) {
                    $this->plugin->getHome($sender->getName(), $args[0]);
                    $this->plugin->home[$sender->getName()] = 0;
                    $task = new HomeTask($this->plugin, $sender, new Position($this->plugin->getX, $this->plugin->getY, $this->plugin->getZ), $this->plugin->getConfig()->get("HomeCooldownTime"));
                    $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
                    $sender->addTitle("§l§7Teleportacja za §b" . $this->plugin->getConfig()->get("HomeCooldownTime") . " §7sekund", "§7Nie ruszaj sie!");
                    $sender->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20 * $this->plugin->getConfig()->get("HomeCooldownTime"), 0));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Dom§b $args[0] §7nie istnieje!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Musisz podac nazwe domu!", false));
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie /home [nazwa]", false));
        }
        return true;
    }
}
