<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class ChatCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Ustawienia chatu");
        $this->setUsage("/chat [on/off/cc]");
        $this->setAliases(["c"]);
        $this->setPermission("chat.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /chat <cc/on/off>", false));
        } elseif (count($args) == 1) {
            if ($args[0] == "cc") {
                for ($i = 0; $i <= 256; $i++) {
                    $this->plugin->getServer()->broadcastMessage("§l");
                }
                $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Chat zostal wyczyszczony przez " . $sender->getName(), true));
            } elseif ($args[0] == "on") {
                if ($this->plugin->getChatStatus() != 0) {
                    for ($i = 0; $i <= 256; $i++) {
                        $this->plugin->getServer()->broadcastMessage("§l");
                    }
                    $this->plugin->changeChatStatus(0);
                    $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Chat zostal wlaczony przez " . $sender->getName(), true));
                    $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars("Chat zostal wlaczony przez " . $sender->getName(), true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Chat jest juz wlaczony!", false));
                }
            } elseif ($args[0] == "off") {
                if ($this->plugin->getChatStatus() != 1) {
                    for ($i = 0; $i <= 256; $i++) {
                        $this->plugin->getServer()->broadcastMessage("§l");
                    }
                    $this->plugin->changeChatStatus(1);
                    $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Chat zostal wylaczony przez " . $sender->getName(), true));
                    $this->plugin->sendDiscordChatMessage($this->plugin->replaceDiscordChars("Chat zostal wylaczony przez " . $sender->getName(), true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Chat jest juz wylaczony!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty! Uzycie: /chat <cc/on/off>", false));
            }
        }
        return true;
    }
}