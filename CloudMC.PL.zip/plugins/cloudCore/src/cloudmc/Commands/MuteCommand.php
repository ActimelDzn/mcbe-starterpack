<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class MuteCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Wycisza graczy");
        $this->setUsage("/mute [nick] [czas]");
        $this->setPermission("mute.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (empty($args)) {
            $sender->sendMessage($this->plugin->formatMessage("Uzycie: /mute [nick] [czas]", false));
        } elseif (count($args) == 1) {
            $target = $this->plugin->getServer()->getPlayer($args[0]);
            if ($target instanceof Player) {
                if ($this->plugin->isMuted($target->getName())) {
                    $this->plugin->unmute($target->getName());
                    $target->sendMessage($this->plugin->formatMessage("Zostales odciszony!", true));
                    $sender->sendMessage($this->plugin->formatMessage($target->getName() . " zostal odciszony. ", true));
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Ten gracz nie jest wyciszony!", false));
                }
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
            }
        } elseif (count($args) == 2) {
            $target = $this->plugin->getServer()->getPlayer($args[0]);
            if ($target instanceof Player) {
                if (!$target->isOp()) {
                    if (!$this->plugin->isMuted($target->getName())) {
                        $prefix = substr($args[1], -1);
                        if ($prefix == "s") {
                            $time = substr($args[1], 0, -1);
                            $this->plugin->setMuted($target, $time);
                            $sender->sendMessage($this->plugin->formatMessage("Wyciszono " . $target->getName() . " na czas " . substr($args[1], 0, -1) . " sekund", true));
                            $target->sendMessage($this->plugin->formatMessage("Zostales wyciszony na " . substr($args[1], 0, -1) . " sekund przez " . $sender->getName(), false));
                        } elseif ($prefix == "m") {
                            $time = substr($args[1], 0, -1);
                            $time = $time * 60;
                            $this->plugin->setMuted($target, $time);
                            $sender->sendMessage($this->plugin->formatMessage("Wyciszono " . $target->getName() . " na czas " . substr($args[1], 0, -1) . " minut", true));
                            $target->sendMessage($this->plugin->formatMessage("Zostales wyciszony na " . substr($args[1], 0, -1) . " minut przez " . $sender->getName(), false));
                        } elseif ($prefix == "h" or $prefix == "g") {
                            $time = substr($args[1], 0, -1);
                            $time = $time * 60 * 60;
                            $this->plugin->setMuted($target, $time);
                            $sender->sendMessage($this->plugin->formatMessage("Wyciszono " . $target->getName() . " na czas " . substr($args[1], 0, -1) . " godzin", true));
                            $target->sendMessage($this->plugin->formatMessage("Zostales wyciszony na " . substr($args[1], 0, -1) . " godzin przez " . $sender->getName(), false));
                        } elseif ($prefix == "d") {
                            $time = substr($args[1], 0, -1);
                            $time = $time * 60 * 60 * 24;
                            $this->plugin->setMuted($target, $time);
                            $sender->sendMessage($this->plugin->formatMessage("Wyciszono " . $target->getName() . " na czas " . substr($args[1], 0, -1) . " dni", true));
                            $target->sendMessage($this->plugin->formatMessage("Zostales wyciszony na " . substr($args[1], 0, -1) . " dni przez " . $sender->getName(), false));
                        } else {
                            $sender->sendMessage($this->plugin->formatMessage("Musisz podac format czasu! (s/m/(h/g))", false));
                        }
                    } else {
                        $sender->sendMessage($this->plugin->formatMessage("Ten gracz jest juz wyciszony!", false));
                    }
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie mozesz wyciszyc tego gracza!", false));
                }
            }
        }
        return true;
    }
}