<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\Tasks\TPATask;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\Player;

class TpacceptCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Akceptuje teleportacje");
        $this->setUsage("/tpaccept");
        $this->setAliases(["tpyes"]);
        $this->setPermission("tpaccept.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz akceptowac teleportacji podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            if (isset($this->plugin->tpa[$sender->getName()])) {
                $target = $this->plugin->getServer()->getPlayer($this->plugin->tpa[$sender->getName()]);
                $this->plugin->tpastatus[$target->getName()] = 0;
                $task = new TPATask($this->plugin, $target, $sender->getPosition(), $this->plugin->getConfig()->get("TpaCooldownTime"));
                $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
                $target->sendMessage($this->plugin->formatMessage("Gracz " . $sender->getName() . " zaakceptowal prosbe o teleportacje!", true));
                $target->addTitle("§l§7Teleportacja za §b" . $this->plugin->getConfig()->get("TpaCooldownTime") . " §7sekund", "§7Nie ruszaj sie!");
                $target->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20 * $this->plugin->getConfig()->get("TpaCooldownTime"), 0));
                $sender->sendMessage($this->plugin->formatMessage("Zaakceptowales prosbe o teleportacje gracza " . $this->plugin->tpa[$sender->getName()] . "! ", true));
                unset($this->plugin->tpa[$sender->getName()]);
            } else {
                $sender->sendMessage($this->plugin->formatMessage("Nie masz zadnych prosb o teleportacje!", false));
            }
        } else {
            $sender->sendMessage($this->plugin->formatMessage("Bledne argumenty", false));
        }
        return true;
    }
}
