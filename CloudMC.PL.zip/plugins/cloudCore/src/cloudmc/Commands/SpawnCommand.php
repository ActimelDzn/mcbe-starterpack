<?php

namespace cloudmc\Commands;

use cloudmc\Main;
use cloudmc\Tasks\SpawnTask;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\Player;

class SpawnCommand extends PluginCommand
{

    private $plugin;

    public function __construct(Main $plugin, String $name)
    {
        parent::__construct($name, $plugin);
        $this->setDescription("Teleportuje na spawn");
        $this->setUsage("/spawn [nick]");
        $this->setPermission("spawn.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $alias, array $args): bool
    {
        if (!$this->testPermission($sender)) {
            return true;
        }
        if (!$sender instanceof Player) {
            $sender->sendMessage("Ta komende mozesz uzyc tylko w grze!");
            return true;
        }
        $antylogout = $this->plugin->api("SystemAntyLogouta");
        $fight = $antylogout->isInFight($sender->getName());
        if ($fight) {
            $sender->sendMessage($this->plugin->formatMessage("Nie mozesz isc na spawna podczas walki!", false));
            return false;
        }
        if (empty($args)) {
            if (!$sender->hasPermission("ac.spawn.override")) {
                $this->plugin->spawn[$sender->getName()] = 0;
                $task = new SpawnTask($this->plugin, $sender, $this->plugin->getConfig()->get("SpawnCooldownTime"));
                $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
                $sender->addTitle("§l§7Teleportacja za §b" . $this->plugin->getConfig()->get("SpawnCooldownTime") . " §7sekund", "§7Nie ruszaj sie!");
                $sender->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20 * $this->plugin->getConfig()->get("SpawnCooldownTime"), 0));
            } else {
                $sender->teleport($this->plugin->getServer()->getDefaultLevel()->getSpawnLocation()->asVector3());
            }
        } elseif (count($args) == 1) {
            if ($sender->hasPermission("ac.spawn.override")) {
                $target = $sender->getServer()->getPlayer($args[0]);
                if ($target instanceof Player) {
                    $target->teleport($this->plugin->getServer()->getDefaultLevel()->getSpawnLocation()->asVector3());
                } else {
                    $sender->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                }
            }
        }
        return true;
    }
}
