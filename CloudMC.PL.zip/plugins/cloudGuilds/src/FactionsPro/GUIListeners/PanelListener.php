<?php

namespace FactionsPro\GUIListeners;

use FactionsPro\FactionMain;
use muqsit\invmenu\InvMenu;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\scheduler\ClosureTask;

class PanelListener
{

    public $plugin;
    public $menu;
    public $username;

    public function __construct(FactionMain $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        if ($itemTakenOut->getId() == Item::MOB_HEAD) {
            if ($nbt->hasTag("username", StringTag::class)) {
                $username = $nbt->getTagValue("username", StringTag::class);
                $this->username = $username;
                $player->removeWindow($inventoryAction->getInventory());
                $this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function (int $currentTick) use ($player) : void {
                    $gui = new HeadListener($this->plugin, "§8§l» §b" . $this->username);
                    $gui->addContents($this->username);
                    $gui->sendTo($player);
                }), 5);
            }
        }
        if ($itemTakenOut->getId() == -161) {
            $this->addContents($player);
        }
        return true;
    }

    public function addContents(Player $player): void
    {
        $inv = $this->menu->getInventory();
        $inv->clearAll(false);
        $i = 0;
        $faction = $this->plugin->getPlayerFaction($player->getName());
        if ($this->plugin->getNumberOfPlayers($faction) > 1) {
            $array = $this->plugin->db->query("SELECT * FROM master WHERE faction='$faction';");
            while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                $name = $row["player"];
                $rank = $this->plugin->getRankAsString2($name);
                if ($name != $player->getName()) {
                    if ($this->plugin->existsInPermissions($name)) {
                        $item = Item::get(Item::MOB_HEAD, 3, 1);
                        $item->setCustomName("§8§l» §7Gracz:§b " . $name);
                        $item->setLore(["§l ",
                            "§8§l» §7Ranga:§b " . $rank,
                            "§l ",
                            "§8§l» §aKliknij, aby zobaczyc permisje"]);
                        $nbt = ($item->getNamedTag() ?? new CompoundTag());
                        $nbt->setTag(new StringTag("username", $name));
                        $item->setNamedTag($nbt);
                        $inv->setItem($i, $item);
                        $i++;
                    }
                }
            }
        } else {
            for ($i = 0; $i <= 26; $i++) {
                $item = Item::get(-161, 0, 1);
                $item->setCustomName("§8§l» §bAby zarzadzac gildia potrzebujesz wiecej czlonkow!");
                $item->setLore(["§l ",
                    "§8§l» §aKliknij, aby odswiezyc"]);
                $inv->setItem($i, $item);
            }
        }
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}