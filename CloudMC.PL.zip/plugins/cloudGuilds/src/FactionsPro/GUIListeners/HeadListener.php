<?php

namespace FactionsPro\GUIListeners;

use FactionsPro\FactionMain;
use muqsit\invmenu\InvMenu;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\scheduler\ClosureTask;

class HeadListener
{

    public $plugin;
    public $menu;

    public function __construct(FactionMain $pg, String $name)
    {
        $this->menu = InvMenu::create(InvMenu::TYPE_CHEST)->readonly()->setName($name)->setListener([$this, "onTransaction"]);
        $this->plugin = $pg;
    }

    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction): bool
    {
        $inv = $this->menu->getInventory();
        $nbt = ($itemTakenOut->getNamedTag() ?? new CompoundTag());
        if ($nbt->hasTag("username", StringTag::class)) {
            $username = $nbt->getTagValue("username", StringTag::class);
            $faction = $this->plugin->getPlayerFaction($username);
            if ($itemTakenOut->getId() == Item::STONE) {
                if ($this->plugin->getPermission($username, "build")) {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " przydzielil permisje gildyjna: Stawianie blokow dla " . $username, $faction, true);
                } else {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " usunal permisje gildyjna: Stawianie blokow dla " . $username, $faction, true);
                }
                $this->plugin->switchPermission($username, "build");
                $this->addContents($username);
            }
            if ($itemTakenOut->getId() == Item::DIAMOND_PICKAXE) {
                if ($this->plugin->getPermission($username, "break") == 0) {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " przydzielil permisje gildyjna: Niszczenie blokow dla " . $username, $faction, true);
                } else {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " usunal permisje gildyjna: Niszczenie blokow dla " . $username, $faction, true);

                }
                $this->plugin->switchPermission($username, "break");
                $this->addContents($username);
            }
            if ($itemTakenOut->getId() == Item::CHEST) {
                if ($this->plugin->getPermission($username, "chestopen") == 0) {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " przydzielil permisje gildyjna: Otwieranie skrzyn dla " . $username, $faction, true);
                } else {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " usunal permisje gildyjna: Otwieranie skrzyn dla " . $username, $faction, true);
                }
                $this->plugin->switchPermission($username, "chestopen");
                $this->addContents($username);
            }
            if ($itemTakenOut->getId() == Item::FURNACE) {
                if ($this->plugin->getPermission($username, "furnaceopen") == 0) {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " przydzielil permisje gildyjna: Otwieranie piecykow dla " . $username, $faction, true);
                } else {
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " usunal permisje gildyjna: Otwieranie piecykow dla " . $username, $faction, true);
                }
                $this->plugin->switchPermission($username, "furnaceopen");
                $this->addContents($username);
            }
            if ($itemTakenOut->getId() == Item::TERRACOTTA) {
                if ($itemTakenOut->getDamage() == 14) {
                    $this->plugin->setAllPermissions($username, 0);
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " wylaczyl wszystkie permisje gildyjne dla " . $username, $faction, true);
                } elseif ($itemTakenOut->getDamage() == 5) {
                    $this->plugin->setAllPermissions($username, 1);
                    $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " wlaczyl wszystkie permisje gildyjne dla " . $username, $faction, true);
                }
                $this->addContents($username);
            }
        }
        if ($itemTakenOut->getId() == Item::TOTEM) {
            $player->removeWindow($inventoryAction->getInventory());
            $this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function (int $currentTick) use ($player) : void {
                $gui = new PanelListener($this->plugin, "§8§l» §bPanel Gildyjny");
                $gui->addContents($player);
                $gui->sendTo($player);
            }), 5);
        }
        return true;
    }

    public function addContents(String $target): void
    {
        $inv = $this->menu->getInventory();

        $inv->clearAll(false);
        $item = Item::get(Item::STONE, 0, 1);
        $status = $this->plugin->getPermissionAsString($target, "build");
        $item->setCustomName("§8§l» §bStawianie blokow ");
        $item->setLore(["§l ",
            "§8§l» §7Informacje: §bPozwala na stawianie blokow na terenie gildii",
            "§8§l» §7Status: " . $status,
            "§8§l» §aKliknij, aby zmienic permisje"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("username", $target));
        $item->setNamedTag($nbt);
        $inv->setItem(0, $item);

        $item = Item::get(Item::DIAMOND_PICKAXE, 0, 1);
        $status = $this->plugin->getPermissionAsString($target, "break");
        $item->setCustomName("§8§l» §bNiszczenie blokow ");
        $item->setLore(["§l ",
            "§8§l» §7Informacje: §bPozwala na niszczenie blokow na terenie gildii",
            "§8§l» §7Status: " . $status,
            "§8§l» §aKliknij, aby zmienic permisje"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("username", $target));
        $item->setNamedTag($nbt);
        $inv->setItem(1, $item);

        $item = Item::get(Item::CHEST, 0, 1);
        $status = $this->plugin->getPermissionAsString($target, "chestopen");
        $item->setCustomName("§8§l» §bOtwieranie skrzynek ");
        $item->setLore(["§l ",
            "§8§l» §7Informacje: §bPozwala na otwieranie skrzyn na terenie gildii",
            "§8§l» §7Status: " . $status,
            "§8§l» §aKliknij, aby zmienic permisje"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("username", $target));
        $item->setNamedTag($nbt);
        $inv->setItem(2, $item);

        $item = Item::get(Item::FURNACE, 0, 1);
        $status = $this->plugin->getPermissionAsString($target, "furnaceopen");
        $item->setCustomName("§8§l» §bOtwieranie piecykow ");
        $item->setLore(["§l ",
            "§8§l» §7Informacje: §bPozwala na otwieranie piecykow na terenie gildii",
            "§8§l» §7Status: " . $status,
            "§8§l» §aKliknij, aby zmienic permisje"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("username", $target));
        $item->setNamedTag($nbt);
        $inv->setItem(3, $item);

        $item = Item::get(Item::TERRACOTTA, 14, 1);
        $item->setCustomName("§8§l» §bWylacz wszystko ");
        $item->setLore(["§l ",
            "§8§l» §7Informacje: §bWylacza dostep do wszystkiego",
            "§8§l» §aKliknij, aby zmienic wszystkie permisje"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("username", $target));
        $item->setNamedTag($nbt);
        $inv->setItem(25, $item);

        $item = Item::get(Item::TERRACOTTA, 5, 1);
        $item->setCustomName("§8§l» §aWlacz wszystko ");
        $item->setLore(["§l ",
            "§8§l» §7Informacje: §bWlacza dostep do wszystkiego",
            "§8§l» §aKliknij, aby zmienic wszystkie permisje"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("username", $target));
        $item->setNamedTag($nbt);
        $inv->setItem(26, $item);

        $item = Item::get(Item::TOTEM, 0, 1);
        $item->setCustomName("§8§l» §aPowrot do menu ");
        $item->setLore(["§l ",
            "§8§l» §aKliknij, aby wrocic do menu"]);
        $nbt = ($item->getNamedTag() ?? new CompoundTag());
        $nbt->setTag(new StringTag("username", $target));
        $item->setNamedTag($nbt);
        $inv->setItem(24, $item);
    }

    public function sendTo(Player $player): void
    {
        $this->menu->send($player);
    }
}