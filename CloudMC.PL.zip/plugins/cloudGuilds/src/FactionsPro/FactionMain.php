<?php

namespace FactionsPro;

use FactionsPro\Tasks\CenterTask;
use FactionsPro\Tasks\ExpireTask;
use JackMD\ScoreFactory\ScoreFactory;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\HappyVillagerParticle;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\AddItemActorPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\RemoveActorPacket;
use pocketmine\network\Network;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use SQLite3;

class FactionMain extends PluginBase implements Listener
{

    public $db, $fCommand;
    public $getTop = array(11);
    public $getLevelInTop = array(9999);
    public $home, $terenstatus, $taskid, $tntcooldown, $bossbarid, $particle, $particle2, $item, $fightcooldown, $compassType = [];

    public function onEnable()
    {
        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();
        $this->db = new SQLite3($this->getDataFolder() . "FactionsPro.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS master (player TEXT PRIMARY KEY COLLATE NOCASE, faction TEXT, rank TEXT, chat BOOLEAN, chat_type TEXT, chat_color TEXT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS confirm (player TEXT PRIMARY KEY COLLATE NOCASE, faction TEXT, invitedby TEXT, timestamp INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS motdrcv (player TEXT PRIMARY KEY, timestamp INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS motd (faction TEXT PRIMARY KEY, message TEXT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS plots(faction TEXT PRIMARY KEY, x1 INT, z1 INT, x2 INT, z2 INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS home(faction TEXT PRIMARY KEY, x INT, y INT, z INT, world VARCHAR);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS top(faction TEXT PRIMARY KEY, points INT, wins INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS expires(faction TEXT PRIMARY KEY, time INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS center(faction TEXT PRIMARY KEY, lives INT, timeWarProtection INT, timeWarWait INT, x INT, y INT, z INT, world VARCHAR);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS allies(ID INT PRIMARY KEY,faction1 TEXT, faction2 TEXT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS alliescountlimit(faction TEXT PRIMARY KEY, count INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS alliance(player TEXT PRIMARY KEY COLLATE NOCASE, faction TEXT, requestedby TEXT, timestamp INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS pvp(faction TEXT PRIMARY KEY, status INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS plotsize(faction TEXT PRIMARY KEY, status INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS createdate(faction TEXT PRIMARY KEY, time INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS scoreboard(player TEXT PRIMARY KEY, status INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS health(faction TEXT PRIMARY KEY, health INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS wars(ID INT PRIMARY KEY, faction1 TEXT, faction2 TEXT, status INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS warwait(faction TEXT PRIMARY KEY, time TEXT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS warstatus(warstat TEXT PRIMARY KEY, status INT);");
        $this->db->exec("CREATE TABLE IF NOT EXISTS permissions(player TEXT PRIMARY KEY, faction TEXT, build INT, break INT, chestopen INT, furnaceopen INT);");

        $this->getServer()->getPluginManager()->registerEvents(new FactionListener($this), $this);
        $this->fCommand = new FactionCommands($this);
        $task = new ExpireTask($this);
        $this->getScheduler()->scheduleDelayedRepeatingTask($task, 20 * 120, 20 * 120);
        date_default_timezone_set('Europe/Warsaw');
        $task = new CenterTask($this);
        $this->getScheduler()->scheduleDelayedRepeatingTask($task, 20 * 120, 20 * 120);
        $this->updateParticles();
    }

    public function updateParticles()
    {
        $faction = $this->db->query("SELECT * FROM expires;");
        while ($row = $faction->fetchArray(SQLITE3_ASSOC)) {
            $factionName = $row["faction"];
            $result = $this->db->query("SELECT * FROM center WHERE faction='$factionName';");
            $array = $result->fetchArray(SQLITE3_ASSOC);
            $x = $array["x"];
            $y = $array["y"];
            $z = $array["z"];
            $title = $this->getParticlesTitle($factionName);
            $text = $this->getParticlesText($factionName);

            $this->getServer()->getDefaultLevel()->addParticle(new HappyVillagerParticle(new Vector3($x + 0.5, $y + 1.1, $z + 0.5)));

            if (isset($this->particle[$factionName]) && isset($this->particle2[$factionName])) {
                if ($this->particle[$factionName] instanceof FloatingTextParticle && $this->particle2[$factionName] instanceof FloatingTextParticle) {
                    $this->particle2[$factionName]->setTitle($title);
                    $this->particle2[$factionName]->setInvisible(false);
                    $this->particle[$factionName]->setText($text);
                    $this->particle[$factionName]->setInvisible(false);
                    $this->getServer()->getDefaultLevel()->addParticle($this->particle[$factionName]);
                    $this->getServer()->getDefaultLevel()->addParticle($this->particle2[$factionName]);
                    $this->updateItem($factionName);
                }
            } else {
                $this->particle[$factionName] = new FloatingTextParticle(new Vector3($x + 0.5, $y + 1, $z + 0.5), $text, "");
                $this->getServer()->getDefaultLevel()->addParticle($this->particle[$factionName]);
                $this->particle2[$factionName] = new FloatingTextParticle(new Vector3($x + 0.5, $y + 2.5, $z + 0.5), "", $title);
                $this->getServer()->getDefaultLevel()->addParticle($this->particle2[$factionName]);
                $this->updateItem($factionName);
            }
        }
    }

    public function getParticlesTitle($faction)
    {
        return "§l§8[§l§b" . $faction . "§r§8] §b§l" . $this->getMOTD($faction);
    }

    public function getMOTD($faction)
    {
        $faction = $this->db->query("SELECT * FROM motd WHERE faction='$faction';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["message"];
    }

    public function getParticlesText($faction)
    {
        $currentTime = time();
        $timeWarProtection = $this->getFactionTimeWarProtection($faction);
        $timeWarProtectionDefault = $this->getConfig()->get("WarProtection");
        $differentTimeWarProtection = ($currentTime - $timeWarProtection);
        $lives = $this->getFactionWarLivesAsString($faction);
        $health = $this->getFactionHealthAsString($faction);
        $maxhealth = $this->getConfig()->get("MaxHealth");
        $expire = $this->getExpireAsString($faction);
        $protection = $this->getProtectionAsString($faction);
        if ($differentTimeWarProtection < $timeWarProtectionDefault) {
            $text = "§l§7HP: " . $health . "§7/§a" . $maxhealth . "§r\n§r§l§7Zycia: " . $lives . "§r\n§r§l§7Wygasa: " . $expire . "§r\n§r§l§7Ochrona: " . $protection . "";
            return $text;
        } else {
            $text = "§l§7HP: " . $health . "§7/§a" . $maxhealth . "§r\n§l§7Zycia: " . $lives . "§r\n§r§l§7Wygasa: " . $expire . "";
            return $text;
        }
    }

    public function getFactionTimeWarProtection($faction)
    {
        $faction = $this->db->query("SELECT * FROM center WHERE faction='$faction';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["timeWarProtection"];
    }

    public function getFactionWarLivesAsString($faction)
    {
        if ($this->getFactionWarLives($faction) == 1) {
            return "§c" . $this->getFactionWarLives($faction);
        } elseif ($this->getFactionWarLives($faction) == 2) {
            return "§e" . $this->getFactionWarLives($faction);
        } elseif ($this->getFactionWarLives($faction) == 3) {
            return "§a" . $this->getFactionWarLives($faction);
        }
    }

    public function getFactionsAll()
    {
        $this->plugin->getConfig()->set("Gildie", "off");
        $this->plugin->getConfig()->save();
        $this->plugin->getConfig()->reload();
    }

    public function getFactionWarLives($faction)
    {
        $faction = $this->db->query("SELECT * FROM center WHERE faction='$faction';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["lives"];
    }

    public function getFactionHealthAsString($faction)
    {
        if ($this->getFactionHealth($faction) / $this->getConfig()->get("MaxHealth") * 100 <= 25) {
            return "§c" . $this->getFactionHealth($faction);
        } elseif ($this->getFactionHealth($faction) / $this->getConfig()->get("MaxHealth") * 100 <= 50) {
            return "§6" . $this->getFactionHealth($faction);
        } elseif ($this->getFactionHealth($faction) / $this->getConfig()->get("MaxHealth") * 100 <= 75) {
            return "§e" . $this->getFactionHealth($faction);
        } elseif ($this->getFactionHealth($faction) / $this->getConfig()->get("MaxHealth") * 100 <= 100) {
            return "§a" . $this->getFactionHealth($faction);
        } elseif ($this->getFactionHealth($faction) > $this->getConfig()->get("MaxHealth")) {
            return "§a" . $this->getConfig()->get("MaxHealth");
        }
    }

    public function getFactionHealth($faction)
    {
        $result = $this->db->query("SELECT * FROM health WHERE faction='$faction';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["health"];
    }

    public function getExpireAsString($faction)
    {
        $time = $this->db->query("SELECT * FROM expires WHERE faction='$faction';");
        $array = $time->fetchArray(SQLITE3_ASSOC);
        if ($array["time"] / $this->getConfig()->get("Expires") * 100 <= 25) {
            return "§c" . floor($array["time"] / 1440) . "d, " . floor((($array["time"] / 1440) * 24) % 24) . "h, " . floor(((($array["time"] / 1440) * 24) * 60) % 60) . "m.";
        } elseif ($array["time"] / $this->getConfig()->get("Expires") * 100 <= 50) {
            return "§6" . floor($array["time"] / 1440) . "d, " . floor((($array["time"] / 1440) * 24) % 24) . "h, " . floor(((($array["time"] / 1440) * 24) * 60) % 60) . "m.";
        } elseif ($array["time"] / $this->getConfig()->get("Expires") * 100 <= 75) {
            return "§e" . floor($array["time"] / 1440) . "d, " . floor((($array["time"] / 1440) * 24) % 24) . "h, " . floor(((($array["time"] / 1440) * 24) * 60) % 60) . "m.";
        } elseif ($array["time"] / $this->getConfig()->get("Expires") * 100 <= 100) {
            return "§a" . floor($array["time"] / 1440) . "d, " . floor((($array["time"] / 1440) * 24) % 24) . "h, " . floor(((($array["time"] / 1440) * 24) * 60) % 60) . "m.";
        } elseif ($array["time"] > $this->getConfig()->get("Expires")) {
            return "§a" . floor($array["time"] / 1440) . "d, " . floor((($array["time"] / 1440) * 24) % 24) . "h, " . floor(((($array["time"] / 1440) * 24) * 60) % 60) . "m.";
        }
    }

    public function getProtectionAsString($faction)
    {
        $timeWarProtection = $this->getFactionTimeWarProtection($faction);
        $timeWarProtectionDefault = $this->getConfig()->get("WarProtection");
        $differentTimeWarProtection = time() - $timeWarProtection;

        if ($differentTimeWarProtection / $timeWarProtectionDefault * 100 <= 25) {
            return "§a" . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . "d, " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . "h, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . "m, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) % 60) . "s.";
        } elseif ($differentTimeWarProtection / $timeWarProtectionDefault * 100 <= 50) {
            return "§e" . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . "d, " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . "h, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . "m, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) % 60) . "s.";
        } elseif ($differentTimeWarProtection / $timeWarProtectionDefault * 100 <= 75) {
            return "§6" . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . "d, " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . "h, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . "m, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) % 60) . "s.";
        } elseif ($differentTimeWarProtection / $timeWarProtectionDefault * 100 <= 100) {
            return "§c" . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . "d, " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . "h, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . "m, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) % 60) . "s.";
        } elseif ($differentTimeWarProtection / $timeWarProtectionDefault * 100 > 100) {
            return "§c" . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . "d, " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . "h, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . "m, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) % 60) . "s.";
        }
    }

    public function updateItem($faction)
    {
        $result = $this->db->query("SELECT * FROM center WHERE faction='$faction';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        $x = $array["x"];
        $y = $array["y"];
        $z = $array["z"];
        $this->removeItem($faction);
        $this->item[$faction] = [];
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if ($player instanceof Player) {
                if (!isset($this->item[$faction][$player->getName()])) {
                    $id = mt_rand(1, 999999999);
                    $pk = new AddItemActorPacket();
                    $pk->entityRuntimeId = $id;
                    $pk->item = Item::get(Item::EMERALD, 0, 1);
                    $pk->position = new Position($x + 0.5, $y + 2.2, $z + 0.5);
                    $pk->metadata = [
                        Entity::DATA_FLAGS => [Entity::DATA_TYPE_LONG, (1 << Entity::DATA_FLAG_IMMOBILE)]
                    ];
                    $player->sendDataPacket($pk);
                    $this->item[$faction][$player->getName()] = $id;
                }
            }
        }
    }

    public function removeItem($faction)
    {
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if ($player instanceof Player) {
                if (isset($this->item[$faction][$player->getName()])) {
                    $id = $this->item[$faction][$player->getName()];
                    $pk = new RemoveActorPacket();
                    $pk->entityUniqueId = $id;
                    $player->sendDataPacket($pk);
                    unset($this->item[$faction][$player->getName()]);
                }
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args): bool
    {
        $this->fCommand->onCommand($sender, $command, $label, $args);
        return true;
    }

    public function api($plugin)
    {
        return $this->getServer()->getPluginManager()->getPlugin($plugin);
    }

    public function hasWars($faction)
    {
        $array = $this->db->query("SELECT * FROM wars WHERE faction2='$faction';");
        return empty($array) == false;
    }

    public function isInWar($faction)
    {
        $result = $this->db->query("SELECT * FROM wars WHERE faction2 = '$faction';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        return $resultArr["status"] == 1;
    }

    public function getWars($faction)
    {
        $array = $this->db->query("SELECT * FROM wars WHERE faction2='$faction';");
        $members = [
            "players" => "",
            "all" => 0
        ];
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            $members["players"] = $members["players"] . "§8[§b§l" . $row["faction1"] . "§r§8]§7, ";
            $members["all"]++;
        }
        $count = strlen($members["players"]);
        $members["players"] = substr($members["players"], 0, $count - 2);
        if (!empty($members["players"])) {
            return $members["players"];
        } else {
            return "Brak";
        }
    }

    public function addWars($faction1, $faction2)
    {
        $stmt = $this->db->prepare("INSERT INTO wars (faction1, faction2, status) VALUES (:faction1, :faction2, :status);");
        $stmt->bindValue(":faction1", $faction1);
        $stmt->bindValue(":faction2", $faction2);
        $stmt->bindValue(":status", 0);
        $result = $stmt->execute();
    }

    public function removeWars($faction)
    {
        $stmt = $this->db->prepare("DELETE FROM wars WHERE faction1 = '$faction' AND faction2 = '$faction';");
        $result = $stmt->execute();
    }

    public function areInWar($faction1, $faction2)
    {
        $result = $this->db->query("SELECT * FROM wars WHERE faction1 = '$faction1' AND faction2 = '$faction2';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        return (!empty($resultArr) && $resultArr["status"] == 1);
    }

    public function startWars($faction)
    {
        $this->db->query("UPDATE wars SET status = '1' WHERE faction2='$faction';");
    }

    public function setWarStatus(int $status)
    {
        $this->db->query("UPDATE warstatus SET status = '$status' WHERE warstat='warstat';");
    }

    public function getWarStatus()
    {
        $result = $this->db->query("SELECT * FROM warstatus WHERE warstat='warstat';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["status"];
    }

    public function setHealth($faction, $amount)
    {
        $this->db->query("UPDATE health SET health = '$amount' WHERE faction='$faction';");
    }

    public function addHealth($faction, $amount)
    {
        $this->db->query("UPDATE health SET health = health + '$amount' WHERE faction='$faction';");
    }

    public function removeHealth($faction, $amount)
    {
        $this->db->query("UPDATE health SET health = health - '$amount' WHERE faction='$faction';");
    }

    public function removeParticles($faction)
    {
        $particle = $this->particle[$faction];
        $particle2 = $this->particle2[$faction];
        if (isset($particle) && isset($particle2)) {
            if ($particle instanceof FloatingTextParticle && $particle2 instanceof FloatingTextParticle) {
                $particle->setInvisible(true);
                $particle2->setInvisible(true);
                $this->getServer()->getDefaultLevel()->addParticle($particle);
                $this->getServer()->getDefaultLevel()->addParticle($particle2);
                $result = $this->db->query("SELECT * FROM center WHERE faction='$faction';");
                $array = $result->fetchArray(SQLITE3_ASSOC);
                $x = $array["x"];
                $y = $array["y"];
                $z = $array["z"];
                $level = $this->getServer()->getDefaultLevel();
                $level->broadcastLevelSoundEvent(new Vector3($x, $y, $z), LevelSoundEventPacket::SOUND_BLAST);
                $level->broadcastLevelSoundEvent(new Vector3($x, $y, $z), LevelSoundEventPacket::SOUND_BLAST);
                $level->broadcastLevelSoundEvent(new Vector3($x, $y, $z), LevelSoundEventPacket::SOUND_BLAST);
                $this->removeItem($faction);
            }
        }
    }

    public function addScoreboard(Player $player)
    {
        $points = $this->getcloudPoints()->getPoints($player->getName());
        $kills = $this->getcloudPoints()->getKills($player->getName());
        $deaths = $this->getcloudPoints()->getDeaths($player->getName());
        $assists = $this->getcloudPoints()->getAssists($player->getName());
        $kda = $this->getcloudPoints()->getKD($player->getName());
        $money = $this->getCloudCore()->getMoney($player->getName());
        $money = round($money, 2);
        $rank = $this->getRankAsString($player);
        ScoreFactory::setScore($player, "§8[§l§bCloudMC.pl§r§8]§7");
        ScoreFactory::setScoreLine($player, 1, "§8 §8 §8 " . "§8");
        if ($this->isInFaction($player->getName())) {
            ScoreFactory::setScoreLine($player, 2, "§8§l» §7§lGildia:§b " . $this->getPlayerFaction($player->getName()) . " §r§8[§b§l" . $rank . "§r§8]§8 ");
        } else {
            ScoreFactory::setScoreLine($player, 2, "§8§l» §7§lGildia:§b Brak§8 ");
        }
        ScoreFactory::setScoreLine($player, 3, "§8§l» §7§lPunkty:§b " . $points . "§8");
        ScoreFactory::setScoreLine($player, 4, "§8§l» §7§lZabojstwa:§b " . $kills . "§8");
        ScoreFactory::setScoreLine($player, 5, "§8§l» §7§lSmierci:§b " . $deaths . "§8");
        ScoreFactory::setScoreLine($player, 6, "§8§l» §7§lAsysty:§b " . $assists . "§8");
        ScoreFactory::setScoreLine($player, 7, "§8§l» §7§lKDR:§b " . $kda . "§8");
        ScoreFactory::setScoreLine($player, 8, "§8§l» §7§lMonety:§b " . $money . "§7$");
        ScoreFactory::setScoreLine($player, 9, " §8 §8 §8 §8 " . "§8");
        ScoreFactory::setScoreLine($player, 10, "§8§l» §7§lPing:§b " . $player->getPing() . "§7ms" . "§8");
        ScoreFactory::setScoreLine($player, 11, "§8§l» §7§lOnline:§b " . count($this->getServer()->getOnlinePlayers()) . "§8");
        /* ScoreFactory::setScoreLine($player, 12, "§8§l» §7§lTPS:§b " . $this->getServer()->getTicksPerSecond() . "§8"); */
    }

    public function getcloudPoints()
    {
        return $this->getServer()->getPluginManager()->getPlugin("cloudPoints");
    }

    public function getCloudCore()
    {
        return $this->getServer()->getPluginManager()->getPlugin("cloudCore");
    }

    public function getRankAsString(Player $player)
    {
        if ($this->isLeader($player->getName())) {
            $rank = "Lider";
            return $rank;
        } elseif ($this->isOfficer($player->getName())) {
            $rank = "Oficer";
            return $rank;
        } else {
            $rank = "Czlonek";
            return $rank;
        }
    }

    public function isLeader($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $factionArray = $faction->fetchArray(SQLITE3_ASSOC);
        return $factionArray["rank"] == "Leader";
    }

    public function isOfficer($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $factionArray = $faction->fetchArray(SQLITE3_ASSOC);
        return $factionArray["rank"] == "Officer";
    }

    public function isInFaction($player)
    {
        $result = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function getPlayerFaction($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $factionArray = $faction->fetchArray(SQLITE3_ASSOC);
        return $factionArray["faction"];
    }

    public function getRankAsString2(String $player)
    {
        if ($this->isLeader($player)) {
            $rank = "Lider";
            return $rank;
        } elseif ($this->isOfficer($player)) {
            $rank = "Oficer";
            return $rank;
        } else {
            $rank = "Czlonek";
            return $rank;
        }
    }

    public function addToScoreboard(Player $player)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO scoreboard(player, status) VALUES (:player, :status);");
        $stmt->bindValue(":player", $player->getName());
        $stmt->bindValue(":status", 0);
        $result = $stmt->execute();
    }

    public function existsInPermissions(String $player)
    {
        $result = $this->db->query("SELECT * FROM permissions WHERE player='$player';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function addToPermissions(String $player, $faction)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO permissions(player, faction, build, break, chestopen, furnaceopen) VALUES (:player, :faction, :build, :break, :chestopen, :furnaceopen);");
        $stmt->bindValue(":player", $player);
        $stmt->bindValue(":faction", $faction);
        $stmt->bindValue(":build", 0);
        $stmt->bindValue(":break", 0);
        $stmt->bindValue(":chestopen", 0);
        $stmt->bindValue(":furnaceopen", 0);
        $result = $stmt->execute();
    }

    public function removeFromPermissions(String $player)
    {
        $stmt = $this->db->prepare("DELETE FROM permissions WHERE player = '$player';");
        $result = $stmt->execute();
    }

    public function getPermissionAsString(String $player, String $permission)
    {
        if ($permission == "build" or $permission == "break" or $permission == "chestopen" or $permission == "furnaceopen") {
            if ($this->getPermission($player, $permission) == 0) {
                return "§cWYLACZONY";
            } else {
                return "§aWLACZONY";
            }
        } else {
            $this->getLogger()->info("Unkown permission: " . $permission . " (Line: 470)");
        }
    }

    public function getPermission(String $player, String $permission)
    {
        if ($permission == "build" or $permission == "break" or $permission == "chestopen" or $permission == "furnaceopen") {
            $result = $this->db->query("SELECT * FROM permissions WHERE player = '$player';");
            $resultArr = $result->fetchArray(SQLITE3_ASSOC);
            return $resultArr[$permission];
        } else {
            $this->getLogger()->info("Unkown permission: " . $permission . " (Line: 470)");
        }
    }

    public function switchPermission(String $player, String $permission)
    {
        if ($permission == "build" or $permission == "break" or $permission == "chestopen" or $permission == "furnaceopen") {
            if ($this->getPermission($player, $permission) == 0) {
                $this->setPermission($player, $permission, 1);
            } else {
                $this->setPermission($player, $permission, 0);
            }
        } else {
            $this->getLogger()->info("Unkown permission: " . $permission . " (Line: 470)");
        }
    }

    public function setPermission(String $player, String $permission, int $status)
    {
        if ($permission == "build" or $permission == "break" or $permission == "chestopen" or $permission == "furnaceopen") {
            $this->db->query("UPDATE permissions SET '$permission' = '$status' WHERE player='$player';");
        } else {
            $this->getLogger()->info("Unkown permission: " . $permission . " (Line: 470)");
        }
    }

    public function setAllPermissions(String $player, int $status)
    {
        $this->setPermission($player, "build", $status);
        $this->setPermission($player, "break", $status);
        $this->setPermission($player, "chestopen", $status);
        $this->setPermission($player, "furnaceopen", $status);
    }

    public function existsInScoreboard(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM scoreboard WHERE player='$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function changeScoreboard(Player $player, int $status)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO scoreboard(player, status) VALUES (:player, :status);");
        $stmt->bindValue(":player", $player->getName());
        $stmt->bindValue(":status", $status);
        $result = $stmt->execute();
    }

    public function getScoreboardStatus(Player $player)
    {
        $name = $player->getName();
        $result = $this->db->query("SELECT * FROM scoreboard WHERE player = '$name';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        return $resultArr["status"];
    }

    public function getCreateDate($faction)
    {
        $result = $this->db->query("SELECT * FROM createdate WHERE faction = '$faction';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        return $resultArr["time"];
    }

    public function startTNTCooldown($faction)
    {
        $this->tntcooldown[$faction] = time();
    }

    public function getTNTCooldownTime($faction)
    {
        if (isset($this->tntcooldown[$faction])) {
            return $this->tntcooldown[$faction];
        }
    }

    public function hasTNTCooldown($faction)
    {
        if (!isset($this->tntcooldown[$faction])) {
            return false;
        } else {
            if (time() - $this->tntcooldown[$faction] <= $this->getConfig()->get("TNTExplosionCooldown")) {
                return true;
            } else {
                return false;
            }
        }
    }

    public function sendTipToFaction($string, $faction, $formatMessage = true)
    {
        $array = $this->db->query("SELECT * FROM master WHERE faction='$faction';");
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            if ($this->getServer()->getPlayer($row["player"])) {
                if ($formatMessage == true) {
                    $this->getServer()->getPlayer($row["player"])->sendTip($this->formatMessage($string, true));
                } else {
                    $this->getServer()->getPlayer($row["player"])->sendTip($string);
                }
            }
        }
    }

    public function formatMessage($string, $confirm = false)
    {
        $success = $this->getConfig()->get("PrefixSuccess");
        $failure = $this->getConfig()->get("PrefixFailure");
        if ($confirm) {
            return str_replace('{STRING}', $string, $success);
        } else {
            return str_replace('{STRING}', $string, $failure);
        }
    }

    public function sendPopupToFaction($string, $faction, $formatMessage = true)
    {
        $array = $this->db->query("SELECT * FROM master WHERE faction='$faction';");
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            if ($this->getServer()->getPlayer($row["player"])) {
                if ($formatMessage == true) {
                    $this->getServer()->getPlayer($row["player"])->sendPopup($this->formatMessage($string, true));
                } else {
                    $this->getServer()->getPlayer($row["player"])->sendPopup($string);
                }
            }
        }
    }

    public function sendListOfItemsToCreateFaction(Player $player)
    {
        /* Zmienne */
        $diamonds = [];
        $gold = [];
        $iron = [];
        $emeralds = [];
        $coal = [];

        $diamonds[$player->getName()] = 0;
        $gold[$player->getName()] = 0;
        $iron[$player->getName()] = 0;
        $emeralds[$player->getName()] = 0;
        $coal[$player->getName()] = 0;
        foreach ($player->getInventory()->getContents() as $items) {
            if ($items->getId() == 57) {
                $diamonds[$player->getName()] = $diamonds[$player->getName()] + $items->getCount();
            }
            if ($items->getId() == 41) {
                $gold[$player->getName()] = $gold[$player->getName()] + $items->getCount();
            }
            if ($items->getId() == 42) {
                $iron[$player->getName()] = $iron[$player->getName()] + $items->getCount();
            }
            if ($items->getId() == 133) {
                $emeralds[$player->getName()] = $emeralds[$player->getName()] + $items->getCount();
            }
            if ($items->getId() == 173) {
                $coal[$player->getName()] = $coal[$player->getName()] + $items->getCount();
            }
        }
        $player->sendMessage("§8[ §7---------- §8[§b§lItemy§r§8] §7---------- §8]");
        $player->sendMessage("§b* §7Diamentowe Bloki:§b " . $diamonds[$player->getName()] . "§7/§b64");
        $player->sendMessage("§b* §7Szmaragdowe Bloki:§b " . $emeralds[$player->getName()] . "§7/§b64");
        $player->sendMessage("§b* §7Zlote Bloki:§b " . $gold[$player->getName()] . "§7/§b64");
        $player->sendMessage("§b* §7Zelazne Bloki:§b " . $iron[$player->getName()] . "§7/§b64");
        $player->sendMessage("§b* §7Weglowe Bloki:§b " . $coal[$player->getName()] . "§7/§b64");
        $player->sendMessage("§8[ §7---------- §8[§b§lItemy§r§8] §7---------- §8]");
    }

    public function updatePVP(Player $player, $faction)
    {
        if ($this->getPVP($faction) == 0) {
            $this->setPVP($faction, 1);
            $this->sendMessageToFaction($player->getName() . " wlaczyl pvp w gildii!", $faction, true);
        } else {
            $this->setPVP($faction, 0);
            $this->sendMessageToFaction($player->getName() . " wylaczyl pvp w gildii!", $faction, true);
        }
    }

    public function getPVP($faction)
    {
        $result = $this->db->query("SELECT * FROM pvp WHERE faction = '$faction';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        return $resultArr["status"];
    }

    public function setPVP($faction, $status)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO pvp(faction, status) VALUES (:faction, :status);");
        $stmt->bindValue(":faction", $faction);
        $stmt->bindValue(":status", $status);
        $result = $stmt->execute();
    }

    public function sendMessageToFaction($string, $faction, $formatMessage = true)
    {
        $array = $this->db->query("SELECT * FROM master WHERE faction='$faction';");
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            if ($this->getServer()->getPlayer($row["player"])) {
                if ($formatMessage == true) {
                    $this->getServer()->getPlayer($row["player"])->sendMessage($this->formatMessage($string, true));
                } else {
                    $this->getServer()->getPlayer($row["player"])->sendMessage($string);
                }
            }
        }
    }

    public function getHomeStatus($player)
    {
        return $this->home[$player];
    }

    public function setHomeStatus($player, $stan)
    {
        $this->home[$player] = $stan;
    }

    public function setTerenStatus($player, $stan)
    {
        $this->terenstatus[$player] = $stan;
    }

    public function getTerenStatus($player)
    {
        if (isset($this->terenstatus[$player])) {
            return $this->terenstatus[$player];
        }
    }

    public function setAllies($faction1, $faction2)
    {
        $stmt = $this->db->prepare("INSERT INTO allies (faction1, faction2) VALUES (:faction1, :faction2);");
        $stmt->bindValue(":faction1", $faction1);
        $stmt->bindValue(":faction2", $faction2);
        $result = $stmt->execute();
    }

    public function areAllies($faction1, $faction2)
    {
        $result = $this->db->query("SELECT * FROM allies WHERE faction1 = '$faction1' AND faction2 = '$faction2';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        if (empty($resultArr) == false) {
            return true;
        }
    }

    public function updateAllies($faction)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO alliescountlimit(faction, count) VALUES (:faction, :count);");
        $stmt->bindValue(":faction", $faction);
        $result = $this->db->query("SELECT * FROM allies WHERE faction1='$faction';");
        $i = 0;
        while ($resultArr = $result->fetchArray(SQLITE3_ASSOC)) {
            $i = $i + 1;
        }
        $stmt->bindValue(":count", (int)$i);
        $result = $stmt->execute();
    }

    public function getAlliesCount($faction)
    {

        $result = $this->db->query("SELECT * FROM alliescountlimit WHERE faction = '$faction';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        return (int)$resultArr["count"];
    }

    public function getAlliesLimit()
    {
        return (int)$this->getConfig()->get("AllyLimitPerFaction");
    }

    public function deleteAllies($faction1, $faction2)
    {
        $stmt = $this->db->prepare("DELETE FROM allies WHERE faction1 = '$faction1' AND faction2 = '$faction2';");
        $result = $stmt->execute();
    }

    public function packetFakeExplode(String $level, int $x, int $y, int $z, int $radius)
    {
        $pk = new ExplodePacket;
        $pk->x = $x;
        $pk->y = $y;
        $pk->z = $z;
        $pk->radius = $radius;
        $pk->records = [new Vector3($x, $y, $z)];
        $this->getServer()->broadcastPacket($this->getServer()->getLevelByName($level)->getChunkPlayers($x >> 4, $z >> 4), $pk->setChannel(Network::$BATCH_THRESHOLD));
    }

    public function getAllAllies($faction)
    {
        $array = $this->db->query("SELECT * FROM allies WHERE faction2='$faction';");
        $members = array(
            "players" => "",
            "online" => 0,
            "all" => 0,
        );
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            $members["players"] = $members["players"] . TextFormat::YELLOW . "§8[§c" . $row["faction1"] . "§8] §c" . $this->getMOTD($row["faction1"]) . TextFormat::GRAY . ", ";
            $members["online"]++;
            $members["all"]++;
        }
        $count = strlen($members["players"]);
        $members["players"] = substr($members["players"], 0, $count - 2);
        #$members["all"]
        #$members["online"]
        #$members["players"]
        if (!empty($members["players"])) {
            return $members["players"];
        } else {
            return "Brak";
        }
    }

    public function getFactionTimeWarWait($faction)
    {
        $faction = $this->db->query("SELECT * FROM center WHERE faction='$faction';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["timeWarWait"];
    }

    public function getFactionChatType($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["chat_type"];
    }

    public function getFactionChatColor($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["chat_color"];
    }

    public function getFactionChat($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["chat"];
    }

    public function getFactionTop()
    {
        $faction = $this->db->query("SELECT * FROM top ORDER BY points DESC LIMIT 10");
        $this->getTop[11] = 0;
        while ($row = $faction->fetchArray(SQLITE3_BOTH)) {
            $this->getTop[11]++;
            $this->getTop[$this->getTop[11]] = "&7Gildia &b" . $row[0] . "&7 (Punkty&b " . $this->getFactionPoints($row[0]) . "&7)";
        }
    }

    public function getFactionPoints($faction)
    {
        $array = $this->db->query("SELECT * FROM top WHERE faction='$faction';");
        $array = $array->fetchArray(SQLITE3_ASSOC);
        return round($array["points"], 1);
    }

    public function getTopLevel($faction)
    {
        $players = $this->db->query("SELECT * FROM top ORDER BY points DESC LIMIT 9999");
        $this->getLevelInTop[9999] = 0;
        while ($row = $players->fetchArray(SQLITE3_BOTH)) {
            $this->getLevelInTop[9999]++;
            $this->getLevelInTop[$this->getLevelInTop[9999]] = $row[0];
        }
        for ($i = 1; $i < 9999; $i++) {
            if ($this->getLevelInTop[$i] == $faction) {
                return $i;
            }
        }
    }

    public function addPoints($faction, int $amount)
    {
        $this->db->query("UPDATE top SET points = points + '$amount' WHERE faction='$faction';");
    }

    public function reducePoints($faction, int $amount)
    {
        $this->db->query("UPDATE top SET points = points + '-$amount' WHERE faction='$faction';");
    }

    public function setPoints($faction, int $amount)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO top (faction, points, wins) VALUES (:faction, :points, :wins);");
        $stmt->bindValue(":faction", $faction);
        $stmt->bindValue(":points", $amount);
        $stmt->bindValue(":wins", $this->getFactionWins($faction));
        $result = $stmt->execute();
    }

    public function getFactionWins($faction)
    {
        $faction = $this->db->query("SELECT * FROM top WHERE faction='$faction';");
        $array = $faction->fetchArray(SQLITE3_ASSOC);
        return $array["wins"];
    }

    public function isMember($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $factionArray = $faction->fetchArray(SQLITE3_ASSOC);
        return $factionArray["rank"] == "Member";
    }

    public function getRank($player)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player';");
        $factionArray = $faction->fetchArray(SQLITE3_ASSOC);
        return $factionArray["rank"];
    }

    public function getLeader($faction)
    {
        $leader = $this->db->query("SELECT * FROM master WHERE faction='$faction' AND rank='Leader';");
        $leaderArray = $leader->fetchArray(SQLITE3_ASSOC);
        return $leaderArray['player'];
    }

    public function getOfficer($faction)
    {
        $array = $this->db->query("SELECT * FROM master WHERE faction='$faction' AND rank='Officer';");
        $members = array(
            "players" => "",
            "online" => 0,
            "all" => 0,
        );
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            $members["players"] = $members["players"] . TextFormat::YELLOW . $row["player"] . TextFormat::GRAY . ", ";
            $members["online"]++;
            $members["all"]++;
        }
        $count = strlen($members["players"]);
        $members["players"] = substr($members["players"], 0, $count - 2);
        #$members["all"]
        #$members["online"]
        #$members["players"]
        if (!empty($members["players"])) {
            return $members["players"];
        } else {
            return "BRAK";
        }
    }

    public function factionExists($faction)
    {
        $result = $this->db->query("SELECT * FROM master WHERE faction='$faction';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function sameFaction($player1, $player2)
    {
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player1';");
        $player1Faction = $faction->fetchArray(SQLITE3_ASSOC);
        $faction = $this->db->query("SELECT * FROM master WHERE player='$player2';");
        $player2Faction = $faction->fetchArray(SQLITE3_ASSOC);
        return $player1Faction["faction"] == $player2Faction["faction"];
    }

    public function isFactionFull($faction)
    {
        return $this->getNumberOfPlayers($faction) >= $this->getConfig()->get("MaxPlayersPerFaction");
    }

    public function getNumberOfPlayers($faction)
    {
        $array = $this->db->query("SELECT * FROM master WHERE faction='$faction';");
        $i = 0;
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            $i++;
        }
        return $i;
    }

    public function nearPlot(Player $player)
    {
        $playerX = $player->getX();
        $playerZ = $player->getZ();
        $maxDistance = 120;
        $result = $this->db->query("SELECT faction, x1, z1, x2, z2 FROM plots WHERE ((x1 + (x2 - x1) / 2) - $playerX) * ((x1 + (x2 - x1) / 2) - $playerX) + ((z1 + (z2 - z1) / 2) - $playerZ) * ((z1 + (z2 - z1) / 2) - $playerZ) <= $maxDistance * $maxDistance;");
        $factionPlots = [];
        $i = 0;
        while ($res = $result->fetchArray(SQLITE3_ASSOC)) {
            if (!isset($res['faction'])) continue;
            $factionPlots[$i]['faction'] = $res['faction'];
            $factionPlots[$i]['x1'] = $res['x1'];
            $factionPlots[$i]['x2'] = $res['x2'];
            $factionPlots[$i]['z1'] = $res['z1'];
            $factionPlots[$i]['z2'] = $res['z2'];
            $i++;
        }
        return $factionPlots == null;
    }

    public function updatePlotSize(Player $player, $faction)
    {
        $result = $this->db->query("SELECT * FROM plotsize WHERE faction = '$faction';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        $result2 = $this->db->query("SELECT * FROM center WHERE faction = '$faction';");
        $resultArr2 = $result2->fetchArray(SQLITE3_ASSOC);
        $x = $resultArr2["x"];
        $z = $resultArr2["z"];
        if (!empty($resultArr)) {
            if ($this->getPlotSize($faction) != $this->getConfig()->get("MaxPlotSize")) {
                if ($player->getInventory()->contains(Item::get(Item::DIAMOND, 0, 64)) && $player->getInventory()->contains(Item::get(Item::EMERALD, 0, 64))) {
                    $size = $this->getPlotSize($faction);
                    $newsize = $size + $this->getConfig()->get("PlotUpdateEvery");
                    $this->setPlotSize($faction, $newsize);
                    $this->drawPlot($faction, $x, $z, $newsize);
                    $this->getServer()->broadcastMessage($this->formatMessage("Gildia " . $faction . " powiekszyla teren swojej gildii do " . $newsize . "!", true));
                    $player->getInventory()->removeItem(Item::get(Item::DIAMOND, 0, 64));
                    $player->getInventory()->removeItem(Item::get(Item::EMERALD, 0, 64));
                } else {
                    $player->sendMessage($this->formatMessage("Aby powiekszyc teren gildii potrzebujesz 64 diamenty oraz 64 emeraldy!", false));
                }
            } else {
                $player->sendMessage($this->formatMessage("Osiaganales maksymalna wielkosc terenu gildii! (" . $this->getConfig()->get("MaxPlotSize") . ") ", false));
            }
        }
    }

    public function getPlotSize($faction)
    {
        $result = $this->db->query("SELECT * FROM plotsize WHERE faction = '$faction';");
        $resultArr = $result->fetchArray(SQLITE3_ASSOC);
        return $resultArr["status"];
    }

    public function setPlotSize($faction, $size)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO plotsize(faction, status) VALUES (:faction, :status);");
        $stmt->bindValue(":faction", $faction);
        $stmt->bindValue(":status", $size);
        $result = $stmt->execute();
    }

    public function drawPlot($faction, $x, $z, $size)
    {
        $arm = ($size - 1) / 2;
        $this->newPlot($faction, $x + $arm, $z + $arm, $x - $arm, $z - $arm);
        return true;
    }

    public function newPlot($faction, $x1, $z1, $x2, $z2)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO plots (faction, x1, z1, x2, z2) VALUES (:faction, :x1, :z1, :x2, :z2);");
        $stmt->bindValue(":faction", $faction);
        $stmt->bindValue(":x1", $x1);
        $stmt->bindValue(":z1", $z1);
        $stmt->bindValue(":x2", $x2);
        $stmt->bindValue(":z2", $z2);
        $result = $stmt->execute();
    }

    public function isInPlot($x, $z)
    {
        $result = $this->db->query("SELECT * FROM plots WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    public function inOwnPlot($player, $x, $z)
    {
        $playerName = $player->getName();
        return $this->getPlayerFaction($playerName) == $this->factionFromPoint($x, $z);
    }

    public function factionFromPoint($x, $z)
    {
        $result = $this->db->query("SELECT * FROM plots WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["faction"];
    }

    public function cornerIsInPlot($x1, $z1, $x2, $z2)
    {
        return ($this->pointIsInPlot($x1, $z1) || $this->pointIsInPlot($x1, $z2) || $this->pointIsInPlot($x2, $z1) || $this->pointIsInPlot($x2, $z2));
    }

    public function pointIsInPlot($x, $z)
    {

        $result = $this->db->query("SELECT * FROM plots WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return !empty($array);
    }

    public function motdWaiting($player)
    {
        $stmt = $this->db->query("SELECT * FROM motdrcv WHERE player='$player';");
        $array = $stmt->fetchArray(SQLITE3_ASSOC);
        return !empty($array);
    }

    public function setMOTD($faction, $player, $msg)
    {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO motd (faction, message) VALUES (:faction, :message);");
        $stmt->bindValue(":faction", $faction);
        $stmt->bindValue(":message", $msg);
        $result = $stmt->execute();
        $this->db->query("DELETE FROM motdrcv WHERE player='$player';");
    }

    public function onDisable()
    {
        $this->db->close();
    }
}