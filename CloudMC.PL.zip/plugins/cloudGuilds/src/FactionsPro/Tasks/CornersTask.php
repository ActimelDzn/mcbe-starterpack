<?php

namespace FactionsPro\Tasks;

use FactionsPro\FactionMain;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class CornersTask extends Task
{

    private $plugin;

    public function __construct(FactionMain $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick)
    {
        $center = $this->plugin->db->query("SELECT * FROM center;");
        while ($row = $center->fetchArray(SQLITE3_ASSOC)) {
            $faction = $row["faction"];
            $plot = $this->plugin->getPlotSize($faction);
            $arm = floor(($plot - 1) / 2);
            $x = floor($row["x"]);
            $y = floor($row["y"]);
            $z = floor($row["z"]);
            $world = $row["world"];
            for ($i = 1; $i < 256; $i++) {
                $firstcorner = new Vector3($x + $arm, $i, $z + $arm);
                $secondcorner = new Vector3($x + $arm, $i, $z - $arm);
                $thirdcorner = new Vector3($x - $arm, $i, $z + $arm);
                $fourthcorner = new Vector3($x - $arm, $i, $z - $arm);
                if ($this->plugin->getServer()->getLevelByName($world)->getBlock($firstcorner)->getId() != 49) {
                    $this->plugin->getServer()->getLevelByName($world)->setBlock($firstcorner, Block::get(49, 0));
                }
                if ($this->plugin->getServer()->getLevelByName($world)->getBlock($secondcorner)->getId() != 49) {
                    $this->plugin->getServer()->getLevelByName($world)->setBlock($secondcorner, Block::get(49, 0));
                }
                if ($this->plugin->getServer()->getLevelByName($world)->getBlock($thirdcorner)->getId() != 49) {
                    $this->plugin->getServer()->getLevelByName($world)->setBlock($thirdcorner, Block::get(49, 0));
                }
                if ($this->plugin->getServer()->getLevelByName($world)->getBlock($fourthcorner)->getId() != 49) {
                    $this->plugin->getServer()->getLevelByName($world)->setBlock($fourthcorner, Block::get(49, 0));
                }
            }
        }
    }
}

