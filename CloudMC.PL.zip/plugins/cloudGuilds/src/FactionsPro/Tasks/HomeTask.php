<?php

namespace FactionsPro\Tasks;

use FactionsPro\FactionMain;
use pocketmine\entity\Effect;
use pocketmine\level\Position;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class HomeTask extends Task
{

    private $plugin;
    private $player;
    private $position;
    private $time;

    public function __construct(FactionMain $plugin, Player $player, Position $position, int $time)
    {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->position = $position;
        $this->time = $time;
    }

    public function onRun(int $currentTick)
    {
        if ($this->getServer()->getPlayer($this->getPlayer()->getName()) instanceof Player) {
            if ($this->getPlugin()->home[$this->getPlayer()->getName()] == 0) {
                if ($this->getTime() > 1) {
                    $this->updateTime();
                    $this->getPlayer()->addTitle("§l§7Teleportacja nastapi za §b" . $this->getTime() . " §7sekund ", "§7Nie ruszaj sie!");
                } else {
                    $this->updateTime();
                    if ($this->getPlayer()->hasEffect(Effect::NAUSEA)) {
                        $this->getPlayer()->removeEffect(Effect::NAUSEA);
                    }
                    $this->getPlayer()->getLevel()->broadcastLevelSoundEvent($this->getPlayer()->getPosition()->asVector3(), LevelSoundEventPacket::SOUND_LAUNCH);
                    $this->getPlayer()->addTitle("§l§7Teleportacja udana!");
                    $this->getPlayer()->teleport($this->getPosition()->asVector3());
                    $this->getPlugin()->home[$this->getPlayer()->getName()] = 1;
                    $this->getHandler()->cancel();
                }
            } else {
                $this->getHandler()->cancel();
            }
        } else {
            $this->getHandler()->cancel();
        }
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }

    public function getPlayer()
    {
        return $this->player;
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function getTime()
    {
        return $this->time;
    }

    public function updateTime()
    {
        $this->time--;
    }

    public function getPosition()
    {
        return $this->position;
    }
}

