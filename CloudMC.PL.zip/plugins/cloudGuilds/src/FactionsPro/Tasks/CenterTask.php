<?php

namespace FactionsPro\Tasks;

use FactionsPro\FactionMain;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class CenterTask extends Task
{

    private $plugin;

    public function __construct(FactionMain $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRun(int $currentTick)
    {
        $this->getPlugin()->updateParticles();
        $array = $this->getPlugin()->db->query("SELECT * FROM health;");
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            $faction = $row["faction"];
            if (!$this->plugin->isInWar($faction)) {
                if ($this->getPlugin()->getFactionHealth($faction) < $this->getPlugin()->getConfig()->get("MaxHealth")) {
                    $this->getPlugin()->addHealth($faction, 2);
                } elseif ($this->getPlugin()->getFactionHealth($faction) > $this->getPlugin()->getConfig()->get("MaxHealth")) {
                    $this->getPlugin()->setHealth($faction, $this->getPlugin()->getConfig()->get("MaxHealth"));
                }
            }
        }
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }
}

