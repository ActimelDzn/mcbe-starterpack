<?php

namespace FactionsPro\Tasks;

use FactionsPro\FactionMain;
use JackMD\ScoreFactory\ScoreFactory;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class ScoreboardTask extends Task
{

    private $plugin, $player;

    public function __construct(FactionMain $plugin, Player $player)
    {
        $this->plugin = $plugin;
        $this->player = $player;
    }

    public function onRun(int $currentTick)
    {
        if ($this->getServer()->getPlayer($this->getPlayer()->getName()) instanceof Player) {
            if ($this->getPlugin()->getScoreboardStatus($this->getPlayer()) == 0) {
                $this->getPlugin()->addScoreboard($this->getPlayer());
            } else {
                if (ScoreFactory::hasScore($this->getPlayer())) {
                    ScoreFactory::removeScore($this->getPlayer());
                    $this->getHandler()->cancel();
                }
            }
        } else {
            $this->getHandler()->cancel();
        }
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }

    public function getPlayer()
    {
        return $this->player;
    }

    public function getPlugin()
    {
        return $this->plugin;
    }
}

