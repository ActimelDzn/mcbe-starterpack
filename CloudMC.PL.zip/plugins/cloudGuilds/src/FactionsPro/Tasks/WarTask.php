<?php

namespace FactionsPro\Tasks;

use FactionsPro\FactionMain;
use pocketmine\scheduler\Task;

class WarTask extends Task
{

    private $plugin;

    public function __construct(FactionMain $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onRun(int $currentTick)
    {
        $array = $this->getPlugin()->db->query("SELECT * FROM center;");
        if (date("H", time()) >= 18 && date("H", time()) < 23 && date("i", time()) == 28) {
            if ($this->getPlugin()->getWarStatus() == 0) {
                for ($i = 0; $i <= 100; $i++) {
                    $this->getServer()->broadcastMessage("§l ");
                }
                $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Wszystkie wojny zostaly rozpoczete!", true));
                while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                    $faction = $row["faction"];
                    if ($this->getPlugin()->hasWars($faction)) {
                        if (!$this->getPlugin()->isInWar($faction)) {
                            $this->getPlugin()->sendMessageToFaction("Twoje wojny z: " . $this->getPlugin()->getWars($faction) . " zostaly rozpoczete pomyslnie!", $faction, true);
                            $this->getPlugin()->startWars($faction);
                            $this->getPlugin()->setWarStatus(1);
                        }
                    }
                }
            }
        } else {
            if ($this->getPlugin()->getWarStatus() == 1) {
                $array = $this->getPlugin()->db->query("SELECT * FROM center;");
                while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                    $faction = $row["faction"];
                    $this->getPlugin()->removeWars($faction);
                }
                for ($i = 0; $i <= 100; $i++) {
                    $this->getServer()->broadcastMessage("§l ");
                }
                $this->getServer()->broadcastMessage($this->getPlugin()->formatMessage("Wszystkie wojny zostaly zakonczone!", true));
                $this->getPlugin()->setWarStatus(0);
            }
        }
    }

    public function getPlugin()
    {
        return $this->plugin;
    }

    public function getServer()
    {
        return $this->plugin->getServer();
    }
}

