<?php

namespace FactionsPro;

use FactionsPro\GUIListeners\CompassListener;
use FactionsPro\Tasks\ScoreboardTask;
use pocketmine\block\Block;
use pocketmine\entity\Arrow;
use pocketmine\entity\Effect;
use pocketmine\entity\utils\Bossbar;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityExplodeEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\entity\ExplosionPrimeEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\level\Explosion;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\BossEventPacket;
use pocketmine\Player;

class FactionListener implements Listener
{

    public $plugin;
    private $address_ip = [];

    public function __construct(FactionMain $pg)
    {
        $this->plugin = $pg;
    }

    public function factionChat(PlayerChatEvent $event)
    {
        $player = $event->getPlayer();
        $message = $event->getMessage();
        $faction = $this->plugin->getPlayerFaction($player->getName());
        if ($this->plugin->isInFaction($player->getName())) {
            if ($message[0] == "#") {
                $event->setCancelled();
                if (strlen($message) > 1) {
                    if ($message[1] != "#") {
                        $this->plugin->sendMessageToFaction("§8[§aCzat Gildii§8] §8[§a" . $this->plugin->getRankAsString($player) . "§8] §f" . $player->getName() . ": " . str_replace("#", "", $message), $faction, false);
                    }
                    if ($message[1] == "#") {
                        foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                            if ($this->plugin->areAllies($faction, $this->plugin->getPlayerFaction($p->getName())) or $this->plugin->sameFaction($player->getName(), $p->getName())) {
                                $p->sendMessage("§8[§3Czat Sojuszy§8] §8[§3" . $faction . "§8] §f" . $player->getName() . ": " . str_replace("#", "", $message));
                            }
                        }
                    }
                } else {
                    $player->sendMessage($this->plugin->formatMessage("Twoja wiadomosc jest zbyt krotka!", false));
                }
            }
            if ($message[0] == "!") {
                $event->setCancelled();
                $faction = $this->plugin->getPlayerFaction($event->getPlayer()->getName());
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                    if ($this->plugin->sameFaction($player->getName(), $p->getName()) or $this->plugin->areAllies($faction, $this->plugin->getPlayerFaction($p->getName()))) {
                        $p->sendMessage("§8[§3Czat Sojuszy§8] §8[§3" . $faction . "§8] §f" . $player->getName() . " potrzebuje pomocy! X: §3" . floor($player->getX()) . " §fY: §3" . floor($player->getY()) . " §fZ: §3" . floor($player->getZ()) . " §8(§fDystans: §3" . floor($p->distance($player->getPosition())) . " §fkratek§8)");
                    }
                }
            }
        }
    }

    public function factionPVP(EntityDamageEvent $factionDamage)
    {
        if ($factionDamage instanceof EntityDamageByEntityEvent) {
            if ($factionDamage->getDamager() instanceof Player) {
                if (isset($this->plugin->bossbarid[$factionDamage->getDamager()->getName()])) {
                    $pk = new BossEventPacket();
                    $pk->bossEid = $this->plugin->bossbarid[$factionDamage->getDamager()->getName()];
                    $pk->eventType = BossEventPacket::TYPE_HIDE;
                    $factionDamage->getDamager()->sendDataPacket($pk);
                    unset($this->plugin->bossbarid[$factionDamage->getDamager()->getName()]);
                }
            }
            if ($factionDamage->getEntity() instanceof Player) {
                if (isset($this->plugin->bossbarid[$factionDamage->getEntity()->getName()])) {
                    $pk = new BossEventPacket();
                    $pk->bossEid = $this->plugin->bossbarid[$factionDamage->getEntity()->getName()];
                    $pk->eventType = BossEventPacket::TYPE_HIDE;
                    $factionDamage->getEntity()->sendDataPacket($pk);
                    unset($this->plugin->bossbarid[$factionDamage->getEntity()->getName()]);
                }
            }
            if (!($factionDamage->getEntity() instanceof Player) or !($factionDamage->getDamager() instanceof Player)) {
                return true;
            }
            if (($this->plugin->isInFaction($factionDamage->getEntity()->getPlayer()->getName()) == false) or ($this->plugin->isInFaction($factionDamage->getDamager()->getPlayer()->getName()) == false)) {
                return true;
            }
            if (($factionDamage->getEntity() instanceof Player) and ($factionDamage->getDamager() instanceof Player)) {
                $player1 = $factionDamage->getEntity()->getPlayer()->getName();
                $player2 = $factionDamage->getDamager()->getPlayer()->getName();
                $pvpdata = $this->plugin->getPVP($this->plugin->getPlayerFaction($player1));
                $pvpdata2 = $this->plugin->getPVP($this->plugin->getPlayerFaction($player2));
                $f1 = $this->plugin->getPlayerFaction($player1);
                $f2 = $this->plugin->getPlayerFaction($player2);
                if ($pvpdata == 0 && $pvpdata2 == 0 && $this->plugin->sameFaction($player1, $player2) or $this->plugin->areAllies($f1, $f2)) {
                    $factionDamage->setCancelled(true);
                }
            }
        }
    }

    public function factionBlockBreakProtect(BlockBreakEvent $event)
    {
        if ($this->plugin->isInPlot($event->getBlock()->getFloorX(), $event->getBlock()->getFloorZ())) {
            $x = floor($event->getBlock()->getX());
            $y = floor($event->getBlock()->getY());
            $z = floor($event->getBlock()->getZ());
            $claimedBy = $this->plugin->factionFromPoint($x, $z);
            $motd = $this->plugin->getMotd($claimedBy);
            $world = $event->getBlock()->getLevel()->getName();
            $center = $this->plugin->db->query("SELECT * FROM center WHERE x='$x' AND y='$y' AND z='$z' AND world='$world';");
            $array = $center->fetchArray(SQLITE3_ASSOC);
            if (!empty($array)) {
                $event->setCancelled(true);
            }
            if ($this->plugin->inOwnPlot($event->getPlayer(), $event->getBlock()->getFloorX(), $event->getBlock()->getFloorZ())) {
                return true;
            } elseif ($event->getPlayer()->hasPermission("f.override")) {
                return true;
            } else {
                $event->setCancelled(true);
                $event->getPlayer()->sendPopup("§7Teren gildii:§c " . $claimedBy . " §7- §c" . $motd . "§r");
                return true;
            }
        }
    }

    public function factionBlockPlaceProtect(BlockPlaceEvent $event)
    {
        if ($this->plugin->isInPlot($event->getBlock()->getFloorX(), $event->getBlock()->getFloorZ())) {
            if ($this->plugin->inOwnPlot($event->getPlayer(), $event->getBlock()->getFloorX(), $event->getBlock()->getFloorZ())) {
                return true;
            } elseif ($event->getPlayer()->hasPermission("f.override")) {
                return true;
            } else {
                $event->setCancelled();
                $claimedBy = $this->plugin->factionFromPoint($event->getBlock()->getX(), $event->getBlock()->getZ());
                $motd = $this->plugin->getMotd($claimedBy);
                $event->getPlayer()->sendPopup("§7Teren gildii:§c " . $claimedBy . " §7- §6" . $motd . "§r");
                return true;
            }
        }
    }

    public function Farmers(BlockPlaceEvent $event)
    {
        $block = $event->getBlock();
        $player = $event->getPlayer();
        $x = $block->getX();
        $y = $block->getY();
        $z = $block->getZ();
        if ($block->getId() == Block::IRON_ORE) {
            if ($this->plugin->isInPlot($x, $z)) {
                if ($this->plugin->inOwnPlot($player, $x, $z)) {
                    if ($this->plugin->hasTNTCooldown($this->plugin->getPlayerFaction($player->getName())) == false) {
                        $item = $event->getItem();
                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item);
                        $event->setCancelled();
                        $player->sendMessage($this->plugin->formatMessage("Postawiles boyfarmer!", true));
                        $player->getLevel()->setBlock(new Vector3($x, $y, $z), Block::get(Block::OBSIDIAN, 0));
                        for ($i = 0; $i < 256; $i++) {
                            if (!($player->getLevel()->getBlock(new Vector3($x, $y - $i, $z))->getId() == Block::BEDROCK)) {
                                $player->getLevel()->setBlock(new Vector3($x, $y - $i, $z), Block::get(Block::OBSIDIAN, 0));
                            }
                        }
                    } else {
                        $event->setCancelled();
                    }
                } else {
                    $event->setCancelled();
                    $player->sendMessage($this->plugin->formatMessage("Boyfarmer mozesz stawiac tylko na swoim ternie gildii!", false));
                }
            } else {
                $event->setCancelled();
                $player->sendMessage($this->plugin->formatMessage("Boyfarmer mozesz stawiac tylko na swoim ternie gildii!", false));

            }
        }
        /* if ($block->getId() == Block::GOLD_ORE) {
             if ($this->plugin->isInPlot($x, $z)) {
                 if ($this->plugin->inOwnPlot($player, $x, $z)) {
                     if ($this->plugin->hasTNTCooldown($this->plugin->getPlayerFaction($player->getName())) == false) {
                         $item = $event->getItem();
                         $item->setCount($item->getCount() - 1);
                         $player->getInventory()->setItemInHand($item);
                         $event->setCancelled();
                         $player->sendMessage($this->plugin->formatMessage("Postawiles sandfarmer!", true));
                         $player->getLevel()->setBlock(new Vector3($x, $y, $z), Block::get(Block::SAND, 0));
                         for ($i = 0; $i < 256; $i++) {
                             if (!($player->getLevel()->getBlock(new Vector3($x, $y - $i, $z))->getId() == Block::BEDROCK)) {
                                 $player->getLevel()->setBlock(new Vector3($x, $y - $i, $z), Block::get(Block::SANDSTONE, 0));
                             }
                         }
                         for ($i = 0; $i < 256; $i++) {
                             if ($player->getLevel()->getBlock(new Vector3($x, $y - $i, $z))->getId() == Block::SANDSTONE) {
                                 $player->getLevel()->setBlock(new Vector3($x, $y - $i, $z), Block::get(Block::SAND, 0));
                             }
                         }
                     } else {
                         $event->setCancelled();
                     }
                 } else {
                     $event->setCancelled();
                     $player->sendMessage($this->plugin->formatMessage("Sandfarmer mozesz stawiac tylko na swoim ternie gildii!", false));

                 }
             } else {
                 $event->setCancelled();
                 $player->sendMessage($this->plugin->formatMessage("Sandfarmer mozesz stawiac tylko na swoim ternie gildii!", false));

             }
         } */
        if ($block->getId() == Block::DIAMOND_ORE) {
            if ($this->plugin->isInPlot($x, $z)) {
                if ($this->plugin->inOwnPlot($player, $x, $z)) {
                    if ($this->plugin->hasTNTCooldown($this->plugin->getPlayerFaction($player->getName())) == false) {
                        $item = $event->getItem();
                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item);
                        $event->setCancelled();
                        $player->sendMessage($this->plugin->formatMessage("Postawiles kopaczfos!", true));
                        $player->getLevel()->setBlock(new Vector3($x, $y, $z), Block::get(Block::AIR, 0));
                        for ($i = 0; $i < 256; $i++) {
                            if (!($player->getLevel()->getBlock(new Vector3($x, $y - $i, $z))->getId() == Block::BEDROCK)) {
                                $player->getLevel()->setBlock(new Vector3($x, $y - $i, $z), Block::get(Block::AIR, 0));
                            }
                        }
                    } else {
                        $event->setCancelled();
                    }
                } else {
                    $event->setCancelled();
                    $player->sendMessage($this->plugin->formatMessage("Kopaczfos mozesz stawiac tylko na swoim ternie gildii!", false));

                }
            } else {
                $event->setCancelled();
                $player->sendMessage($this->plugin->formatMessage("Kopaczfos mozesz stawiac tylko na swoim ternie gildii!", false));

            }
        }
    }

    public function factionTNTCooldown(BlockPlaceEvent $event)
    {
        if ($this->plugin->isInPlot($event->getBlock()->getX(), $event->getBlock()->getZ())) {
            if ($this->plugin->inOwnPlot($event->getPlayer(), $event->getBlock()->getX(), $event->getBlock()->getZ())) {
                if ($this->plugin->hasTNTCooldown($this->plugin->getPlayerFaction($event->getPlayer()->getName())) == true) {
                    $event->setCancelled();
                    $time = ($this->plugin->getConfig()->get("TNTExplosionCooldown") - (time() - $this->plugin->getTNTCooldownTime($this->plugin->getPlayerFaction($event->getPlayer()->getName()))));
                    $event->getPlayer()->sendMessage($this->plugin->formatMessage("Na terenie twojej gildii wybuchlo TNT! Budowac bedziesz mogl za " . $time . "s", false));
                }
            }
        }
    }

    public function factionPlayerInteractProtect(PlayerInteractEvent $event)
    {
        if ($event->getItem()->getId() == 325 && ($event->getItem()->getDamage() == 8 || $event->getItem()->getDamage() == 0 || $event->getItem()->getDamage() == 10)) {
            $x = $event->getBlock()->getFloorX();
            $z = $event->getBlock()->getFloorZ();
            if ($this->plugin->isInPlot($x, $z)) {
                if ($this->plugin->inOwnPlot($event->getPlayer(), $x, $z)) {
                } elseif ($event->getPlayer()->hasPermission("f.override")) {
                    return true;
                } else {
                    $event->setCancelled(true);
                    $claimedBy = $this->plugin->factionFromPoint($event->getBlock()->getX(), $event->getBlock()->getZ());
                    $motd = $this->plugin->getMotd($claimedBy);
                    $event->getPlayer()->sendPopup("§7Teren gildii:§c " . $claimedBy . " §7- §c" . $motd . "§r");
                }
            }
        }
    }

    public function factionPlayerDeathEvent(PlayerDeathEvent $event)
    {
        if ($this->plugin->isInFaction($event->getEntity()->getName()) == true) {
            $faction = $this->plugin->getPlayerFaction($event->getEntity()->getName());
            if ($this->plugin->getFactionPoints($faction) >= 25) {
                $this->plugin->db->query("UPDATE top SET points = points + '-25' WHERE faction='$faction';");
            }
        }
        if ($event->getEntity()->getLastDamageCause() instanceof EntityDamageByEntityEvent) {
            $killer = $event->getEntity()->getLastDamageCause()->getDamager();
            if ($event->getEntity() instanceof Player && $killer instanceof Player) {
                if (!isset($this->address_ip[$killer->getName()])) {
                    $this->address_ip[$killer->getName()] = 0;
                }
                if ($this->address_ip[$killer->getName()] != $event->getEntity()->getAddress()) {
                    if ($this->plugin->isInFaction($killer->getName()) == true) {
                        $faction = $this->plugin->getPlayerFaction($killer->getName());
                        $this->plugin->db->query("UPDATE top SET points = points + '25' WHERE faction='$faction';");
                        $this->address_ip[$killer->getName()] = $event->getEntity()->getAddress();
                    }
                }
            }
        }
    }

    public function nightProtection(ExplosionPrimeEvent $e)
    {
        $time = explode("-", $this->plugin->getConfig()->get("NightExplosionProtection"));
        if ((date("H") >= $time[0]) && (date("H") <= $time[1])) {
            $e->setCancelled();
        }
    }

    public function onExplode(EntityExplodeEvent $event)
    {
        $x = $event->getPosition()->getX();
        $y = $event->getPosition()->getY();
        $z = $event->getPosition()->getZ();
        $faction = $this->plugin->factionFromPoint($x, $z);
        if ($y >= 256) {
            if ($this->plugin->isInPlot($x, $z)) {
                $event->setCancelled(true);
                if ($this->plugin->hasTNTCooldown($faction) == false) {
                    $this->plugin->startTNTCooldown($faction);
                    $this->plugin->sendMessageToFaction("Na twoim terenie wybuchlo TNT! Przez nastepne " . $this->plugin->getConfig()->get("TNTExplosionCooldown") . " s. nie mozesz budowac!", $faction, true);
                }
            }
        }
        if (!$event->isCancelled()) {
            $minX = (int)floor($x - 3);
            $maxX = (int)ceil($x + 3);
            $minY = (int)floor($y - 3);
            $maxY = (int)ceil($y + 3);
            $minZ = (int)floor($z - 3);
            $maxZ = (int)ceil($z + 3);
            $pos1 = new Vector3($minX, $minY, $minZ);
            $pos2 = new Vector3($maxX, $maxY, $maxZ);
            $wasInFluid = false;
            if ($event->getPosition()->getLevel()->getBlock($event->getPosition()->asVector3())->getId() == 8 or
                $event->getPosition()->getLevel()->getBlock($event->getPosition()->asVector3())->getId() == 9 or
                $event->getPosition()->getLevel()->getBlock($event->getPosition()->asVector3())->getId() == 10 or
                $event->getPosition()->getLevel()->getBlock($event->getPosition()->asVector3())->getId() == 11) {
                $wasInFluid = true;
            }
            for ($x = min($pos1->getX(), $pos2->getX()); $x <= max($pos1->getX(), $pos2->getX()); $x++) {
                for ($y = min($pos1->getY(), $pos2->getY()); $y <= max($pos1->getY(), $pos2->getY()); $y++) {
                    for ($z = min($pos1->getZ(), $pos2->getZ()); $z <= max($pos1->getZ(), $pos2->getZ()); $z++) {
                        if ($event->getPosition()->getLevel()->getBlock(new Vector3($x, $y, $z))->getId() == 8 or
                            $event->getPosition()->getLevel()->getBlock(new Vector3($x, $y, $z))->getId() == 9 or
                            $event->getPosition()->getLevel()->getBlock(new Vector3($x, $y, $z))->getId() == 10 or
                            $event->getPosition()->getLevel()->getBlock(new Vector3($x, $y, $z))->getId() == 11) {
                            $event->getPosition()->getLevel()->setBlock(new Vector3($x, $y, $z), Block::get(Block::AIR, 0));
                        }
                    }
                }
            }
            if ($wasInFluid == true) {
                $explosion = new Explosion($event->getPosition(), 4, $this);
                $explosion->explodeA();
                $explosion->explodeB();
            }
        }
    }

    public function trueBlockRegionHome(PlayerCommandPreprocessEvent $event)
    {

        $command = explode(" ", strtolower($event->getMessage()));
        $player = $event->getPlayer();
        $x = floor($player->getX());
        $z = floor($player->getZ());
        if ($command[0] === "/sethome") {
            if ($this->plugin->isInPlot($x, $z)) {
                $event->setCancelled();
                $player->sendMessage($this->plugin->formatMessage("Nie mozesz ustawic domu na terenie gildii!", false));
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $x = floor($block->getX());
        $y = floor($block->getY());
        $z = floor($block->getZ());
        $world = $player->getLevel()->getName();
        $center = $this->plugin->db->query("SELECT * FROM center WHERE x='$x' AND y='$y' AND z='$z' AND world='$world';");
        $array = $center->fetchArray(SQLITE3_ASSOC);
        if (!empty($array)) {
            if ($this->plugin->isInFaction($player->getName())) {
                $factionPlayer = $this->plugin->getPlayerFaction($player->getName());
                $factionWar = $array["faction"];
                if ($factionWar != $factionPlayer) {
                    if (!$this->plugin->areAllies($factionPlayer, $factionWar)) {
                        if ($x == $array["x"] && $y == $array["y"] && $z == $array["z"] && $world == $array["world"]) {
                            if ($this->plugin->getConfig()->get("WarEnabled") == false) {
                                $player->sendMessage($this->plugin->formatMessage("Wojny gildii sa wylaczone!", false));
                            }
                            $currentTime = time();
                            $timeWarProtection = $this->plugin->getFactionTimeWarProtection($factionWar);
                            $timeWarProtectionDefault = $this->plugin->getConfig()->get("WarProtection");
                            $differentTimeWarProtection = ($currentTime - $timeWarProtection);
                            if ($differentTimeWarProtection > $timeWarProtectionDefault) {
                                $timeWarWait = $this->plugin->getFactionTimeWarWait($factionWar);
                                $timeWarWaitDefault = $this->plugin->getConfig()->get("WarWait");
                                $differentTimeWarWait = ($currentTime - $timeWarWait);
                                if ($differentTimeWarWait > $timeWarWaitDefault) {
                                    if ($this->plugin->getFactionWarLives($factionWar) > 1) {
                                        if ($this->plugin->getFactionHealth($factionWar) > 1) {
                                            $this->plugin->removeHealth($factionWar, 1);
                                            $this->plugin->sendPopupToFaction("§c§lTwoja gildia jest atakowana!", $factionWar, false);
                                        } else {
                                            if ($this->plugin->getFactionWarLives($factionPlayer) < 3) {
                                                $this->plugin->db->query("UPDATE center SET lives = lives + '1' WHERE faction='$factionPlayer';");
                                            }
                                            $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gildia " . strtoupper($factionPlayer) . " odebrala 1 serce gildii " . strtoupper($factionWar) . ".", true));
                                            $player->sendMessage($this->plugin->formatMessage("Kolejne serce gildii " . strtoupper($factionWar) . " bedziesz mogl odebrac za " . floor(($timeWarWaitDefault / 86400)) . " dni, " . floor(($timeWarWaitDefault % 86400) / 3600) . " godzin, " . floor((($timeWarWaitDefault % 86400) % 3600) / 60) . " minut i " . floor((($timeWarWaitDefault % 86400) % 3600) % 60) . " sekund.", false));
                                            $this->plugin->db->query("UPDATE center SET lives = lives - '1' WHERE faction='$factionWar';");
                                            $this->plugin->db->query("UPDATE center SET timeWarWait = '$currentTime' WHERE faction='$factionWar';");
                                            $this->plugin->setHealth($factionWar, 0);
                                        }
                                    } else {
                                        if ($this->plugin->getFactionHealth($factionWar) < 1) {
                                            $this->plugin->removeWars($factionWar);
                                            $this->plugin->removeParticles($factionWar);
                                            $warWinPoints = $this->plugin->getConfig()->get("WarWinPoints");
                                            $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gildia " . $factionWar . " zostala podbita przez gildie " . $factionPlayer . ".", true));
                                            $this->plugin->db->query("DELETE FROM plots WHERE faction='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM master WHERE faction='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM top WHERE faction='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM expires WHERE faction='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM home WHERE faction='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM allies WHERE faction1='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM allies WHERE faction2='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM pvp WHERE faction='$factionWar';");
                                            $this->plugin->db->query("DELETE FROM plotsize WHERE faction='$factionWar';");
                                            $player->sendMessage($this->plugin->formatMessage("Twoja gildia otrzymuje +$warWinPoints punktow za wygrana wojne!", true));
                                            $this->plugin->addPoints($factionPlayer, $warWinPoints);
                                            $this->plugin->getServer()->getLevelByName($world)->setBlock(new Vector3($array["x"], $array["y"], $array["z"]), Block::get(0));
                                            $this->plugin->db->query("DELETE FROM center WHERE faction='$factionWar';");
                                            $this->plugin->db->query("UPDATE top SET wins = wins + '1' WHERE faction='$factionPlayer';");
                                        } else {
                                            $this->plugin->removeHealth($factionWar, 1);
                                            $this->plugin->sendPopupToFaction("§c§lTwoja gildia jest atakowana!", $factionWar, false);
                                        }
                                    }
                                } else {
                                    $player->sendMessage($this->plugin->formatMessage("Gildia " . strtoupper($factionWar) . " stracila ostatnio serce!", false));
                                    $player->sendMessage($this->plugin->formatMessage("Zaatakowac bedziesz mogl dopiero za " . floor(($timeWarWaitDefault - $differentTimeWarWait) / 86400) . " dni, " . floor((($timeWarWaitDefault - $differentTimeWarWait) % 86400) / 3600) . " godzin, " . floor(((($timeWarWaitDefault - $differentTimeWarWait) % 86400) % 3600) / 60) . " minut i " . floor(((($timeWarWaitDefault - $differentTimeWarWait) % 86400) % 3600) % 60) . " sekund.", false));
                                }
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Gildia " . strtoupper($factionWar) . " ma aktywna ochrone przed podbojem!", false));
                                $player->sendMessage($this->plugin->formatMessage("Zaatakowac bedziesz mogl dopiero za " . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . " dni, " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . " godzin, " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . " minut i " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) % 60) . " sekund.", false));
                            }
                        }
                    } else {
                        $player->sendMessage($this->plugin->formatMessage("Nie mozesz atakowac sojuszniczych gildii!", false));
                    }
                }
            }
        }
    }

    public function onMove(PlayerMoveEvent $event)
    {
        $player = $event->getPlayer();
        if (floor($event->getTo()->getX()) != floor($event->getFrom()->getX()) || floor($event->getTo()->getZ()) != floor($event->getFrom()->getZ()) || floor($event->getTo()->getY()) != floor($event->getFrom()->getY())) {
            if ($this->plugin->getHomeStatus($player->getName()) == 0) {
                $this->plugin->setHomeStatus($player->getName(), 1);
                $player->addTitle("§l§cTeleportacja nieudana!", "§r");
                if ($player->hasEffect(Effect::BLINDNESS)) {
                    $player->removeEffect(Effect::BLINDNESS);
                }
            }
        }
        if ($this->plugin->isInPlot($player->getX(), $player->getZ())) {
            $faction = $this->plugin->factionFromPoint($player->getX(), $player->getZ());
            if ($this->plugin->inOwnPlot($player, $player->getX(), $player->getZ())) {
                if (!isset($this->plugin->bossbarid[$player->getName()])) {
                    $bossbar = new Bossbar("§l§7Terytorium: §a" . $faction, 100, 100);
                    $this->plugin->bossbarid[$player->getName()] = $bossbar->getEntityId();
                    $bossbar->showTo($player);
                }
                if ($player->getGamemode() == 2) {
                    $player->setGamemode(0);
                }
            } else {
                if ($this->plugin->areAllies($this->plugin->getPlayerFaction($player->getName()), $faction)) {
                    if (!isset($this->plugin->bossbarid[$player->getName()])) {
                        $bossbar = new Bossbar("§l§7Terytorium: §3" . $faction, 100, 100);
                        $this->plugin->bossbarid[$player->getName()] = $bossbar->getEntityId();
                        $bossbar->showTo($player);
                    }
                } else {
                    if (!isset($this->plugin->bossbarid[$player->getName()])) {
                        $bossbar = new Bossbar("§l§7Terytorium: §c" . $faction, 100, 100);
                        $this->plugin->bossbarid[$player->getName()] = $bossbar->getEntityId();
                        $bossbar->showTo($player);
                    }
                    if ($player->getGamemode() == 0) {
                        $player->setGamemode(2);
                    }
                }
            }
        } else {
            if (isset($this->plugin->bossbarid[$player->getName()])) {
                $pk = new BossEventPacket();
                $pk->bossEid = $this->plugin->bossbarid[$player->getName()];
                $pk->eventType = BossEventPacket::TYPE_HIDE;
                $player->sendDataPacket($pk);
                unset($this->plugin->bossbarid[$player->getName()]);
            }
            if ($player->getGamemode() == 2) {
                $player->setGamemode(0);
            }
        }
    }

    public function onBreakPermissions(BlockBreakEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        if ($this->plugin->isInPlot($block->getX(), $block->getZ())) {
            if ($this->plugin->inOwnPlot($player, $block->getX(), $block->getZ())) {
                if ($this->plugin->getPermission($player->getName(), "break") != 1 && !$player->hasPermission("f.override")) {
                    $event->setCancelled();
                    $player->sendPopup("§7Nie posiadasz wymagajacych permisji gildyjnych, aby niszczyc bloki!");
                }
            }
        }
    }

    public function onPlacePermissions(BlockPlaceEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        if ($this->plugin->isInPlot($block->getX(), $block->getZ())) {
            if ($this->plugin->inOwnPlot($player, $block->getX(), $block->getZ())) {
                if ($this->plugin->getPermission($player->getName(), "build") != 1 && !$player->hasPermission("f.override")) {
                    $event->setCancelled();
                    $player->sendPopup("§7Nie posiadasz wymagajacych permisji gildyjnych, aby stawiac bloki!");
                }
            }
        }
    }

    public function onInteractPermissions(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        if ($event->getAction() == PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            if ($this->plugin->isInPlot($block->getX(), $block->getZ())) {
                if ($this->plugin->inOwnPlot($player, $block->getX(), $block->getZ())) {
                    if ($block->getId() == Block::CHEST) {
                        if ($this->plugin->getPermission($player->getName(), "chestopen") != 1 && !$player->hasPermission("f.override")) {
                            $event->setCancelled();
                            $player->sendPopup("§7Nie posiadasz wymagajacych permisji gildyjnych, aby otwierac skrzynie!");
                        }
                    }
                    if ($block->getId() == Block::FURNACE) {
                        if ($this->plugin->getPermission($player->getName(), "furnaceopen") != 1 && !$player->hasPermission("f.override")) {
                            $event->setCancelled();
                            $player->sendPopup("§7Nie posiadasz wymagajacych permisji gildyjnych, aby otwierac piecyki!");
                        }
                    }
                }
            }
        }
    }

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        $this->plugin->setHomeStatus($player->getName(), 1);
        $this->plugin->setTerenStatus($player->getName(), false);
        if ($this->plugin->existsInScoreboard($player)) {
            $this->plugin->addToScoreboard($player);
        }
        if ($this->plugin->getScoreboardStatus($player) == 0) {
            $task = new ScoreboardTask($this->plugin, $player);
            $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20 * 30, 20 * 30);
        }
    }

    public function onQuit(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer();
        $array = $this->plugin->db->query("SELECT * FROM health;");
        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
            $faction = $row["faction"];
            if (isset($this->plugin->item[$faction][$player->getName()])) {
                unset($this->plugin->item[$faction][$player->getName()]);
            }
        }
    }

    public function onTeleport(EntityTeleportEvent $event)
    {
        $player = $event->getEntity();
        if ($player instanceof Player) {
            if (isset($this->plugin->bossbarid[$player->getName()])) {
                $pk = new BossEventPacket();
                $pk->bossEid = $this->plugin->bossbarid[$player->getName()];
                $pk->eventType = BossEventPacket::TYPE_HIDE;
                $player->sendDataPacket($pk);
                unset($this->plugin->bossbarid[$player->getName()]);
            }
        }
    }

    public function onBlockUpdate(BlockUpdateEvent $event)
    {
        $block = $event->getBlock();
        $position = $block->asPosition();
        if ($block->getId() == 8 or $block->getId() == 9 or $block->getId() == 10 or $block->getId() == 11) {
            if ($position->getY() >= 50) {
                $event->setCancelled();
            }
        }
    }
}