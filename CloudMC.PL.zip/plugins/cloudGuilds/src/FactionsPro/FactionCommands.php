<?php

namespace FactionsPro;

use FactionsPro\GUIListeners\PanelListener;
use FactionsPro\Tasks\HomeTask;
use FactionsPro\Tasks\ScoreboardTask;
use pocketmine\block\Block;
use pocketmine\block\Emerald;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\item\Item;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class FactionCommands
{

    public $plugin;

    public function __construct(FactionMain $pg)
    {
        $this->plugin = $pg;
    }

    public function onCommand(CommandSender $player, Command $cmd, $label, array $args): bool
    {
        $name = $player->getName();
        if ($player instanceof Player) {
            if ($cmd->getName() == "f") {
                if (empty($args)) {
                    $player->sendMessage($this->plugin->formatMessage("Uzyj /g pomoc aby wyswietlic liste komend!", false));
                    return true;
                }
                /* CREATING */
                if (count($args) == 1 or count($args) == 2) {
                    if ($args[0] == "create" or $args[0] == "zaloz") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g zaloz <tag> <nazwa>", false));
                        return true;
                    }
                }
                if (count($args) == 3) {
                    if ($args[0] == "create" or $args[0] == "zaloz") {
                        $x = floor($player->getX());
                        $y = floor($player->getY());
                        $z = floor($player->getZ());
                        $level = $player->getLevel();
                        $faction = $args[1];
                        $factionName = $args[2];
                        if (!$player->getInventory()->contains(Item::get(57, 0, 64)) or !$player->getInventory()->contains(Item::get(41, 0, 64)) or !$player->getInventory()->contains(Item::get(42, 0, 64)) or !$player->getInventory()->contains(Item::get(133, 0, 64)) or !$player->getInventory()->contains(Item::get(173, 0, 64))) {
                            $player->sendMessage($this->plugin->formatMessage("Aby zalozyc gildie potrzebujesz: 64 blokow: diamentowych, szmaragdowych, zlotych, zelaznych oraz weglowych! Aby sprawdzic czy posiadasz wszystkie itemy wpisz: /g itemy.", false));
                            return true;
                        }
                        if (!(ctype_alnum($args[1]))) {
                            $player->sendMessage($this->plugin->formatMessage("TAG gildii moze sie skladac jedynie z liczb oraz liter!", false));
                            return true;
                        }
                        if (!(ctype_alnum($args[2]))) {
                            $player->sendMessage($this->plugin->formatMessage("NAZWA gildii moze sie skladac jedynie z liczb oraz liter!", false));
                            return true;
                        }
                        if ($this->plugin->factionExists($args[1]) == true) {
                            $player->sendMessage($this->plugin->formatMessage("Gildia o tym tagu juz istnieje.", false));
                            return true;
                        }
                        if (strlen($args[1]) > $this->plugin->getConfig()->get("MaxFactionTagLength")) {
                            $player->sendMessage($this->plugin->formatMessage("Ten tag jest zbyt dlugi! Maksymalna ilosc liter w tagu to 4", false));
                            return true;
                        }
                        if (strlen($args[2]) > $this->plugin->getConfig()->get("MaxFactionNameLength")) {
                            $player->sendMessage($this->plugin->formatMessage("Ta nazwa gidlii jest zbyt dluga maksymalna ilosc liter w nazwie to 24.", false));
                            return true;
                        }
                        if ($this->plugin->isInFaction($name)) {
                            $player->sendMessage($this->plugin->formatMessage("Aby zalozyc gildie musisz najpierw opuscic aktualna!", false));
                            return true;
                        }
                        foreach ($this->plugin->getConfig()->get("BlackListWorlds") as $world) {
                            if (strtolower($player->getLevel()->getName()) == $world) {
                                $player->sendMessage($this->plugin->formatMessage("Nie mozesz zalozyc w tym swiecie gildii!", false));
                                return true;
                            }
                        }
                        if ($player->getX() >= 700 or $player->getX() <= -700 or $player->getZ() >= 700 or $player->getZ() <= -700) {
                            $player->sendMessage($this->plugin->formatMessage("Jestes zbyt daleko, gildie mozesz zalozyc maksymalnie 700 kratek od spawna.", false));
                            return true;
                        }
                        if ($player->getPosition()->distance($player->getLevel()->getSafeSpawn()) < $this->plugin->getConfig()->get("RegionMinDistanceFromSpawn")) {
                            $player->sendMessage($this->plugin->formatMessage("Jestes zbyt blisko spawnu! Minimalna odleglosc to " . $this->plugin->getConfig()->get("RegionMinDistanceFromSpawn") . " kratek.", false));
                            return true;
                        }

                        if (!$this->plugin->nearPlot($player)) {
                            $player->sendMessage($this->plugin->formatMessage("Jestes zbyt blisko innej gildii!", false));
                            return true;
                        }

                        if ($player->getY() > 20) {
                            $player->sendMessage($this->plugin->formatMessage("Jestes zbyt wysoko! Gildie mozesz zalozyc do Y: 20.", false));
                            return true;
                        }

                        if ($player->getY() < 10) {
                            $player->sendMessage($this->plugin->formatMessage("Jestes zbyt nisko! Gildie mozesz zalozyc powyzej Y: 10.", false));
                            return true;
                        }

                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gildia " . $faction . " - " . $factionName . " zostala zalozona przez " . $name . "!", true));

                        $this->plugin->setPlotSize($faction, $this->plugin->getConfig()->get("FirstPlotSize"));
                        $arm = $this->plugin->getConfig()->get("FirstPlotSize");
                        $this->plugin->drawPlot($faction, $x, $z, $arm);

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                        $stmt->bindValue(":player", $player->getName());
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":rank", "Leader");
                        $stmt->bindValue(":chat", 1);
                        $stmt->bindValue(":chat_type", "small");
                        $stmt->bindValue(":chat_color", "&6");
                        $result = $stmt->execute();

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO center (faction, lives, timeWarProtection, timeWarWait, x, y, z, world) VALUES (:faction, :lives, :timeWarProtection, :timeWarWait, :x, :y, :z, :world);");
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":lives", $this->plugin->getConfig()->get("WarLives"));
                        $stmt->bindValue(":timeWarProtection", time());
                        $stmt->bindValue(":timeWarWait", 0);
                        $stmt->bindValue(":x", $x);
                        $stmt->bindValue(":y", $y - 1);
                        $stmt->bindValue(":z", $z);
                        $stmt->bindValue(":world", $player->getLevel()->getName());
                        $result = $stmt->execute();

                        $this->plugin->setPoints($faction, 500);

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO expires (faction, time) VALUES (:faction, :time);");
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":time", $this->plugin->getConfig()->get("Expires"));
                        $result = $stmt->execute();

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO home (faction, x, y, z, world) VALUES (:faction, :x, :y, :z, :world);");
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":x", $player->getX());
                        $stmt->bindValue(":y", $player->getY());
                        $stmt->bindValue(":z", $player->getZ());
                        $stmt->bindValue(":world", $player->getLevel()->getName());
                        $result = $stmt->execute();

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO createdate (faction, time) VALUES (:faction, :time);");
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":time", time());
                        $result = $stmt->execute();

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO health (faction, health) VALUES (:faction, :health);");
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":health", 1000);
                        $result = $stmt->execute();

                        $this->plugin->updateAllies($faction);
                        $this->plugin->setPVP($faction, 0);
                        $this->plugin->setMOTD($faction, $name, $factionName);
                        $this->plugin->addToPermissions($name, $faction);
                        $this->plugin->setAllPermissions($name, 1);
                        $this->plugin->getCloudCore()->setNametag($player);

                        $player->getInventory()->removeItem(Item::get(57, 0, 64));
                        $player->getInventory()->removeItem(Item::get(41, 0, 64));
                        $player->getInventory()->removeItem(Item::get(133, 0, 64));
                        $player->getInventory()->removeItem(Item::get(42, 0, 64));
                        $player->getInventory()->removeItem(Item::get(173, 0, 64));
                        //Pustka
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY(), $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY(), $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY(), $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY(), $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 2, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 2, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 2, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 2, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ()), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 5, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 5, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 5, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 5, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY(), $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 2, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 5, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY(), $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 5, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY(), $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 2, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 5, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 5, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY(), $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 2, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 4, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 5, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY(), $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 4, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 5, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 4, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 5, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 3, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 4, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 5, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY(), $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 2, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 5, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY(), $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 5, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY(), $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 2, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 4, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 5, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY(), $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 4, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 5, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 3, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 4, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 5, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY(), $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 2, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 5, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY(), $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 5, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 4, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 5, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 3, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 4, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 5, $player->getFloorZ() + 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY(), $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 2, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 5, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 4, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 5, $player->getFloorZ() - 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 3, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 4, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 5, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 5, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY(), $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 2, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 5, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 5, $player->getFloorZ() + 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 4, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 5, $player->getFloorZ() + 2), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 5, $player->getFloorZ() - 1), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY(), $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 5, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY(), $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 4, $player->getFloorZ() - 3), Block::get(0, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 5, $player->getFloorZ() - 3), Block::get(0, 0));

                        //Podstawa
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() - 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() - 2), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() - 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() + 2), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() - 1, $player->getFloorZ() + 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() - 1, $player->getFloorZ() - 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() - 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() - 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() - 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 3, $player->getFloorY(), $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 2, $player->getFloorZ() + 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 1, $player->getFloorZ() + 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY(), $player->getFloorZ() + 3), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 2, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY() + 1, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 3, $player->getFloorY(), $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 5, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 4, $player->getFloorZ() - 1), Block::get(49, 0));
                        $createMaterial = explode(":", $this->plugin->getConfig()->get("CreateMaterial"));
                        $level->setBlock(new Vector3($x, $y - 1, $z), Block::get($createMaterial[0], $createMaterial[1]));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 2, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() + 2), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 2, $player->getFloorY() + 3, $player->getFloorZ()), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 3, $player->getFloorZ() - 2), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() - 1, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() + 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX() + 1, $player->getFloorY() + 3, $player->getFloorZ() - 1), Block::get(49, 0));
                        $player->getLevel()->setBlock(new Vector3($player->getFloorX(), $player->getFloorY() + 4, $player->getFloorZ()), Block::get(49, 0));
                        $this->plugin->updateParticles();
                        $level = $this->plugin->getServer()->getDefaultLevel();
                        $level->broadcastLevelSoundEvent($player->getPosition()->asVector3(), LevelSoundEventPacket::SOUND_BLAST);
                        $level->broadcastLevelSoundEvent($player->getPosition()->asVector3(), LevelSoundEventPacket::SOUND_BLAST);
                        $level->broadcastLevelSoundEvent($player->getPosition()->asVector3(), LevelSoundEventPacket::SOUND_BLAST);
                        return true;
                    }
                }

                /* DISBANDIND */
                if (count($args) == 1) {
                    if ($args[0] == "disband" or $args[0] == "usun") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g usun <tag>", false));
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "disband" or $args[0] == "usun") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby tego uzyc!", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem aby usunac gildie!", false));
                            return true;
                        }
                        if ($args[1] != $this->plugin->getPlayerFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Uzycie: /g usun <tag> ", false));
                            return true;
                        }
                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gildia " . $this->plugin->getPlayerFaction($player->getName()) . " zostala rozwiazana przez " . $player->getName() . "", true));
                        $factionDeleteClaim = $this->plugin->getPlayerFaction($player->getName());
                        $this->plugin->removeParticles($factionDeleteClaim);
                        $array = $this->plugin->db->query("SELECT * FROM master WHERE faction='$factionDeleteClaim';");
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            $name = $row["player"];
                            $this->plugin->removeFromPermissions($name);
                        }
                        $this->plugin->db->query("DELETE FROM plots WHERE faction='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM master WHERE faction='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM top WHERE faction='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM expires WHERE faction='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM home WHERE faction='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM allies WHERE faction1='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM allies WHERE faction2='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM pvp WHERE faction='$factionDeleteClaim';");
                        $this->plugin->db->query("DELETE FROM plotsize WHERE faction='$factionDeleteClaim';");
                        $result = $this->plugin->db->query("SELECT * FROM center WHERE faction='$factionDeleteClaim';");
                        $array = $result->fetchArray(SQLITE3_ASSOC);
                        $x = $array["x"];
                        $y = $array["y"];
                        $z = $array["z"];
                        $world = $array["world"];
                        $this->plugin->getServer()->getLevelByName($world)->setBlock(new Vector3($x, $y, $z), Block::get(0));
                        $this->plugin->db->query("DELETE FROM center WHERE faction='$factionDeleteClaim';");
                        $this->plugin->getCloudCore()->setNametag($player);
                        return true;
                    }
                }
                /* ZAPRASZANIE */
                if (count($args) == 1) {
                    if ($args[0] == "zapros" or $args[0] == "invite") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g zapros <nick>", false));
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "zapros" or $args[0] == "invite") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii, aby uzyc tej opcji!", false));
                            return true;
                        }
                        if ($this->plugin->isMember($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem lub oficerem aby zapraszac graczy!", false));
                            return true;
                        }
                        if ($this->plugin->isFactionFull($this->plugin->getPlayerFaction($player->getName()))) {
                            $player->sendMessage($this->plugin->formatMessage("Gildia jest pelna, nie ma miejsc na nowych czlonkow.", false));
                            return true;

                        }
                        if ($this->plugin->isInFaction($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Ten gracz posiada juz gildie!", false));
                            return true;
                        }
                        if (!$this->plugin->getServer()->getPlayer($args[1]) instanceof Player && $args[1] != "all") {
                            $player->sendMessage($this->plugin->formatMessage("Nie znaleziono takiego gracza na serwerze!", false));
                            return true;
                        }
                        if ($args[1] != "all") {
                            $faction = $this->plugin->getPlayerFaction($player->getName());
                            $invited = $this->plugin->getServer()->getPlayer($args[1])->getName();
                            $rank = "Member";

                            $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO confirm (player, faction, invitedby, timestamp) VALUES (:player, :faction, :invitedby, :timestamp);");
                            $stmt->bindValue(":player", $invited);
                            $stmt->bindValue(":faction", $faction);
                            $stmt->bindValue(":invitedby", $player->getName());
                            $stmt->bindValue(":timestamp", time());
                            $result = $stmt->execute();

                            $this->plugin->sendMessageToFaction("Gracz $invited zostal zaproszony do gildii przez " . $player->getName() . "", $faction, true);
                            #$player->sendMessage($this->plugin->formatMessage("Gracz $invited zostal zaproszony do gildii pomyslnie!", true));
                            $this->plugin->getServer()->getPlayer($args[1])->sendMessage($this->plugin->formatMessage("Zostales zaproszony do $faction. Aby dolaczyc uzyj '/g dolacz <tag>' lub '/g odrzuc <tag>', aby odrzucic zaproszenie!", true));
                            return true;
                        }
                        if ($args[1] == "all") {
                            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                                if ($player->distance($p) <= 7 && !$this->plugin->isInFaction($p->getName())) {
                                    $faction = $this->plugin->getPlayerFaction($player->getName());
                                    $invited = $p->getName();
                                    $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO confirm (player, faction, invitedby, timestamp) VALUES (:player, :faction, :invitedby, :timestamp);");
                                    $stmt->bindValue(":player", $invited);
                                    $stmt->bindValue(":faction", $faction);
                                    $stmt->bindValue(":invitedby", $player->getName());
                                    $stmt->bindValue(":timestamp", time());
                                    $result = $stmt->execute();
                                    $p->sendMessage($this->plugin->formatMessage("Zostales zaproszony do $faction. Aby dolaczyc uzyj '/g dolacz <tag>' lub '/g odrzuc <tag>', aby odrzucic zaproszenie!", true));
                                    return true;
                                }
                            }
                            $faction = $this->plugin->getPlayerFaction($player->getName());
                            $this->plugin->sendMessageToFaction("Gracz " . $player->getName() . " zaprosil do gildii wszystkich graczy w poblizu siebie!", $faction, true);
                            #$player->sendMessage($this->plugin->formatMessage("Wszyscy gracze w odleglosci 5 kratek zostali zaproszeni do gildii pomyslnie!", true));
                            return true;
                        }
                    }
                }
                /* DAWANIE LEADERA */
                if (count($args) == 1) {
                    if ($args[0] == "lider" or $args[0] == "leader") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g lider <nick>", false));
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "lider" or $args[0] == "leader") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii, aby uzyc tej opcji!", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem, aby uzyc tej opcji!", false));
                            return true;
                        }
                        if ($this->plugin->getPlayerFaction($player->getName()) != $this->plugin->getPlayerFaction($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Tego gracza nie ma w gildii!", false));
                            return true;
                        }
                        if ($this->plugin->isLeader($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Nie mozesz oddac lidera samemu sobie!", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                        $stmt->bindValue(":player", $player->getName());
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":rank", "Member");
                        $stmt->bindValue(":chat", 1);
                        $stmt->bindValue(":chat_type", "small");
                        $stmt->bindValue(":chat_color", "&6");
                        $result = $stmt->execute();

                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                        $stmt->bindValue(":player", $args[1]);
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":rank", "Leader");
                        $stmt->bindValue(":chat", 1);
                        $stmt->bindValue(":chat_type", "small");
                        $stmt->bindValue(":chat_color", "&6");
                        $result = $stmt->execute();

                        $this->plugin->setAllPermissions($args[1], 1);
                        $this->plugin->setAllPermissions($player->getName(), 0);

                        $player->sendMessage($this->plugin->formatMessage("Oddales lidera graczowi " . $args[1] . "", true));
                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gracz " . $args[1] . " zostal nowym liderm gildii " . $faction . "!", true));
                        return true;
                    }
                }
                /* DAWANIE AWANSU */
                if (count($args) == 1) {
                    if ($args[0] == "awansuj" or $args[0] == "promote" or $args[0] == "oficer") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g awansuj <nick>", false));
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "awansuj" or $args[0] == "promote" or $args[0] == "oficer") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii, aby uzyc tej opcji!", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem aby kogos awansowac!", false));
                            return true;
                        }
                        if ($this->plugin->getPlayerFaction($player->getName()) != $this->plugin->getPlayerFaction($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Ten gracz nie nalezy do twojej gildii!", false));
                            return true;
                        }
                        if ($this->plugin->isOfficer($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Ten gracz jest juz oficerem!", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                        $stmt->bindValue(":player", $args[1]);
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":rank", "Officer");
                        $stmt->bindValue(":chat", 1);
                        $stmt->bindValue(":chat_type", "small");
                        $stmt->bindValue(":chat_color", "&6");
                        $result = $stmt->execute();

                        $player->sendMessage($this->plugin->formatMessage("" . "Gracz " . $args[1] . " zostal awansowany na oficera!", true));
                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gracz " . $args[1] . " zostal awansowany na stopien oficera w gildii " . $faction . "!", true));
                        if ($this->plugin->getServer()->getPlayer($args[1])) {
                            $this->plugin->getServer()->getPlayer($args[1])->sendMessage($this->plugin->formatMessage("Zostales awansowany na stopien oficera.", true));
                            return true;
                        }
                    }
                }
                /* DAWANIE DEGRADA */
                if (count($args) == 1) {
                    if ($args[0] == "zdegraduj" or $args[0] == "odbierz" or $args[0] == "demote") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g odbierz <nick>", false));
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "zdegraduj" or $args[0] == "odbierz" or $args[0] == "demote") {
                        if ($this->plugin->isInFaction($player->getName()) == false) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii, aby uzyc tej opcji!", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem aby kogos zdegradowac!", false));
                            return true;
                        }
                        if ($this->plugin->getPlayerFaction($player->getName()) != $this->plugin->getPlayerFaction($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Ten gracz nie nalezy do twojej gildii!", false));
                            return true;
                        }
                        if (!$this->plugin->isOfficer($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Nie mozesz zdegradowac osoby, ktora jest juz czlonkiem!", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
                        $stmt->bindValue(":player", $args[1]);
                        $stmt->bindValue(":faction", $faction);
                        $stmt->bindValue(":rank", "Member");
                        $result = $stmt->execute();

                        $player->sendMessage($this->plugin->formatMessage("Gracz " . $args[1] . " zostal zniesiony na stopien czlonka!", true));
                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gracz " . $args[1] . " zostal zdegradowany do roli czlonka w gildii " . $faction . "!", true));
                        if ($this->plugin->getServer()->getPlayer($args[1])) {
                            $this->plugin->getServer()->getPlayer($args[1])->sendMessage($this->plugin->formatMessage("Zostales zdegradowany na stopien czlonka.", true));
                            return true;
                        }
                    }
                }
                /* WYRZUCANIE Z GILDII */
                if (count($args) == 1) {
                    if ($args[0] == "kick" or $args[0] == "wyrzuc") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g wyrzuc <nick>", false));
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "kick" or $args[0] == "wyrzuc") {
                        if ($this->plugin->isInFaction($player->getName()) == false) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii, aby uzyc tej opcji!", false));
                            return true;
                        }
                        if ($this->plugin->isMember($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem lub oficerem aby wyrzucac graczy!", false));
                            return true;
                        }
                        if ($this->plugin->isOfficer($player->getName()) && $this->plugin->isOfficer($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Mozesz wyrzucac tylko graczy z nizsza ranga od siebie!", false));
                            return true;
                        }
                        if ($this->plugin->getPlayerFaction($player->getName()) != $this->plugin->getPlayerFaction($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Ten gracz nie nalezy do twojej gildii!", false));
                            return true;
                        }
                        if ($this->plugin->isLeader($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Nie mozesz wyrzucic lidera gildii!", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gracz " . $args[1] . " zostal wyrzucony z gildii " . $faction . "!", true));
                        $player->sendMessage($this->plugin->formatMessage("Wyrzuciles gracza " . $args[1] . " z gildii pomyslnie!", true));
                        $this->plugin->db->query("DELETE FROM master WHERE player='$args[1]';");
                        #$players[] = $this->plugin->getServer()->getOnlinePlayers();
                        return true;
                    }
                }
                if (count($args) == 1) {
                    if ($args[0] == "accept" or $args[0] == "akceptuj" or $args[0] == "dolacz") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g dolacz <tag>", false));
                        return true;
                    }
                }
                /* AKCEPTOWANIE */
                if (count($args) == 2) {
                    if ($args[0] == "accept" or $args[0] == "akceptuj" or $args[0] == "dolacz") {
                        $gracz = $player->getName();
                        $lowercaseName = $gracz;
                        $result = $this->plugin->db->query("SELECT * FROM confirm WHERE player='$lowercaseName';");
                        $array = $result->fetchArray(SQLITE3_ASSOC);
                        if (empty($array) == true) {
                            $player->sendMessage($this->plugin->formatMessage("Nie zostales zaproszony do zadnej gildii!", false));
                            return true;
                        }
                        if ($args[1] != $array["faction"]) {
                            $player->sendMessage($this->plugin->formatMessage("Nie zostales zaproszony od tej gildii!", false));
                            return true;
                        }
                        $invitedTime = $array["timestamp"];
                        $currentTime = time();
                        if (($currentTime - $invitedTime) <= 60) {
                            if ($player->getInventory()->contains(Item::get(264, 0, 5))) {
                                $player->getInventory()->removeItem(Item::get(264, 0, 5));
                                $faction = $array["faction"];
                                $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                                $stmt->bindValue(":player", $gracz);
                                $stmt->bindValue(":faction", $faction);
                                $stmt->bindValue(":rank", "Member");
                                $stmt->bindValue(":chat", 1);
                                $stmt->bindValue(":chat_type", "small");
                                $stmt->bindValue(":chat_color", "&6");
                                $result = $stmt->execute();
                                $this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
                                if ($this->plugin->getServer()->getPlayer($array["invitedby"])) {
                                    if ($this->plugin->getServer()->getPlayer($array["invitedby"])) {
                                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " dolaczyl do gildii " . $faction . "!", true));
                                        $this->plugin->addToPermissions($player->getName(), $faction);
                                        $this->plugin->setAllPermissions($player->getName(), 1);
                                        $this->plugin->getCloudCore()->setNametag($player);
                                        return true;
                                    }
                                }
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Aby dolaczyc do gildii musisz miec 5 diamentów!!", false));
                                return true;
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Zaproszenie do tej gildii jest juz przedawnione!", false));
                            $this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
                            return true;
                        }
                    }
                }
                if (count($args) == 1) {
                    if ($args[0] == "deny" or $args[0] == "odrzuc") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g odrzuc <tag>", false));
                        return true;
                    }
                }
                /* ODRZUCANIE */
                if (count($args) == 2) {
                    if ($args[0] == "deny" or $args[0] == "odrzuc") {
                        $gracz = $player->getName();
                        $lowercaseName = $gracz;
                        $result = $this->plugin->db->query("SELECT * FROM confirm WHERE player='$lowercaseName';");
                        $array = $result->fetchArray(SQLITE3_ASSOC);
                        if (empty($array) == true) {
                            $player->sendMessage($this->plugin->formatMessage("Nie zostales zaproszony do zadnej gildii!", false));
                            return true;
                        }
                        if ($args[1] != $array["faction"]) {
                            $player->sendMessage($this->plugin->formatMessage("Nie zostales zaproszony od tej gildii!", false));
                            return true;
                        }
                        $invitedTime = $array["timestamp"];
                        $currentTime = time();
                        if (($currentTime - $invitedTime) <= 60) {
                            $player->sendMessage($this->plugin->formatMessage("Odrzuciles zaproszenie do gildii " . $array["faction"] . "", true));
                            $this->plugin->getServer()->getPlayerExact($array["invitedby"])->sendMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " odrzucil zaproszenie do twojej gildii!", false));
                            $this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
                            return true;
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Zaproszenie do tej gildii jest juz przedawnione!", false));
                            $this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
                            return true;
                        }
                    }
                }
                /* OPUSZCZANIE GILDII */
                if (count($args) == 1) {
                    if ($args[0] == "opusc" or $args[0] == "leave") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g opusc <tag>", false));
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "opusc" or $args[0] == "leave") {
                        if ($this->plugin->isLeader($player->getName()) == false) {
                            $remove = $player->getPlayer()->getNameTag();
                            $faction = $this->plugin->getPlayerFaction($player->getName());
                            $name = $player->getName();
                            if ($this->plugin->isInFaction($player->getName())) {
                                if ($args[1] == $this->plugin->getPlayerFaction($player->getName())) {
                                    $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gracz " . $player->getName() . " opuscil gildie " . $faction . "!", true));
                                    $this->plugin->db->query("DELETE FROM master WHERE player='$name';");
                                    $this->plugin->removeFromPermissions($name);
                                    $this->plugin->getCloudCore()->setNametag($player);
                                    return true;
                                }
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby to wykonac!", false));
                                return true;
                            }
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Jestes liderem, nie mozesz opuscic gildii!", false));
                            return true;
                        }
                    }
                }
                /* USTAWIANIE DOMU */
                if (count($args) == 1) {
                    if ($args[0] == "sethome" or $args[0] == "ustawdom") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby to wykonac!", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem aby to wykonac", false));
                            return true;
                        }
                        if (!$this->plugin->inOwnPlot($player, $player->getX(), $player->getZ())) {
                            $player->sendMessage($this->plugin->formatMessage("Nie mozesz ustawic domu gildii poza swoim terenem!", false));
                            return true;
                        }
                        $factionName = $this->plugin->getPlayerFaction($player->getName());
                        $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO home (faction, x, y, z, world) VALUES (:faction, :x, :y, :z, :world);");
                        $stmt->bindValue(":faction", $factionName);
                        $stmt->bindValue(":x", $player->getX());
                        $stmt->bindValue(":y", $player->getY());
                        $stmt->bindValue(":z", $player->getZ());
                        $stmt->bindValue(":world", $player->getLevel()->getName());
                        $result = $stmt->execute();
                        $player->sendMessage($this->plugin->formatMessage("Dom gildii zostal ustawiony!", true));
                        return true;
                    }
                }
                /* TELEPORTACJA DO DOMU */
                if (count($args) == 1) {
                    if ($args[0] == "home" or $args[0] == "dom") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby to wykonac!", false));
                            return true;
                        }
                        $antylogout = $this->plugin->api("SystemAntyLogouta");
                        $fight = $antylogout->isInFight($player->getName());
                        if ($fight) {
                            $player->sendMessage($this->plugin->formatMessage("Nie mozesz isc na dom gildii podczas walki!", false));
                            return false;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $result = $this->plugin->db->query("SELECT * FROM home WHERE faction = '$faction';");
                        $array = $result->fetchArray(SQLITE3_ASSOC);
                        if (!empty($array)) {
                            $world = $this->plugin->getServer()->getLevelByName($array['world']);
                            #$player->getPlayer()->teleport(new Position($array['x'], $array['y'], $array['z'], $world));
                            $task = new HomeTask($this->plugin, $player, new Position($array['x'], $array['y'], $array['z']), 10);
                            $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
                            $this->plugin->home[$player->getName()] = 0;
                            $player->addTitle("§l§7Teleportacja nastapi za §b10 §7sekund", "§7Nie ruszaj sie!");
                            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::NAUSEA), 20 * 10, 0));
                            return true;
                        } else {
                            $player->sendMessage($this->plugin->formatMessage("Dom gildii nie jest ustawiony.", false));
                            return true;
                        }
                    }
                }
                /* RANKING GILDII */
                if (count($args) == 1) {
                    if ($args[0] == "top" or $args[0] == "topka") {
                        $this->plugin->getFactionTop();
                        $player->sendMessage(str_replace('&', '§', "&8[ &7---------- &8[&b&lRanking Gildii&r&8] &7---------- &8]"));
                        for ($i = 1; $i < 11; $i++) {
                            if (!empty($this->plugin->getTop[$i])) {
                                $player->sendMessage(str_replace('&', '§', "&l&b$i.&r " . $this->plugin->getTop[$i]));
                            } else {
                                $player->sendMessage(str_replace('&', '§', "&l&b$i.&r &7BRAK"));
                            }
                        }
                        $player->sendMessage(str_replace('&', '§', "&8[ &7---------- &8[&b&lRanking Gildii&r&8] &7---------- &8]"));
                        unset($this->plugin->getTop);
                        return true;
                    }
                }
                /* ZARZADZANIE PVP */
                if (count($args) == 1) {
                    if ($args[0] == "pwp" or $args[0] == "pvp") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby to wykonac!", false));
                            return true;
                        }
                        if ($this->plugin->isMember($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz miec range wyzsza niz Czlonek!", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $this->plugin->updatePVP($player, $faction);
                        return true;
                    }
                }
                /* PRZEDLUZENIE GILDII */
                if (count($args) == 1) {
                    if ($args[0] == "oplac" or $args[0] == "przedluz") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Nie posiadasz gildii!", false));
                            return true;
                        }
                        if (!$player->getInventory()->contains(Item::get(Item::DIAMOND, 0, 128 or !$player->getInventory()->contains(Item::get(Item::EMERALD, 0, 128))))) {
                            $player->sendMessage($this->plugin->formatMessage("Aby przedluzyc gildie potrzebujesz: 2x 64 Diamenty, 2x 64 Szmaragdy", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $time = $this->plugin->getConfig()->get("Expires");
                        $this->plugin->db->query("UPDATE expires SET time = '$time' WHERE faction='$faction';");
                        $player->sendMessage($this->plugin->formatMessage("Waznosc zostala przedluzona!", true));
                        $player->getInventory()->removeItem(Item::get(Item::DIAMOND, 0, 128));
                        $player->getInventory()->removeItem(Item::get(Item::EMERALD, 0, 128));
                        return true;
                    }
                }
                /* POWIEKSZANIE */
                if (count($args) == 1) {
                    if ($args[0] == "powieksz" or $args[0] == "upgrade") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby to wykonac!", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem aby powiekszyc teren!", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $this->plugin->updatePlotSize($player, $faction);
                    }
                }
                if (count($args) == 1) {
                    if ($args[0] == "sojusz" or $args[0] == "allies") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g sojusz <tag>", false));
                        return true;
                    }
                }
                /* SOJUSZE */
                if (count($args) == 2) {
                    if ($args[0] == "sojusz" or $args[0] == "allies") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii aby to wykonac", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem aby to wykonac", false));
                            return true;
                        }
                        if (!$this->plugin->factionExists($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Taka gildia nie istnieje", false));
                            return true;
                        }
                        if ($this->plugin->getPlayerFaction($player->getName()) == $args[1]) {
                            $player->sendMessage($this->plugin->formatMessage("Nie mozesz wyslac prosby o sojusz do swojej gildii!", false));
                            return true;
                        }
                        if ($this->plugin->areAllies($this->plugin->getPlayerFaction($player->getName()), $args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Twoja gildia posiada juz sojusz z ta gildia!", false));
                            return true;
                        }
                        $fac = $this->plugin->getPlayerFaction($player->getName());
                        $leader = $this->plugin->getServer()->getPlayerExact($this->plugin->getLeader($args[1]));
                        $this->plugin->updateAllies($fac);
                        $this->plugin->updateAllies($args[1]);
                        if (!($leader instanceof Player)) {
                            $player->sendMessage($this->plugin->formatMessage("Lider wybranej gildii jest offline!", false));
                            return true;
                        }
                        if ($this->plugin->getAlliesCount($args[1]) >= $this->plugin->getAlliesLimit()) {
                            $player->sendMessage($this->plugin->formatMessage("Ta gildia osiagnela limit sojuszy!", false));
                            return true;
                        }
                        if ($this->plugin->getAlliesCount($fac) >= $this->plugin->getAlliesLimit()) {
                            $player->sendMessage($this->plugin->formatMessage("Twoja gidlia osiągneła limit sojuszy!", false));
                            return true;
                        }
                        $result = $this->plugin->db->query("SELECT * FROM alliance WHERE faction='$fac';");
                        $array = $result->fetchArray(SQLITE3_ASSOC);
                        if (empty($array)) {
                            $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO alliance (player, faction, requestedby, timestamp) VALUES (:player, :faction, :requestedby, :timestamp);");
                            $stmt->bindValue(":player", $leader->getName());
                            $stmt->bindValue(":faction", $args[1]);
                            $stmt->bindValue(":requestedby", $player->getName());
                            $stmt->bindValue(":timestamp", time());
                            $result = $stmt->execute();
                            $player->sendMessage($this->plugin->formatMessage("Wyslano prosbe o sojusz do gildii " . $args[1] . "!", true));
                            $leader->sendMessage($this->plugin->formatMessage("Lider gildii " . $fac . " wysyla prosbe o sojusz. Wpisz /g sojusz <tag> aby zaakceptowac prosbe o sojusz!", true));
                            return true;
                        } else {
                            $allyTime = $array["timestamp"];
                            $currentTime = time();
                            if (($currentTime - $allyTime) <= 60) { //This should be configurable
                                $requested_fac = $this->plugin->getPlayerFaction($array["requestedby"]);
                                $player_fac = $this->plugin->getPlayerFaction($player->getName());
                                $this->plugin->setAllies($requested_fac, $player_fac);
                                $this->plugin->setAllies($player_fac, $requested_fac);
                                $lowercaseName = $this->plugin->getLeader($requested_fac);
                                $this->plugin->db->query("DELETE FROM alliance WHERE player='$lowercaseName';");
                                $this->plugin->updateAllies($requested_fac);
                                $this->plugin->updateAllies($player_fac);
                                $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gildia " . $player_fac . " zawarla sojusz z " . $requested_fac . "!", true));
                                return true;
                            } else {
                                $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO alliance (player, faction, requestedby, timestamp) VALUES (:player, :faction, :requestedby, :timestamp);");
                                $stmt->bindValue(":player", $leader->getName());
                                $stmt->bindValue(":faction", $args[1]);
                                $stmt->bindValue(":requestedby", $player->getName());
                                $stmt->bindValue(":timestamp", time());
                                $result = $stmt->execute();
                                $player->sendMessage($this->plugin->formatMessage("Wyslano prosbe o sojusz do gildii " . $args[1] . "!", true));
                                $leader->sendMessage($this->plugin->formatMessage("Lider gildii " . $fac . " wysyla prosbe o sojusz. Wpisz /g sojusz <tag> aby zaakceptowac prosbe o sojusz!", true));
                                return true;
                            }
                        }
                    }
                }
                if (count($args) == 1) {
                    if ($args[0] == "sojuszzerwij" or $args[0] == "zerwijsojusz") {
                        $player->sendMessage($this->plugin->formatMessage("Uzycie: /g zerwijsojusz <tag>", false));
                        return true;
                    }
                }
                /* ZERWANIE SOJUSZY */
                if (count($args) == 2) {
                    if ($args[0] == "sojuszzerwij" or $args[0] == "zerwijsojusz") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii aby to wykonac", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem gildii, aby to wykonac", false));
                            return true;
                        }
                        if (!$this->plugin->factionExists($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Gildia o takim tagu nie istenieje!", false));
                            return true;
                        }
                        if ($this->plugin->getPlayerFaction($player->getName()) == $args[1]) {
                            $player->sendMessage($this->plugin->formatMessage("Nie mozesz zerwac sojuszu sam ze soba!", false));
                            return true;
                        }
                        if (!$this->plugin->areAllies($this->plugin->getPlayerFaction($player->getName()), $args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Twoja gildia nie posiadala sojuszu z gildia " . $args[1] . "!", false));
                            return true;
                        }
                        $fac = $this->plugin->getPlayerFaction($player->getName());
                        $leader = $this->plugin->getServer()->getPlayerExact($this->plugin->getLeader($args[1]));
                        $this->plugin->deleteAllies($fac, $args[1]);
                        $this->plugin->deleteAllies($args[1], $fac);
                        $this->plugin->updateAllies($fac);
                        $this->plugin->updateAllies($args[1]);
                        $player->sendMessage($this->plugin->formatMessage("Zerwales sojusz z gildia $args[1]", true));
                        $this->plugin->getServer()->broadcastMessage($this->plugin->formatMessage("Gildia " . $fac . " zerwala sojusz z gildia " . $args[1] . "!", true));
                        if ($leader instanceof Player) {
                            $leader->sendMessage($this->plugin->formatMessage("Lider gildii $fac zerwal sojusz z twoja gildia!", false));
                            return true;
                        }
                    }
                }
                if (count($args) == 1) {
                    if ($args[0] == "panel") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc w gildii aby to wykonac", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem gildii, aby to wykonac", false));
                            return true;
                        }
                        $gui = new PanelListener($this->plugin, "§8§l» §bPanel Gildyjny");
                        $gui->addContents($player);
                        $gui->sendTo($player);
                    }
                }
                /* SPRAWDZANIE TERENU */
                if ($args[0] == "sprawdz" or $args[0] == "check") {
                    $x = floor($player->getX());
                    $y = floor($player->getY());
                    $z = floor($player->getZ());
                    $fac = $this->plugin->factionFromPoint($x, $z);
                    if (!$this->plugin->isInPlot($x, $z)) {
                        $player->sendMessage($this->plugin->formatMessage("Ten teren jest wolny! Mozesz zalozyc tutaj gildie!", true));
                        return true;
                    }
                    $player->sendMessage($this->plugin->formatMessage("Ten teren jest zajety przez gildie: " . $fac . "!", false));
                    return true;
                }
                /* LISTA KOMEND */
                if (count($args) == 1) {
                    if ($args[0] == "help" or $args[0] == "pomoc") {
                        $player->sendMessage("§8[ §7-------------- §8[§l§bGILDIE 1/2§r§8] §7-------------- §8]");
                        $player->sendMessage("§l§b *§r§7 /g zaloz [tag] [pelna nazwa] - §bzaklada gildie");
                        $player->sendMessage("§l§b *§r§7 /g usun [tag] - §busuwa gildie");
                        $player->sendMessage("§l§b *§r§7 /g zapros [nick] - §bzaprasza do gildii");
                        $player->sendMessage("§l§b *§r§7 /g wyrzuc [nick] - §bwyrzuca gracza z gildii");
                        $player->sendMessage("§l§b *§r§7 /g dolacz [tag] - §bdolacza do gildii");
                        $player->sendMessage("§l§b *§r§7 /g odrzuc [tag] - §bodrzuca zaproszenie do gildii");
                        $player->sendMessage("§l§b *§r§7 /g opusc [tag] - §bopuszcza gildie");
                        $player->sendMessage("§l§b *§r§7 /g info [tag] - §binformacje o gildii");
                        $player->sendMessage("§l§b *§r§7 /g lider [nick] - §bustawia nowego leadera gildii gildii");
                        $player->sendMessage("§l§b *§r§7 /g awansuj [nick] - §bawansuje czlonka do stopnia oficera");
                        $player->sendMessage("§l§b *§r§7 /g odbierz [nick] - §bodbiera oficera");
                        $player->sendMessage("§l§b *§r§7 /g sojusz [tag] - §bwysyla prosba o sojusz/akceptuje prosbe o sojusz");
                        $player->sendMessage("§l§b *§r§7 /g zerwijsojusz [tag] - §bzrywa sojusz z gildia");
                        $player->sendMessage("§8[ §7-------------- §8[§l§bGILDIE 1/2§r§8] §7-------------- §8]");
                        return true;
                    }
                }
                if (count($args) == 2) {
                    if ($args[1] == 2) {
                        $player->sendMessage("§8[ §7-------------- §8[§l§bGILDIE 2/2§r§8] §7-------------- §8]");
                        $player->sendMessage("§l§b *§r§7 /g sprawdz - §bsprawdza czy teren jest zajety");
                        $player->sendMessage("§l§b *§r§7 /g ustawdom - §bustawia dom gildii");
                        $player->sendMessage("§l§b *§r§7 /g przedluz - §bprzedluza waznosc gildii");
                        $player->sendMessage("§l§b *§r§7 /g powieksz - §bpowieksza teren gildii");
                        $player->sendMessage("§l§b *§r§7 /g pvp - §bwlacza/wylacza pvp w gildii");
                        $player->sendMessage("§l§b *§r§7 /g dom - §bteleportuje do bazy gildii");
                        $player->sendMessage("§l§b *§r§7 /g sprawdz - §bsprawdza czy/przez kogo teren jest zajety");
                        $player->sendMessage("§l§b *§r§7 /g top - §branking gildii");
                        $player->sendMessage("§l§b *§r§7 /g itemy - §bitemy potrzebne do zalozenia gildii");
                        $player->sendMessage("§l§b *§r§7 #[wiadomosc] - §bwysyla wiadomosc do twojej gildii");
                        $player->sendMessage("§l§b *§r§7 ##[wiadomosc] - §bwysyla wiadomosc do sojuszniczych gildii");
                        $player->sendMessage("§l§b *§r§7 ! - §bwysyla prosbe o pomoc do sojuszy, i twojej gildii");
                        $player->sendMessage("§8[ §7-------------- §8[§l§bGILDIE 2/2§r§8] §7-------------- §8]");
                    }
                }
                if (count($args) == 1) {
                    if ($args[0] == "walka") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby to wykonac!", false));
                            return true;
                        }
                        if (!$this->plugin->isLeader($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Musisz byc liderem aby to wykonac!", false));
                            return true;
                        }
                        $faction = $this->plugin->getPlayerFaction($player->getName());
                        $result = $this->plugin->db->query("SELECT * FROM center WHERE faction='$faction';");
                        $array = $result->fetchArray(SQLITE3_ASSOC);
                        $x = $array["x"];
                        $y = $array["y"];
                        $z = $array["z"];
                        if (isset($this->plugin->fightcooldown[$faction])) {
                            if (time() - $this->plugin->fightcooldown[$faction] <= 60) {
                                $time = (60 - (time() - $this->plugin->fightcooldown[$faction]));
                                $player->sendMessage($this->plugin->formatMessage("Mozesz ponownie to wykonac za " . $time . " sekund! ", false));
                                return true;
                            }
                        }
                        $this->plugin->getServer()->broadcastMessage("§8[ §7---------- §8[§b§lWalka§r§8] §7---------- §8]");
                        $this->plugin->getServer()->broadcastMessage("§b§l*§r §7Gildia §b§l" . $faction . " §r§7zaprasza na walke!");
                        $this->plugin->getServer()->broadcastMessage("§b§l*§r §7Pozycja: X:§b§l " . $x . "§r§7, Z: §b§l" . $z);
                        $this->plugin->getServer()->broadcastMessage("§8[ §7---------- §8[§b§lWalka§r§8] §7---------- §8]");
                        $this->plugin->fightcooldown[$faction] = time();
                    }
                }
                /* INFORMACJE O GILDII */
                if (count($args) == 1) {
                    if ($args[0] == "info" or $args[0] == "informacje") {
                        if (!$this->plugin->isInFaction($player->getName())) {
                            $player->sendMessage($this->plugin->formatMessage("Nie posiadasz gildii aby sprawdzic o niej informacje!", false));
                            return true;
                        } else {
                            $faction = $this->plugin->getPlayerFaction($player->getName());
                            $factioname = $this->plugin->getMOTD($faction);
                            $leader = $this->plugin->getLeader($faction);
                            $numPlayers = $this->plugin->getNumberOfPlayers($faction);
                            $plot = $this->plugin->geTPlotSize($faction);
                            $officers = $this->plugin->getOfficer($faction);
                            $levelintop = $this->plugin->getTopLevel($faction);
                            $allies = $this->plugin->getAllAllies($faction);
                            $points = $this->plugin->getFactionPoints($faction);
                            $lives = $this->plugin->getFactionWarLives($faction);
                            $wins = $this->plugin->getFactionWins($faction);
                            $createdate = $this->plugin->getCreateDate($faction);
                            /* HOME COORDS */
                            $result = $this->plugin->db->query("SELECT * FROM home WHERE faction='$faction';");
                            $array = $result->fetchArray(SQLITE3_ASSOC);
                            $x = floor($array["x"]);
                            $z = floor($array["z"]);
                            $home = "X: " . $x . " Z: " . $z;
                            /* HOME COORDS */
                            /* MEMBERS ONLINE */
                            $array = $this->plugin->db->query("SELECT * FROM master WHERE faction='$faction';");
                            $members = array(
                                "players" => "",
                                "online" => 0,
                                "all" => 0,
                            );
                            while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                                if ($this->plugin->getServer()->getPlayer($row["player"]) instanceof Player) {
                                    if (!$this->plugin->isLeader($row["player"])) {
                                        $members["players"] = $members["players"] . TextFormat::GREEN . $row["player"] . TextFormat::GRAY . ", ";
                                    } else {
                                        $members["players"] = $members["players"] . TextFormat::GREEN . "§l" . $row["player"] . "§r" . TextFormat::GRAY . ", ";
                                    }
                                    $members["online"]++;
                                    $members["all"]++;
                                } else {
                                    if (!$this->plugin->isLeader($row["player"])) {
                                        $members["players"] = $members["players"] . TextFormat::GRAY . $row["player"] . TextFormat::GRAY . ", ";
                                    } else {
                                        $members["players"] = $members["players"] . TextFormat::GRAY . "§l" . $row["player"] . "§r" . TextFormat::GRAY . ", ";
                                    }
                                    $members["all"]++;
                                }
                            }
                            $count = strlen($members["players"]);
                            $allplayers = $members["players"] = substr($members["players"], 0, $count - 2);
                            $onlineplayerscount = $members["online"];
                            /* MEMBERS ONLINE */
                            $pvpstatus = $this->plugin->getPVP($faction);
                            if ($pvpstatus == 0) {
                                $pvp = "OFF";
                            } else {
                                $pvp = "ON";
                            }
                            $maxplayers = $this->plugin->getConfig()->get("MaxPlayersPerFaction");
                            /* FACTION PROTECTION */
                            $currentTime = time();
                            $timeWarProtection = $this->plugin->getFactionTimeWarProtection($faction);
                            $timeWarProtectionDefault = $this->plugin->getConfig()->get("WarProtection");
                            $differentTimeWarProtection = ($currentTime - $timeWarProtection);
                            /* FACTION PROTECTION */
                            /* MESSAGES */
                            $player->sendMessage("§8[ §7---------- §8[§b§lInformacje§r§8] §7---------- §8]");
                            $player->sendMessage("§b§l*§r §7Gildia: §8[§b" . $faction . "§8] §b" . $factioname);
                            $player->sendMessage("§b§l*§r §7Data Zalozenia: §b" . date('d/m/Y', $createdate) . " " . date("H", $createdate) . ":" . date("i", $createdate));
                            $player->sendMessage("§b§l*§r §7Lider: §b" . $leader);
                            $player->sendMessage("§b§l*§r §7Punkty: §b" . $points . " §8[§b" . $levelintop . "§8]");
                            $player->sendMessage("§b§l*§r §7Zycia: §b" . $lives);
                            $player->sendMessage("§b§l*§r §7Czlonkowie: §b" . $allplayers . " §8[§b" . $onlineplayerscount . "/" . $this->plugin->getNumberOfPlayers($faction) . "§8]");
                            $player->sendMessage("§b§l*§r §7Sojusze: §b" . $allies);
                            /* if ($levelintop == 3 or $levelintop == 2 or $levelintop == 1) {
                                 if ($this->plugin->getNumberOfPlayers($faction) >= 3) {
                                     $player->sendMessage("§b§l*§r §7Kordynaty: §b" . $home);
                                 }
                             } */
                            if (!$differentTimeWarProtection > $timeWarProtectionDefault) {
                                $player->sendMessage("§b§l*§r §7Ochrona: " . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . " §7dni,§b " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . " §7godzin,§b " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . " §7minut");
                            }
                            $time = $this->plugin->db->query("SELECT * FROM expires WHERE faction='$faction';");
                            $array = $time->fetchArray(SQLITE3_ASSOC);
                            $player->sendMessage("§b§l*§r §7Wygasa za: §b" . floor($array["time"] / 1440) . " §7dni,§b " . floor((($array["time"] / 1440) * 24) % 24) . " §7godzin i §b" . floor(((($array["time"] / 1440) * 24) * 60) % 60) . " §7minut");
                            $player->sendMessage("§8[ §7---------- §8[§b§lInformacje§r§8] §7---------- §8]");
                            return true;
                        }
                    }
                }
                if (count($args) == 2) {
                    if ($args[0] == "info" or $args[0] == "informacje") {
                        if (!$this->plugin->factionExists($args[1])) {
                            $player->sendMessage($this->plugin->formatMessage("Gildia o takim tagu nie istnieje!", false));
                            return true;
                        }
                        $faction = $args[1];
                        $factioname = $this->plugin->getMOTD($faction);
                        $leader = $this->plugin->getLeader($faction);
                        $numPlayers = $this->plugin->getNumberOfPlayers($faction);
                        $plot = $this->plugin->geTPlotSize($faction);
                        $officers = $this->plugin->getOfficer($faction);
                        $levelintop = $this->plugin->getTopLevel($faction);
                        $allies = $this->plugin->getAllAllies($faction);
                        $points = $this->plugin->getFactionPoints($faction);
                        $lives = $this->plugin->getFactionWarLives($faction);
                        $wins = $this->plugin->getFactionWins($faction);
                        $createdate = $this->plugin->getCreateDate($faction);
                        /* HOME COORDS */
                        $result = $this->plugin->db->query("SELECT * FROM home WHERE faction='$faction';");
                        $array = $result->fetchArray(SQLITE3_ASSOC);
                        $x = floor($array["x"]);
                        $z = floor($array["z"]);
                        $home = "X: " . $x . " Z: " . $z;
                        /* HOME COORDS */
                        /* MEMBERS ONLINE */
                        $array = $this->plugin->db->query("SELECT * FROM master WHERE faction='$faction';");
                        $members = array(
                            "players" => "",
                            "online" => 0,
                            "all" => 0,
                        );
                        while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                            if ($this->plugin->getServer()->getPlayer($row["player"]) instanceof Player) {
                                if (!$this->plugin->isLeader($row["player"])) {
                                    $members["players"] = $members["players"] . TextFormat::GREEN . $row["player"] . TextFormat::GRAY . ", ";
                                } else {
                                    $members["players"] = $members["players"] . TextFormat::GREEN . "§l" . $row["player"] . "§r" . TextFormat::GRAY . ", ";
                                }
                                $members["online"]++;
                                $members["all"]++;
                            } else {
                                if (!$this->plugin->isLeader($row["player"])) {
                                    $members["players"] = $members["players"] . TextFormat::GRAY . $row["player"] . TextFormat::GRAY . ", ";
                                } else {
                                    $members["players"] = $members["players"] . TextFormat::GRAY . "§l" . $row["player"] . "§r" . TextFormat::GRAY . ", ";
                                }
                                $members["all"]++;
                            }
                        }
                        $count = strlen($members["players"]);
                        $allplayers = $members["players"] = substr($members["players"], 0, $count - 2);
                        $onlineplayerscount = $members["online"];
                        /* MEMBERS ONLINE */
                        $pvpstatus = $this->plugin->getPVP($faction);
                        if ($pvpstatus == 0) {
                            $pvp = "OFF";
                        } else {
                            $pvp = "ON";
                        }
                        $maxplayers = $this->plugin->getConfig()->get("MaxPlayersPerFaction");
                        /* FACTION PROTECTION */
                        $currentTime = time();
                        $timeWarProtection = $this->plugin->getFactionTimeWarProtection($faction);
                        $timeWarProtectionDefault = $this->plugin->getConfig()->get("WarProtection");
                        $differentTimeWarProtection = ($currentTime - $timeWarProtection);
                        /* FACTION PROTECTION */
                        /* MESSAGES */
                        $player->sendMessage("§8[ §7---------- §8[§b§lInformacje§r§8] §7---------- §8]");
                        $player->sendMessage("§b§l*§r §7Gildia: §8[§b" . $faction . "§8] §b" . $factioname);
                        $player->sendMessage("§b§l*§r §7Data Zalozenia: §b" . date('d/m/Y', $createdate) . " " . date("H", $createdate) . ":" . date("i", $createdate));
                        $player->sendMessage("§b§l*§r §7Lider: §b" . $leader);
                        $player->sendMessage("§b§l*§r §7Punkty: §b" . $points . " §8[§b" . $levelintop . "§8]");
                        $player->sendMessage("§b§l*§r §7Zycia: §b" . $lives);
                        $player->sendMessage("§b§l*§r §7Czlonkowie: §b" . $allplayers . " §8[§b" . $onlineplayerscount . "/" . $this->plugin->getNumberOfPlayers($faction) . "§8]");
                        $player->sendMessage("§b§l*§r §7Sojusze: §b" . $allies);
                        if ($levelintop == 3 or $levelintop == 2 or $levelintop == 1) {
                            if ($this->plugin->getNumberOfPlayers($faction) >= 3) {
                                $player->sendMessage("§b§l*§r §7Kordynaty: §b" . $home);
                            }
                        }
                        if (!$differentTimeWarProtection > $timeWarProtectionDefault) {
                            $player->sendMessage("§b§l*§r §7Ochrona: §b" . floor(($timeWarProtectionDefault - $differentTimeWarProtection) / 86400) . " §7dni,§b " . floor((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) / 3600) . " §7godzin,§b " . floor(((($timeWarProtectionDefault - $differentTimeWarProtection) % 86400) % 3600) / 60) . " §7minut");
                        }
                        $time = $this->plugin->db->query("SELECT * FROM expires WHERE faction='$faction';");
                        $array = $time->fetchArray(SQLITE3_ASSOC);
                        $player->sendMessage("§b§l*§r §7Wygasa za: §b" . floor($array["time"] / 1440) . " §7dni,§b " . floor((($array["time"] / 1440) * 24) % 24) . " §7godzin i §b" . floor(((($array["time"] / 1440) * 24) * 60) % 60) . " §7minut");
                        $player->sendMessage("§8[ §7---------- §8[§b§lInformacje§r§8] §7---------- §8]");
                        return true;
                    }
                }
                if (count($args) == 1) {
                    if ($args[0] == "itemy") {
                        $this->plugin->sendListOfItemsToCreateFaction($player);
                    }
                }
                if ($player->hasPermission("f,override")) {
                    if (count($args) == 1) {
                        if ($args[0] == "ophelp") {
                            $player->sendMessage("§8[ §7---------- §8[§b§lOperator Help§r§8] §7---------- §8]");
                            $player->sendMessage("§b* §7/g opusun <gildia> - wymusza usuniecie gildii");
                            $player->sendMessage("§b* §7/g opdom <gildia> - wymusza teleportacje na dom gildii");
                            $player->sendMessage("§b* §7/g opdolacz <gildia> - wymusza dolaczenie do gildii");
                            $player->sendMessage("§b* §7/g oplider - wymusza oddanie lidera aktualnej gldii");
                            $player->sendMessage("§b* §7/g opoficer - wymusza oddanie oficera aktualnej gldii");
                            $player->sendMessage("§b* §7/g dodajpunkty <gildia> <ilosc> - wymusza dodanie punktow danej gidlii");
                            $player->sendMessage("§b* §7/g usunpunkty <gildia> <ilosc> - wymusza usuniecie punktow danej gidlii");
                            $player->sendMessage("§b* §7/g ban <gildia> - banuje cala gildie");
                            $player->sendMessage("§8[ §7---------- §8[§b§lOperator Help§r§8] §7---------- §8]");
                            return true;
                        }
                        if ($args[0] == "oplider") {
                            if ($this->plugin->isInFaction($player->getName())) {
                                $faction = $this->plugin->getPlayerFaction($player->getName());
                                $leader = $this->plugin->getLeader($faction);
                                $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                                $stmt->bindValue(":player", $leader);
                                $stmt->bindValue(":faction", $faction);
                                $stmt->bindValue(":rank", "Member");
                                $stmt->bindValue(":chat", 1);
                                $stmt->bindValue(":chat_type", "small");
                                $stmt->bindValue(":chat_color", "&6");
                                $result = $stmt->execute();
                                $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                                $stmt->bindValue(":player", $player->getName());
                                $stmt->bindValue(":faction", $faction);
                                $stmt->bindValue(":rank", "Leader");
                                $stmt->bindValue(":chat", 1);
                                $stmt->bindValue(":chat_type", "small");
                                $stmt->bindValue(":chat_color", "&6");
                                $result = $stmt->execute();

                                $this->plugin->setAllPermissions($player->getName(), 1);
                                $this->plugin->setAllPermissions($leader, 0);

                                $player->sendMessage($this->plugin->formatMessage("Odebrales lidera gidlii§b " . $faction . "", true));
                                return true;
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby wymusic lidera!", false));
                                return true;
                            }
                        }
                        if ($args[0] == "opoficer") {
                            if ($this->plugin->isInFaction($player->getName())) {
                                $faction = $this->plugin->getPlayerFaction($player->getName());
                                $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                                $stmt->bindValue(":player", $player->getName());
                                $stmt->bindValue(":faction", $faction);
                                $stmt->bindValue(":rank", "Officer");
                                $stmt->bindValue(":chat", 1);
                                $stmt->bindValue(":chat_type", "small");
                                $stmt->bindValue(":chat_color", "&6");
                                $result = $stmt->execute();
                                $player->sendMessage($this->plugin->formatMessage("Otrzymales oficera w gidlii§b " . $faction . ""));
                                return true;
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Musisz miec gildie aby wymusic lidera!", false));
                                return true;
                            }
                        }
                    }
                    if (count($args) == 2) {
                        if ($args[0] == "opusun") {
                            $faction = $args[1];
                            if ($this->plugin->factionExists($faction)) {
                                $this->plugin->db->query("DELETE FROM plots WHERE faction='$faction';");
                                $this->plugin->db->query("DELETE FROM master WHERE faction='$faction';");
                                $this->plugin->db->query("DELETE FROM top WHERE faction='$faction';");
                                $this->plugin->db->query("DELETE FROM expires WHERE faction='$faction';");
                                $this->plugin->db->query("DELETE FROM home WHERE faction='$faction';");
                                $this->plugin->db->query("DELETE FROM allies WHERE faction1='$faction';");
                                $this->plugin->db->query("DELETE FROM allies WHERE faction2='$faction';");
                                $result = $this->plugin->db->query("SELECT * FROM center WHERE faction='$faction';");
                                $array = $result->fetchArray(SQLITE3_ASSOC);
                                $x = $array["x"];
                                $y = $array["y"];
                                $z = $array["z"];
                                $world = $array["world"];
                                $this->plugin->removeParticles($faction);
                                $this->plugin->getServer()->getLevelByName($world)->setBlock(new Vector3($array["x"], $array["y"], $array["z"]), Block::get(0));
                                $this->plugin->db->query("DELETE FROM center WHERE faction='$faction';");
                                $player->sendMessage($this->plugin->formatMessage("Usunales gildie " . $faction . "", true));
                                return true;
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Niema takiej gildii!", false));
                                return true;
                            }
                        }
                        if ($args[0] == "opdom") {
                            $faction = $args[1];
                            if ($this->plugin->factionExists($faction)) {
                                $result = $this->plugin->db->query("SELECT * FROM home WHERE faction = '$faction';");
                                $array = $result->fetchArray(SQLITE3_ASSOC);
                                if (!empty($array)) {
                                    $world = $this->plugin->getServer()->getLevelByName($array['world']);
                                    $player->getPlayer()->teleport(new Position($array['x'], $array['y'], $array['z'], $world));
                                    $player->sendMessage($this->plugin->formatMessage("Teleportowanie do domu gildii $faction", true));
                                    return true;
                                    return true;
                                } else {
                                    $player->sendMessage($this->plugin->formatMessage("Dom gildii nie jest ustawiony.", false));
                                    return true;
                                }
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Niema takiej gildii!", false));
                                return true;
                            }
                        }
                        if ($args[0] == "opdolacz") {
                            $faction = $args[1];
                            if ($this->plugin->factionExists($faction)) {
                                if (!$this->plugin->isInFaction($player->getName())) {
                                    $stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank, chat, chat_type, chat_color) VALUES (:player, :faction, :rank, :chat, :chat_type, :chat_color);");
                                    $stmt->bindValue(":player", $player->getName());
                                    $stmt->bindValue(":faction", $faction);
                                    $stmt->bindValue(":rank", "Member");
                                    $stmt->bindValue(":chat", 1);
                                    $stmt->bindValue(":chat_type", "small");
                                    $stmt->bindValue(":chat_color", "&6");
                                    $result = $stmt->execute();
                                    $player->sendMessage($this->plugin->formatMessage("Dolaczyles do gildii " . $faction . "", true));
                                    $this->plugin->addToPermissions($player->getName(), $faction);
                                    return true;
                                } else {
                                    $player->sendMessage($this->plugin->formatMessage("Musisz opuscic aktualna gildie!", false));
                                    return true;
                                }
                            }
                            $player->sendMessage($this->plugin->formatMessage("Niema takiej gildii!", false));
                            return true;
                        }
                        if ($args[0] == "ban") {
                            $faction = $args[1];
                            if ($this->plugin->factionExists($faction)) {
                                $array = $this->plugin->db->query("SELECT * FROM master WHERE faction='$faction';");
                                $members = array(
                                    "players" => "",
                                    "online" => 0,
                                    "all" => 0,
                                );
                                while ($row = $array->fetchArray(SQLITE3_ASSOC)) {
                                    $members["players"] = $row["player"];
                                    $members["online"]++;
                                    $members["all"]++;
                                    $this->plugin->getServer()->getNameBans()->addBan($members["players"]);
                                    if ($this->plugin->getServer()->getPlayer($members["players"]) instanceof Player) {
                                        $this->plugin->getServer()->getPlayer($members["players"])->kick("Twoja gildia zostala zbanowana");
                                    }
                                }
                                $player->sendMessage($this->plugin->formatMessage("Cala gildia " . $faction . " zostala zbanowana", true));
                                return true;
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Niema takiej gildii!", false));
                                return true;
                            }
                        }
                    }
                    if (count($args) == 3) {
                        if ($args[0] == "dodajpunkty") {
                            $faction = $args[1];
                            $points = $args[2];
                            if (is_numeric($points)) {
                                if ($this->plugin->factionExists($faction)) {
                                    $this->plugin->db->query("UPDATE top SET points = points + '$points' WHERE faction='$faction';");
                                    $player->sendMessage($this->plugin->formatMessage("Dodales " . $points . " punktow gidlii " . $faction . "", true));
                                    return true;
                                } else {
                                    $player->sendMessage($this->plugin->formatMessage("Niema takiej gildii!", false));
                                    return true;
                                }
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Punkty musza byc podane w liczbie!", false));
                                return true;
                            }
                        }
                        if ($args[0] == "usunpunkty") {
                            $faction = $args[1];
                            $points = $args[2];
                            if (is_numeric($points)) {
                                if ($this->plugin->factionExists($faction)) {
                                    $this->plugin->db->query("UPDATE top SET points = points - '$points' WHERE faction='$faction';");
                                    $player->sendMessage($this->plugin->formatMessage("Usunales " . $points . " punktow gidlii " . $faction . "", true));
                                    return true;
                                } else {
                                    $player->sendMessage($this->plugin->formatMessage("Niema takiej gildii!", false));
                                    return true;
                                }
                            } else {
                                $player->sendMessage($this->plugin->formatMessage("Punkty musza byc podane w liczbie!", false));
                                return true;
                            }
                        }
                    }
                }
            }
            if ($cmd->getName() == "sb") {
                if (empty($args)) {
                    $player->sendMessage($this->plugin->formatMessage("Uzycie: /sb on/off", false));
                } elseif (count($args) == 1) {
                    if ($args[0] == "on") {
                        $this->plugin->changeScoreboard($player, 0);
                        $player->sendMessage($this->plugin->formatMessage("Wlaczyles scoreboard!", true));
                        $task = new ScoreboardTask($this->plugin, $player);
                        $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20 * 30, 20 * 30);
                    } elseif ($args[0] == "off") {
                        $this->plugin->changeScoreboard($player, 1);
                        $player->sendMessage($this->plugin->formatMessage("Wylaczyles scoreboard!", true));
                    } else {
                        $player->sendMessage($this->plugin->formatMessage("Bledne argumenty!", false));
                    }
                }
            }
        } else {
            $player->sendMessage($this->plugin->formatMessage("Ta komende mozesz uzyc tylko w grze!", false));
            return true;
        }
        return true;
    }
}