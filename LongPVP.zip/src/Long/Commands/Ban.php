<?php

namespace Zeno\Commands;

use Zeno\Core;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class Ban extends PluginCommand {

    private $plugin;

    public function __construct(Core $plugin) {
        parent::__construct("ban", $plugin);
        $this->setDescription("Zbanuj gracza");
        $this->setPermission("ban.cmd");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if (!$sender->hasPermission("ban.cmd")) {
            return $sender->sendMessage("§l§a» §r§cBrak permisji !");
        }

        if (!isset($args[0]) or !isset($args[1]) or !isset($args[2]) or !isset($args[3])) {
            return $sender->sendMessage("§l§a» §r§cPoprawne uzycie: /ban (nick) (czas) (ip [yes/no]) (powod) !");
        }

        if (ctype_alnum($args[1]) == false) {
            return $sender->sendMessage("§l§a» §r§cPoprawne uzycie: /ban (nick) (czas) (ip [yes/no]) (powod) !");
        }

        $val = substr($args[1], -1);
        if ($val == "y") {
            $temp = time() + ((int)$args[1] * 31536000);
            $FormatTemp = (int)$args[1] . " lat.";
        } else if ($val == "M") {
            $temp = time() + ((int)$args[1] * 2635200);
            $FormatTemp = (int)$args[1] . " miesięcy.";
        } else if ($val == "w") {
            $temp = time() + ((int)$args[1] * 604800);
            $FormatTemp = (int)$args[1] . " tygodni.";
        } else if ($val == "d") {
            $temp = time() + ((int)$args[1] * 86400);
            $FormatTemp = (int)$args[1] . " dni.";
        } else if ($val == "h") {
            $temp = time() + ((int)$args[1] * 3600);
            $FormatTemp = (int)$args[1] . " godzin.";
        } else if ($val == "m") {
            $temp = time() + ((int)$args[1] * 60);
            $FormatTemp = (int)$args[1] . " minut.";
        } else if ($val == "s") {
            $temp = time() + ((int)$args[1]);
            $FormatTemp = (int)$args[1] . " sekund.";
        } else {
            return $sender->sendMessage("§l§a» §r§cUzycie: /ban (nick) (czas) (ip [yes/no]) (powod) !");
        }

        $raison = [];
        for ($i = 3; $i < count($args); $i++) {
            array_push($raison, $args[$i]);
        }
        $raison = implode(" ", $raison);

        if ($this->plugin->getServer()->getPlayer($args[0]) instanceof Player) {
            $target = $this->plugin->getServer()->getPlayer($args[0]);
            $targetName = $target->getName();
            $this->plugin->getServer()->broadcastMessage("\n§a" . $targetName . "§f Został zbanowany przez §a" . $sender->getName() . "§f za §c" . $raison . " §f!\n\n");
            $target->kick("§cZostsłeś  zbanowany przez " . $sender->getName() . "\n§cZa: §7" . $raison . "\n§6Kup unbana na https://LongPVP.pl", false);
            if ($args[2] == "oui") {
                $ban = "{$sender->getName()}:{$temp}:{$raison}:oui:{$target->getAddress()}";
                $this->plugin->getSanctionAPI()->InsertBan(strtolower($targetName), $ban);
                $this->plugin->getSanctionAPI()->InsertBanIP($target->getAddress(), strtolower($targetName));
            } else {
                $ban = "{$sender->getName()}:{$temp}:{$raison}:non";
                $this->plugin->getSanctionAPI()->InsertBan(strtolower($targetName), $ban);
            }
        } else {
            $targetName = strtolower($args[0]);
            $this->plugin->getServer()->broadcastMessage("\n§a" . $targetName . "§f Został zbanowany przez §a" . $sender->getName() . "§f za §c" . $raison . " §f!\n\n");
            $ban = "{$sender->getName()}:{$temp}:{$raison}:non";
            $this->plugin->getSanctionAPI()->InsertBan($targetName, $ban);
        }

        return true;
    }
}