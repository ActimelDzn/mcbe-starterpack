<?php

namespace Zeno\Tasks;

use Zeno\Core;
use pocketmine\scheduler\Task;

class BroadcastMessageTask extends Task {

    public $plugin;
    private static $message = [
        "§l»» §r§f§g§lNasz discord:https://discord.gg/TT7ajDS8rH"
        "§l§a»» §r§l§zakup range na https://LongPVP.plf!"];
    private static $old = 0;

    public function __construct(Core $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(int $tick){
        $this->plugin->getServer()->broadcastMessage(self::$message[self::$old]);
        self::$old++;
        if(self::$old > count(self::$message)-1)self::$old = 0;
    }

}