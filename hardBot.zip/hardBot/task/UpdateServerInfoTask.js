const fetch = require('node-fetch');

const { domain, port } = require('../data/config.json');

const UpdateServerInfoTask = bot => {
    fetch(`https://api.minetools.eu/query/${domain}/${port}`)
    .then(res => res.json())
    .then(data => {
        const { status, MaxPlayers, Players } = data;

        if(status !== 'OK') {
            bot.user.setActivity('SERWER OFF!', { type: "PLAYING" });
            return;
        }

        bot.user.setActivity(`W GRZE: ${Players}/${MaxPlayers}`, { type: "PLAYING" });
    })
}

module.exports = UpdateServerInfoTask;