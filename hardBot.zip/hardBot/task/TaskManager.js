const UpdateServerInfoTask = require('./UpdateServerInfoTask');

class TaskManager {

    static init(bot) {
        setInterval(() => UpdateServerInfoTask(bot), 3000);
    }
}

module.exports = TaskManager;