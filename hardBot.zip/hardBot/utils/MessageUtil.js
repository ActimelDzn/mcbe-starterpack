class MessageUtil {
    static replyMessageAndDelete(message, msg, seconds = 20) {
        msg.reply(message)
        .then(msg => msg.delete({ timeout: seconds * 200 }))
    }
}

module.exports = MessageUtil;