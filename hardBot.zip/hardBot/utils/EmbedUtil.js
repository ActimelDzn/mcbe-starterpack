const { MessageEmbed } = require("discord.js");
const config  = require('../data/config.json');

const { embedColor } = require('../data/config.json');

class EmbedUtil {

    static createEmbed(title, description) {
        const embed = new MessageEmbed();

        embed.setTitle(title);
        embed.setDescription(description.join('\n'));
        embed.setColor(embedColor);
        embed.setThumbnail(config.image);
        embed.setTimestamp();

        return embed;
    }
}

module.exports = EmbedUtil;