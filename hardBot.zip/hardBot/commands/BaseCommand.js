class BaseCommand {

    static name;
    static permission;

    constructor(name, permission = false) {
        this.name = name;
        this.permission = permission;
    }

    execute(bot, msg, args) {

    }

    getName() {
        return this.name;
    }

    getPermission() {
        return this.permission;
    }
}

module.exports = BaseCommand;