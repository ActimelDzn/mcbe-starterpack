const fetch = require('node-fetch');

const EmbedUtil = require("../../utils/EmbedUtil");
const BaseCommand = require("../BaseCommand");

const { domain, port } = require('../../data/config.json');
const MessageUtil = require('../../utils/MessageUtil');

class StatusCommand extends BaseCommand {
    constructor() {
        super('status');
    }

    execute(bot, msg, args) {
        fetch(`https://api.minetools.eu/query/${domain}/${port}`)
        .then(res => res.json())
        .then(data => {
            const { status, MaxPlayers, Players, Playerlist } = data;

            if(status !== 'OK') {
                const embed = EmbedUtil.createEmbed('STATUS', ['Serwer: OFF']);
                MessageUtil.replyMessageAndDelete(embed, msg);
                return;
            }

            const embed = EmbedUtil.createEmbed('STATUS', [
                'Serwer: ON',
                `Aktualnie gra: ${Players}/${MaxPlayers}`,
            ]);
            MessageUtil.replyMessageAndDelete(embed, msg);
        })
    }
}

module.exports = StatusCommand;