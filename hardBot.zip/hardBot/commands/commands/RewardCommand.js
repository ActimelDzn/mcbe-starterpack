const Rcon = require('modern-rcon');

const BaseCommand = require('../BaseCommand');
const MessageUtil = require('../../utils/MessageUtil');
const RewardModel = require('../../models/RewardModel');

const EmbedUtil = require("../../utils/EmbedUtil");

const config = require('../../data/config.json');

const rcon = new Rcon(config.rcon.host, config.rcon.port, config.rcon.password);

class RewardCommand extends BaseCommand {
    constructor() {
        super('nagroda');
    }

    async execute(bot, msg, args) {
        if(msg.channel.id === config.reward) {
            if(args.length === 0) {
                const embed = EmbedUtil.createEmbed('BLAD', [`Poprawne użycie: ${config.prefix}nagroda (nick)`]);
                MessageUtil.replyMessageAndDelete(embed, msg, 7);
                return;
            }

            const userExists = await RewardModel.userExists(msg.author.id);
            const playerExists = await RewardModel.playerExists(args[0]);

            if(userExists) {
                const embed = EmbedUtil.createEmbed('BLAD', ['Odebrałeś już swoją nagrodę!']);
                MessageUtil.replyMessageAndDelete(embed, msg, 7);
                return;
            }

            if(playerExists) {
                const embed = EmbedUtil.createEmbed('BLAD', ['Ten gracz odebrał już swoją nagrodę!']);
                MessageUtil.replyMessageAndDelete(embed, msg, 7);
                return;
            }

            RewardModel.addUser(msg.author.id, args[0])
            .then(() => {
                rcon.connect().then(() => {
                    const commnads = config.rewardCommands;

                    commnads.forEach(cmd => {
                        cmd = cmd.replace('{nick}', args[0]);
                        rcon.send(cmd);
                    });
                })
                .then(() => rcon.disconnect())
                .catch(() => console.log('Nie udalo sie polaczyc z rconem!'))

                const embed = EmbedUtil.createEmbed('Nagroda odebrana!', ['Twoja nagroda została odebrana pomyslnie!'])
                MessageUtil.replyMessageAndDelete(embed, msg, 60);
            });
        }
        else {
            const channel = bot.channels.cache.get(config.reward);
            const embed = EmbedUtil.createEmbed('Błąd podczas użycia komendy', [`Nagrodę możesz odebrać na kanale ${channel.toString()}!`]);

            MessageUtil.replyMessageAndDelete(embed, msg, 7);
        }
    }
}

module.exports = RewardCommand;