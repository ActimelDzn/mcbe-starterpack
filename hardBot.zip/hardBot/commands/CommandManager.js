const StatusCommand = require("./commands/StatusCommand");
const RewardCommand = require("./commands/RewardCommand");
const IdeaCommand = require("./commands/IdeaCommand");

class CommandManager {

    commands;

    static init() {
        this.commands = [
            new StatusCommand(),
            new RewardCommand(),
            new IdeaCommand(),
        ];
    }

    static getCommand(name) {        
        return this.commands.find(cmd => cmd.getName() === name);
    }
}

module.exports = CommandManager;