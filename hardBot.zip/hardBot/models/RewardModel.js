const fs = require('fs');
const path = require('path');

class RewardModel {

    static fetch() {
        return new Promise((resolve, reject) => {
            fs.readFile(path.join(__dirname, '../', 'data', 'players.json'), (err, data) => {
                const playersData = JSON.parse(data.toString());
                resolve(playersData);
            });
        });
    }

    static playerExists(name) {
        return new Promise(async (resolve, reject) => {
            const players = await this.fetch();
            resolve(players.find(p => p.nickname === name) == null ? false : true);
        });
    }

    static userExists(id) {
        return new Promise(async (resolve, reject) => {
            const players = await this.fetch();
            resolve(players.find(p => p.userID === id) == null ? false : true);
        });
    }
    
    static addUser(id, name) {
        return new Promise(async (resolve, reject) => {
            const data = await this.fetch();
            data.push({ userID: id, nickname: name });

            fs.writeFile(path.join(__dirname, '../', 'data', 'players.json'), JSON.stringify(data), () => resolve())
        });
    }
}

module.exports = RewardModel;