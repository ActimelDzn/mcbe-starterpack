const CommandManager = require('../commands/CommandManager');
const { prefix } = require('../data/config.json');
const EmbedUtil = require('../utils/EmbedUtil');
const MessageUtil = require('../utils/MessageUtil');
const config = require('../data/config.json');

const MessageListener = (msg, bot) => {

    if(msg.content.startsWith(prefix)) {
        const message = msg.content.substring(prefix.length);
        const args = message.split(' ');
        const cmd = args[0];
        args.shift();

        const command = CommandManager.getCommand(cmd);

        if(command) {
            if(command.getPermission()) {
                if(!msg.member.roles.cache.get(config.permission)) {
                    const embed = EmbedUtil.createEmbed('WYSTAPIL BLAD', ['Niestety nie posiadasz permisji aby uzyc tej komendy!']);
                    MessageUtil.replyMessageAndDelete(embed, msg, 20);
                    return;
                }
            }

            command.execute(bot, msg, args);
        }
        else
            msg.channel.send('Niestety ta komenda nie istnieje!')
    }
}

module.exports = MessageListener;