const CommandManager = require('../commands/CommandManager');
const TaskManager = require('../task/TaskManager');

const ReadyListener = bot => {

    CommandManager.init();
    TaskManager.init(bot);

    console.log('HARD4u - BOT WLACZONY!');
}


module.exports = ReadyListener;