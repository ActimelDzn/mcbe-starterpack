const { Client } = require('discord.js');
const { token } = require('./data/config.json');
const MessageListener = require('./listener/MessageListener');

const ReadyListener = require('./listener/ReadyListener');
const RewardModel = require('./models/RewardModel');
const config = require('./data/config.json');

const bot = new Client();
require('discord-buttons')(bot);

bot.on('ready', () => ReadyListener(bot));
bot.on('message', msg => MessageListener(msg, bot));

bot.login(token);