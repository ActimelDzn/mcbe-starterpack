// 
// Decompiled by Procyon v0.5.36
// 

package pl.vertty.arivi.utils;

import pl.vertty.arivi.guilds.data.User;

public class RankingTopUtil
{
}
