// 
// Decompiled by Procyon v0.5.36
// 

package pl.vertty.arivi.drop.base;

public class Prize
{
    private int lvl;
    
    public Prize(final int lvl) {
        this.lvl = lvl;
    }
    
    public int getLvl() {
        return this.lvl;
    }
    
    public void setLvl(final int lvl) {
        this.lvl = lvl;
    }
}
