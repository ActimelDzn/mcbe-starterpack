// 
// Decompiled by Procyon v0.5.36
// 

package pl.vertty.arivi.mysql;

public interface Entry
{
    void insert();
    
    void update(final boolean p0);
    
    void delete();
}
