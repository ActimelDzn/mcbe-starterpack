// 
// Decompiled by Procyon v0.5.36
// 

package pl.vertty.arivi.guilds.listeners;

import cn.nukkit.event.Listener;

public class ShadowBlockListener implements Listener
{
}
