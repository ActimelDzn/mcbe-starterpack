// 
// Decompiled by Procyon v0.5.36
// 

package pl.vertty.arivi.drop.data;

public interface DataExecutor
{
    void save();
    
    void load();
    
    void clear();
    
    void check();
}
