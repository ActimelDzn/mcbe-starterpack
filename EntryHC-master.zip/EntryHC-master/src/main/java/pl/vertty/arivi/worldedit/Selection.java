package pl.vertty.arivi.worldedit;

import cn.nukkit.level.Position;

public class Selection {

    public Position pos1 = null;
    public Position pos2 = null;
}
