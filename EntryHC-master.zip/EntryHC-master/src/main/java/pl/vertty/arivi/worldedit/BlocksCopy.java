package pl.vertty.arivi.worldedit;

import cn.nukkit.block.Block;

import java.util.ArrayList;

public class BlocksCopy {

    public ArrayList<Block> blocks = new ArrayList<>();
}
