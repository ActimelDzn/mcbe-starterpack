# Pluginy z EntryHC i tego BuzzHC

## Lista funkcji
- wszystko i nic

## Plik config.yml

```yml
sam sie genruje wiec no xd
```
## Jeżeli znajdziesz błąd napisz na dc: VerttyPL#7533
