<?php

namespace LightPE_X;

use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\block\Obsidian;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\SimpleCommandMap;
use pocketmine\entity\Creature;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\entity\hostile\Creeper;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\inventory\ShapelessRecipe;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\GoldenApple;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\Task;
use pocketmine\utils\Config;
use SQLite3;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\transaction\DeterministicInvMenuTransaction;

use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\inventory\transaction\InventoryTransaction;
use pocketmine\event\inventory\InventoryTransactionEvent;

class Main extends PluginBase implements Listener
{

  public function onEnable()
  {
    $bot_cfg = new Config($this->getDataFolder() . "bot_wiadomosci.yml", Config::YAML);

    if (!($bot_cfg->exists("wiadomosci"))) {
      $bot_cfg->set("wiadomosci", ["§8[§3WaterPE§8] §7Kanal wlasciciela:§3 RafaTure§r §8*", "§8[§3WaterPE§8]§7 dostepne komendy znajdziesz pod §3/pomoc §8*", "§8[§3WaterPE§8]§7 Nasza strona§8: §3www.WaterPE.PL §8*"]);
      $bot_cfg->save();
    }

    $this->getScheduler()->scheduleRepeatingTask(new BotTask($this, $bot_cfg), 20 * 110);

    $this->getScheduler()->scheduleRepeatingTask(new AlwaysDayTask($this), 1200 * 5);

    $this->getServer()->getPluginManager()->registerEvents($this, $this);

  }

  public function format(string $wiadomosc)
  {
    return '§8[§3WaterPE§8] §7' . $wiadomosc . ' §8*';
  } 
 

  public function GrupoweTP(PlayerInteractEvent $e)
  {
    $gracz = $e->getPlayer();

    $blok = $e->getBlock();

    $x = $blok->getFloorX();
    $y = $blok->getFloorY();
    $z = $blok->getFloorZ();

    $gracze[$x][$y][$z] = [];

    if ($blok->getId() == 25) {
      foreach ($this->getServer()->getOnlinePlayers() as $p) {

        $odleglosc = floor((new Vector3($x, $y, $z))->distance($p));

        if ($odleglosc <= 2) {
          array_push($gracze[$x][$y][$z], $p->getName());
        }
      }

      if (count($gracze[$x][$y][$z]) > 1) {

        $x_tp = mt_rand(1, 700);
        $z_tp = mt_rand(1, 700);
        $y_tp = $e->getPlayer()->getLevel()->getHighestBlockAt($x_tp, $z_tp) + 1;

        foreach ($gracze[$x][$y][$z] as $nick) {
          $gracz = $this->getServer()->getPlayerExact($nick)->teleport(new Vector3($x_tp, $y_tp, $z_tp));
        }
      } else {
        foreach ($gracze[$x][$y][$z] as $nick) {
          $gracz = $this->getServer()->getPlayerExact($nick)->sendTip($this->format("Brakuje §31 gracza"));
        }
      }
    }
  }
  
  public function onCommand(CommandSender $sender, Command $cmd, String $label, array $args) : bool {
      if($cmd->getName() == "xp"){
          $sender->sendMessage("ok");
          return true;
      }
          
      if($cmd->getName() == "testgui"){
          $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
          $inv = $menu->getInventory();
          $menu->setName("TEST GUI");
          $item = Item::get(2, 0, 1);
          $inv->addItem($item);
          $menu->setListener(InvMenu::readonly(function(DeterministicInvMenuTransaction $transaction): void {
              $player = $transaction->getPlayer();
              $item = $transaction->getItemClicked();
              $itemClickedWith = $transaction->getIemClickedWith();
              $inv = $transaction->getAction()->getInventory();
              
              if($item->getId() === 2) {
                  $player->sendMessage("essa");
                  $player->removeWindow($inv);
                  return;
              }
          }));
          $menu->send($sender);
      }
      return true;
  }

}

class BotTask extends Task
{
  public function __construct(Main $plugin, Config $cfg)
  {
    $this->plugin = $plugin;
    $this->cfg = $cfg;
  }

  public function onRun($tick)
  {
    $cfg = $this->cfg->get("wiadomosci");
    $wiadomosc = $cfg[rand(0, count($cfg) - 1)];
    $this->plugin->getServer()->broadcastMessage($wiadomosc);
  }
}

class AlwaysDayTask extends Task
{

  public function __construct(Main $main)
  {
    $this->main = $main;
  }

  public function onRun($tick)
  {
    $level = $this->main->getServer()->getDefaultLevel();

    $level->setTime(0);
  }
}