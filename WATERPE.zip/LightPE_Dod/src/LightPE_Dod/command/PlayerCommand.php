<?php

declare(strict_types=1);

namespace LightPE_Dod\command;

use LightPE_Dod\utils\FormatUtils;
use pocketmine\command\CommandSender;
use pocketmine\Player;

abstract class PlayerCommand extends CoreCommand {

    public function canUse(CommandSender $sender): bool {
        if(!$sender instanceof Player) {
            $sender->sendMessage(FormatUtils::messageFormat("Tej komendy mozesz uzyc tylko w grze!"));
            return false;
        }

        return parent::canUse($sender);
    }
}