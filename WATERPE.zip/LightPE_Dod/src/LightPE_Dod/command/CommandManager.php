<?php

declare(strict_types=1);

namespace LightPE_Dod\command;

use LightPE_Dod\command\commands\GlosowanieCommand;
use LightPE_Dod\command\commands\NieCommand;
use LightPE_Dod\command\commands\PomocCommand;
use LightPE_Dod\command\commands\ProtectCommand;
use LightPE_Dod\command\commands\SpawnCommand;
use LightPE_Dod\command\commands\BanCommand;
use LightPE_Dod\command\commands\TakCommand;
use LightPE_Dod\command\commands\WarpCommand;
use LightPE_Dod\command\commands\TempbanCommand;
use LightPE_Dod\command\commands\UnbanCommand;
use LightPE_Dod\command\commands\UnmuteCommand;
use LightPE_Dod\command\commands\SprawdzanieCommand;
use LightPE_Dod\command\commands\PrzyznajesieCommand;
use LightPE_Dod\command\commands\MuteCommand;

use pocketmine\Server;

class CommandManager {

    public static function init() : void {
        $unregisterCommands = [
            "ban",
            "pardon"
        ];

        foreach($unregisterCommands as $commandName) {
            $command = Server::getInstance()->getCommandMap()->getCommand($commandName);

            if($command === null)
                continue;

            Server::getInstance()->getCommandMap()->unregister($command);
        }

        $commands = [
            new BanCommand(),
            new SpawnCommand(),
            new GlosowanieCommand(),
            new TakCommand(),
            new NieCommand(),
            new ProtectCommand(),
            new TempbanCommand(),
            new UnbanCommand(),
            new SprawdzanieCommand(),
            new PrzyznajesieCommand(),
            new MuteCommand(),
            new UnmuteCommand(),
            new WarpCommand()
        ];

        Server::getInstance()->getCommandMap()->registerAll("dot", $commands);
    }
}