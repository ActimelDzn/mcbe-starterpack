<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\CoreCommand;

class UnbanCommand extends CoreCommand {

    public function __construct() {
        parent::__construct("unban", "Komenda unban", true);
    }

    public function execute(CommandSender $sender, string $label, array $args) : void {
        if(!$this->canUse($sender))
            return;

        if(!isset($args[0])) {
            $sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /unban §8(§3nick§8)"));
            return;
        }

        $user = UserManager::getUser($args[0]);

        if($user == null) {
            $sender->sendMessage(FormatUtils::messageFormat("Nie znaleziono uzytkownika!"));
            return;
        }

        if(!$user->isBanned()) {
            $sender->sendMessage(FormatUtils::messageFormat("Ten gracz nie jest zbanowany!"));
            return;
        }
        
        $user->unban();
        
        $sender->sendMessage(FormatUtils::messageFormat("Pomyslnie odbanowano gracza §3{$args[0]}"));
    }
}