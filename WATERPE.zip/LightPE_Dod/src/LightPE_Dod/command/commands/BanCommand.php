<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\CoreCommand;
use LightPE_Dod\api\Webhook;
use LightPE_Dod\api\Message;
use LightPE_Dod\api\Embed;

class BanCommand extends CoreCommand {

    public function __construct() {
        parent::__construct("ban", "Komenda ban", true);
    }

    public function execute(CommandSender $sender, string $label, array $args) : void {
 = date("d/m/Y");
		$cza        if(!$this->canUse($sender))
            return;

        if(empty($args)) {
            $sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /ban §8(§3nick§8) (§3powod§8)"));
            return;
        }

        $player = $sender->getServer()->getPlayer($args[0]);

        $nick = $player === null ? $args[0] : $player->getName();

        $user = UserManager::getUser($nick);

        if($user == null) {
            $sender->sendMessage(FormatUtils::messageFormat("Nie znaleziono uzytkownika!"));
            return;
        }

        if($user->isBanned()) {
            $sender->sendMessage(FormatUtils::messageFormat("Ten gracz zostal juz zbanowany!"));
            return;
        }

        array_shift($args);

        $reason = isset($args[0]) ? trim(implode(" ", $args)) : "BRAK";

        $user->ban($reason, $sender->getName());

        if($player != null)
            $player->kick(FormatUtils::banFormat($user->getBanReason(), $user->getBanAdmin(), $user->getBanDate()), false);

        $datas = date("H");
		$czasd = date("i");
		$czass = date("s");
        $sender->sendMessage(FormatUtils::messageFormat("Pomyslnie zbanowano gracza §3$nick §7z powodem: §3$reason"));
        $test = new Webhook("https://discord.com/api/webhooks/828888821172928542/n0Ej-1g1YKX0ofm9PxHH_OJ6iDS6xIGJT0DOObG5kRSRxILDEiPg78o_CnnoKPafuykd");
	    $msg = new Message();
	    $emb = new Embed();
	    $emb->setTitle("(🔒)  » $nick został zbanowany!");
	     $emb->setDescription("**» __Przez__:** `{$sender->getName()}` \n **» __Powód__: **$reason \n » **__Wygasa__:** NIGDY");
	    $emb->setFooter("LightPE | $data | {$czas}:{$czasd}:{$czass}");
	    $msg->addEmbed($emb);
	    $test->send($msg);
    }
}
