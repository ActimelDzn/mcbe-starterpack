<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\command\CoreCommand;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use pocketmine\command\CommandSender;

class NieCommand extends CoreCommand {

    public function __construct() {
        parent::__construct("nie", "Komenda nie");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if(!$this->canUse($sender))
            return;

        if(!GlobalVariables::$vote) {
            $sender->sendMessage(FormatUtils::messageFormat("Glosowanie nie trwa!"));
            return;
        }

        if(isset(GlobalVariables::$votes[$sender->getName()])) {
            $sender->sendMessage(FormatUtils::messageFormat("Zaglosowales juz!"));
            return;
        }

        GlobalVariables::$voteNoCounter++;
        GlobalVariables::$votes[$sender->getName()] = true;
        $sender->sendMessage(FormatUtils::messageFormat("Zaglosowales na: §cnie"));
    }
}