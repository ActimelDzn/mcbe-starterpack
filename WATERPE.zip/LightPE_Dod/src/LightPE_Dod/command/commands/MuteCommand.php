<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\CoreCommand;

class MuteCommand extends CoreCommand {

    public function __construct() {
        parent::__construct("mute", "Komenda mute", true);
    }

    public function execute(CommandSender $sender, string $label, array $args) : void {
        if(!$this->canUse($sender))
            return;

        if(!isset($args[1])) {
            $sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /mute §8(§3nick§8) (§3forever§8/§3czas§7[§3h§8/§3m§8/§3s§7]§8) (§3powod§8)"));
            return;
        }

        $player = $sender->getServer()->getPlayer($args[0]);

        $nick = $player == null ? $args[0] : $player->getName();

        $user = UserManager::getUser($nick);

        if($user == null) {
            $sender->sendMessage(FormatUtils::messageFormat("Nie znaleziono uzytkownika!"));
            return;
        }

        if($user->isMuted()) {
            $sender->sendMessage(FormatUtils::messageFormat("Ten gracz zostal juz zmutowany!"));
            return;
        }

        if($args[1] == "forever")
            $time = null;
        else {
            if(!strpos($args[1], "d") && !strpos($args[1], "h") && !strpos($args[1], "m") && !strpos($args[1], "s")){
                $sender->sendMessage(FormatUtils::messageFormat("Nieprawidlowy format czasu!"));
                return;
            }

            $time = 0;

            if(strpos($args[1], "d"))
                $time = intval(explode("d", $args[1])[0]) * 86400;

            if(strpos($args[1], "h"))
                $time = intval(explode("h", $args[1])[0]) * 3600;

            if(strpos($args[1], "m"))
                $time = intval(explode("h", $args[1])[0]) * 60;

            if(strpos($args[1], "s"))
                $time = intval(explode("s", $args[1])[0]);
        }

        $reason = "";

        for($i = 2; $i <= count($args) - 1; $i++)
            $reason .= $args[$i] . " ";

        if($reason == "") $reason = "BRAK";

        $user->mute($reason, $sender->getName(), $time);

        $sender->sendMessage(FormatUtils::messageFormat("Pomyslnie zmutowano gracza §3$nick §7na czas §2$args[1] §7z powodem: §3$reason"));

        if($player !== null)
            $player->sendMessage(FormatUtils::messageFormatLines(["Zostales zmutowany przez: §3{$sender->getName()}", "Czas mute'a: §3$args[1]", "Powod mute'a: §3$reason"]));
    }
}
