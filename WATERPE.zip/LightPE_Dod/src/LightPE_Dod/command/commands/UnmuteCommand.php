<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\CoreCommand;

class UnmuteCommand extends CoreCommand {

    public function __construct() {
        parent::__construct("unmute", "Komenda unmute", true);
    }

    public function execute(CommandSender $sender, string $label, array $args) : void {
        if(!$this->canUse($sender))
            return;

        if(empty($args)) {
            $sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /unmute §8(§3nick§8)"));
            return;
        }

        $player = $sender->getServer()->getPlayer($args[0]);

        $nick = $player == null ? $args[0] : $player->getName();

        $user = UserManager::getUser($nick);

        if($user == null) {
            $sender->sendMessage(FormatUtils::messageFormat("Nie znaleziono uzytkownika!"));
            return;
        }

        if(!$user->isMuted()) {
            $sender->sendMessage(FormatUtils::messageFormat("Ten gracz nie jest zmutowany!"));
            return;
        }

        $user->unmute();

        $sender->sendMessage(FormatUtils::messageFormat("Odmutowano gracza §3{$player->getName()}"));

        if($player)
            $player->sendMessage(FormatUtils::messageFormat("Zostales odmutowany!"));
    }
}
