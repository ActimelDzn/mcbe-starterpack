<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\CoreCommand;
use LightPE_Dod\api\Webhook;
use LightPE_Dod\api\Message;
use LightPE_Dod\api\Embed;
use LightPE_Dod\form\WarpsForm;
use LightPE_Dod\manager\WarpsManager;

class WarpCommand extends CoreCommand {

    public function __construct() {
        parent::__construct("warp", "Komenda warp", true);
    }

    public function execute(CommandSender $sender, string $label, array $args) : void {
        if(!$this->canUse($sender))
            return;


        $sender->sendForm(new WarpsForm());

        if(isset($args[0])) {
            if($args[0] == "set") {

                $test = "pl";
                WarpsManager::setWarp($test, ["11", "233", "32"]);
                $sender->sendMessage("USTAWIONO WARP");
            }
        }
    }
}
