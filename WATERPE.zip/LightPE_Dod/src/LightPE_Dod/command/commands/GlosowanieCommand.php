<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\Main;
use LightPE_Dod\task\GlosowanieTask;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\CoreCommand;

class GlosowanieCommand extends CoreCommand {

    public function __construct() {
        parent::__construct("glosowanie", "Komenda glosowanie", true);
    }

    public function execute(CommandSender $sender, string $label, array $args) : void {
        if(!$this->canUse($sender))
            return;

        if(!isset($args[1])) {
            $sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /glosowanie §8(§3czas w sekundach§8) §8(§3wiadomosc§8)"));
            return;
        }

        if(GlobalVariables::$vote) {
            $sender->sendMessage(FormatUtils::messageFormat("Glosowanie juz trwa!"));
            return;
        }

        $time = $args[0];

        if(!is_numeric($time)) {
            $sender->sendMessage(FormatUtils::messageFormat("Argument §31 §7musi byc numeryczny!"));
            return;
        }

        GlobalVariables::$vote = true;

        Main::getInstance()->getScheduler()->scheduleDelayedTask(new GlosowanieTask(), 20*$time);

        array_shift($args);

        $message = implode(" ", $args);

        $sender->getServer()->broadcastMessage("§8» §7{$message}§c?");
        $sender->getServer()->broadcastMessage("§8» §2/tak");
        $sender->getServer()->broadcastMessage("§8» §c/nie");
    }
}