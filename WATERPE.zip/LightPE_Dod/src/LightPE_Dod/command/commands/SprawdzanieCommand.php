<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use pocketmine\Player;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\PlayerCommand;
use pocketmine\math\Vector3;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use LightPE_Dod\Main;

class SprawdzanieCommand extends PlayerCommand {

	public function __construct() {
		parent::__construct("sprawdzanie", "Komenda sprawdzanie", true);
	}

	public function execute(CommandSender $sender, string $label, array $args) : void {
	    if(!$this->canUse($sender))
	        return;

		if(!isset($args[0])) {
			$sender->sendMessage(FormatUtils::messageFormatLines(["Poprawne uzycie:", "/sprawdzanie sprawdz §8(§3nick§8)", "/sprawdzanie zbanuj §8(§3nick§8)", "/sprawdzanie czysty §8(§3nick§8)", "/sprawdzanie ustaw"]));
			return;
		}

		switch($args[0]) {

			case "sprawdz":

			 if(!isset($args[1])) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /sprawdzanie sprawdz §8(§3nick§8)"));
			 	return;
			 }

			 $player = $sender->getServer()->getPlayer($args[1]);

			 if($player == null) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Ten gracz jest §3offline"));
			 	return;
			 }

			 $nick = $player->getName();

			 /*if($nick == $sender->getName()) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Nie mozesz sprawdzic samego siebie!"));
			 	return;
			 }*/

			 if(isset(GlobalVariables::$spr[$nick])) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Ten gracz jest juz sprawdzany!"));
			 	return;
			 }

			 $cfg = Main::getInstance()->getConfig()->get("sprawdzanie");

			 if(!$cfg) {
			     $sender->sendMessage(FormatUtils::messageFormat("Musisz ustawic pozycje sprawdzania!"));
			     return;
    }
    
    GlobalVariables::$spr[$nick] = [$player->asVector3(), $sender->getName()];
    
			 $pos = new Vector3($cfg['x'], $cfg['y'], $cfg['z']);

			 $sender->teleport($pos);
			 $player->teleport($pos);

			 $sender->getServer()->broadcastMessage(FormatUtils::messageFormat("Gracz §3$nick §7zostal wezwany do sprawdzania przez administratora §3{$sender->getName()}§7!"));

			 $sender->sendMessage(FormatUtils::messageFormat("Pomyslnie wezwano do sprawdzania gracza §3$nick"));
			 $player->sendMessage(FormatUtils::messageFormatLines(["Zostales wezwany do sprawdzania!", "Nick administratora: §2{$sender->getName()}", "Mozesz uzywac komend §3/msg§7, §3/r§7!"]));

			break;

			case "zbanuj":

			 if(!isset($args[1])) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /sprawdzanie zbanuj §8(§3nick§8)"));
			 	return;
			 }

			 $player = $sender->getServer()->getPlayer($args[1]);

			 if($player == null) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Ten gracz jest §3offline"));
			 	return;
			 }

			 $nick = $player->getName();

			 if(!isset(GlobalVariables::$spr[$nick])) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Ten gracz nie jest sprawdzany!"));
			 	return;
			 }
			 $player->teleport($player->getLevel()->getSafeSpawn());
			 
			 $user = UserManager::getUser($player);
			 
			 $user->ban("cheaty", $sender->getName());
    $player->kick(FormatUtils::banFormat($user->getBanReason(), $user->getBanAdmin(), $user->getBanDate()), false);

			 unset(GlobalVariables::$spr[$nick]);

			 $sender->teleport($sender->getLevel()->getSafeSpawn());

			 $sender->getServer()->broadcastMessage(FormatUtils::messageFormat("Gracz §3$nick §7zostal zbanowany za §3cheaty§7!"));

			break;

			case "czysty":
			 if(!isset($args[1])) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /sprawdzanie czysty §8(§3nick§8)"));
			 	return;
			 }

			 $player = $sender->getServer()->getPlayer($args[1]);

			 if($player == null) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Ten gracz jest §3offline"));
			 	return;
			 }

			 $nick = $player->getName();

			 if(!isset(GlobalVariables::$spr[$nick])) {
			 	$sender->sendMessage(FormatUtils::messageFormat("Ten gracz nie jest sprawdzany!"));
			 	return;
			 }

			 $player->teleport(GlobalVariables::$spr[$nick][0]);
			 $sender->teleport($player->getLevel()->getSafeSpawn());

			 unset(GlobalVariables::$spr[$nick]);

			 $sender->getServer()->broadcastMessage(FormatUtils::messageFormat("Gracz §3$nick §7okazal sie byc czysty!"));

			break;

			case "ustaw":
			 $pos = $sender->asVector3();

			 $x = $pos->getX();
			 $y = $pos->getY();
			 $z = $pos->getZ();

			 $cfg = Main::getInstance()->getConfig();

			 $cfg->set("sprawdzanie", [
			  "x" => $x,
			  "y" => $y,
			  "z" => $z
			 ]);
			 $cfg->save();

			 $sender->sendMessage(FormatUtils::messageFormat("Pomyslnie ustawiono pozycje sprawdzarki!"));
			break;

			default:
			 $sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /sprawdzanie czysty §8(§3nick§8)"));
		}
	}
}