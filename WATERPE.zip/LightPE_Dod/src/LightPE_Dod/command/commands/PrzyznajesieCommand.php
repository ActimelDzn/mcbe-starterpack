<?php

namespace LightPE_Dod\command\commands;

use LightPE_Dod\command\PlayerCommand;
use pocketmine\command\CommandSender;
use LightPE_Dod\utils\GlobalVariables;
use LightPE_Dode\utils\FormatUtils;
use LightPE_Dod\user\UserManager;

class PrzyznajesieCommand extends PlayerCommand {
	
	public function __construct() {
		parent::__construct("przyznajesie", "Komenda przyznajesie");
	}
	
	public function execute(CommandSender $sender, string $label, array $args) : void {
	    if(!$this->canUse($sender))
	        return;

		$nick = $sender->getName();
		
		if(!isset(GlobalVariables::$spr[$nick])) {
			$sender->sendMessage(FormatUtils::messageFormat("Musisz byc sprawdzany aby uzyc tej komendy!"));
			return;
		}
		
		$user = UserManager::getUser($sender);
		
		$sender->teleport($sender->getLevel()->getSafeSpawn());
		
		$user->ban("Przyzanie sie do cheatow", GlobalVariables::$spr[$nick][1], (24*3600)*3);

  $sender->kick(FormatUtils::banFormat($user->getBanReason(), $user->getBanAdmin(), $user->getBanDate()), false);
		
		unset(GlobalVariables::$spr[$nick]);
		
		$sender->getServer()->broadcastMessage(FormatUtils::messageFormat("Gracz §3$nick §7przyznal sie do cheatow"));
	}
}