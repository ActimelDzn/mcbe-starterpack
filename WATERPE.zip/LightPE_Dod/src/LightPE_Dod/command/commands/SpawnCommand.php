<?php

declare(strict_types=1);

namespace LightPE_Dod\command\commands;

use LightPE_Dod\command\PlayerCommand;
use LightPE_Dod\user\User;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\task\SpawnTask;
use pocketmine\command\CommandSender;

class SpawnCommand extends PlayerCommand {

    public function __construct() {
        parent::__construct("lobby", "Komenda spawn", false, ["spawn"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if(!$this->canUse($sender))
            return;

        $sender->sendMessage(FormatUtils::messageFormat("Teleportacja nastapi za §310 §7sekund, nie ruszaj sie!"));

        $user = UserManager::getUser($sender);

        if(!$user->findTask(SpawnTask::class))
            $user->addTask(new SpawnTask($sender), 20*10, User::TASK_DELAYED);
    }
}