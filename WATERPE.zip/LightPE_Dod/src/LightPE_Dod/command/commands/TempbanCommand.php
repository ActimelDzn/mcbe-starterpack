<?php

namespace LightPE_Dod\command\commands;

use pocketmine\Server;
use pocketmine\command\CommandSender;
use LightPE_Dod\command\CoreCommand;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\api\Webhook;
use LightPE_Dod\api\Message;
use LightPE_Dod\api\Embed;

class TempbanCommand extends CoreCommand {

	public function __construct() {
		parent::__construct("tempban", "Komenda tempban", true);
	}

	public function execute(CommandSender $sender, string $label, array $args) : void {
		if(!$this->canUse($sender))
		    return;

		if(!isset($args[1])) {
			$sender->sendMessage(FormatUtils::messageFormat("Poprawne uzycie: /tempban §8(§3nick§8) (§3czas§7[§3h§8/§3m§8/§3s§7]§8) (§3powod§8)"));
			return;
		}
		$player = Server::getInstance()->getPlayer($args[0]);

		$nick = $player == null ? $args[0] : $player->getName();
		
		$user = UserManager::getUser($nick);
		
		if($user == null) {
            $sender->sendMessage(FormatUtils::messageFormat("Nie znaleziono uzytkownika!"));
            return;
        }

		if($user->isBanned()) {
			$sender->sendMessage(FormatUtils::messageFormat("Ten gracz zostal juz zbanowany!"));
			return;
		}

		if(!strpos($args[1], "d") && !strpos($args[1], "h") && !strpos($args[1], "m") && !strpos($args[1], "s")){
			 $sender->sendMessage(FormatUtils::messageFormat("Nieprawidlowy format czasu!"));
 			return;
  }

  $time = 0;

 	if(strpos($args[1], "d"))
		$time = intval(explode("d", $args[1])[0]) * 86400;

 	if(strpos($args[1], "h"))
		$time = intval(explode("h", $args[1])[0]) * 3600;

		if(strpos($args[1], "m"))
		$time = intval(explode("h", $args[1])[0]) * 60;

		if(strpos($args[1], "s"))
		$time = intval(explode("s", $args[1])[0]);

		$reason = "";

		for($i = 2; $i <= count($args) - 1; $i++)
		 $reason .= $args[$i] . " ";

		if($reason == "") $reason = "BRAK";
		
		$user->ban($reason, $sender->getName(), $time);

        if($player != null)
            $player->kick(FormatUtils::banFormat($user->getBanReason(), $user->getBanAdmin(), $user->getBanDate()), false);

		$sender->sendMessage(FormatUtils::messageFormat("Pomyslnie zbanowano gracza §3$nick §7na czas §3$args[1] §7z powodem: §3$reason"));
		        $data = date("d/m/Y");
		$czas = date("H");
		$czasd = date("i");
		$czass = date("s");
        $sender->sendMessage(FormatUtils::messageFormat("Pomyslnie zbanowano gracza §3$nick §7z powodem: §3$reason"));
        $test = new Webhook("https://discord.com/api/webhooks/828888821172928542/n0Ej-1g1YKX0ofm9PxHH_OJ6iDS6xIGJT0DOObG5kRSRxILDEiPg78o_CnnoKPafuykd");
	    $msg = new Message();
	    $emb = new Embed();
	    $emb->setTitle("(🔒)  » {$nick} został zbanowany!");
	    $emb->setDescription("**» __Przez__:** `{$sender->getName()}` \n **» __Powód__:** $reason \n **» __Wygasa__:** $args[1]");
	    $emb->setFooter("LightPE | $data | {$czas}:{$czasd}:{$czass}");
	    $msg->addEmbed($emb);
	    $test->send($msg);
	}
}