<?php

declare(strict_types=1);

namespace LightPE_Dod\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

abstract class CoreCommand extends Command {

    private $usePermission = null;
    private $seePermission = null;

    public function __construct(string $name, string $description = "", bool $usePerm = false, array $aliases = []) {
        parent::__construct($name, $description, null, $aliases);

        $this->seePermission = $seePermission = "LightPE.command.".$name.".see";
        $this->setPermission($seePermission);

        if($usePerm)
            $this->usePermission = "LightPE.command.".$name;
    }

    public function getUsePermission() : ?string {
        return $this->usePermission;
    }

    public function getSeePermission() : ?string {
        return $this->seePermission;
    }

    public function canUse(CommandSender $sender) : bool {
        if($this->usePermission == null)
            return true;

        return $sender->hasPermission($this->usePermission);
    }
}