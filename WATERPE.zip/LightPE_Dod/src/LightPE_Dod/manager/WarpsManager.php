<?php

declare(strict_types=1);

namespace LightPE_Dod\manager;

use pocketmine\level\Position;
use pocketmine\Server;

class WarpsManager {

    private static $db;

    public static function init(\SQLite3 $db) : void {
        $db->exec("CREATE TABLE IF NOT EXISTS warps (name TEXT, levelName TEXT, x DOUBLE, y DOUBLE, z DOUBLE)");
        self::$db = $db;
    }

    public static function setWarp(string $name, Position $pos) : void {
        $x = $pos->getX();
        $y = $pos->getY();
        $z = $pos->getZ();
        $levelName = $pos->getLevel()->getName();

        self::$db->query("INSERT INTO warps (name, levelName, x, y, z) VALUES ('$name', '$levelName', '$x', '$y', '$z')");
    }

    public static function removeWarp(string $name) : void {
        self::$db->query("DELETE FROM warps WHERE name = '$name'");
    }

    public static function getWarpPosition(string $name) : Position {
        $array =self::$db->query("SELECT * FROM warps WHERE name = '$name'")->fetchArray(SQLITE3_ASSOC);

        return new Position($array['x'], $array['y'], $array['z'], Server::getInstance()->getLevelByName($array['levelName']));
    }

    public static function isWarpExists(string $name) : bool {
        $array = self::$db->query("SELECT * FROM warps WHERE name = '$name'")->fetchArray();

        return !empty($array);
    }

    public static function getWarpByIndex(int $index) : ?string {
        $i = 0;

        $array = self::$db->query("SELECT * FROM warps");

        while($row = $array->fetchArray(SQLITE3_ASSOC)) {
            if($i == $index)
                return $row['name'];

            $i++;
        }

        return null;
    }

    public static function getWarps() : array {
        $warps = [];

        $result = self::$db->query("SELECT * FROM warps");

        while($array = $result->fetchArray(SQLITE3_ASSOC))
            $warps[] = $array['name'];

        return $warps;
    }
}