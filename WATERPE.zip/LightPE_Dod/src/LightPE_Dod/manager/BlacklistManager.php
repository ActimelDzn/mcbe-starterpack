<?php

declare(strict_types=1);

namespace LightPE_Dod\manager;

use pocketmine\utils\Config;
use LightPE_Dod\Main;

class BlacklistManager {
	
	public static $config;
	
	public static function init() : void {
		self::$config = new Config(Main::getInstance()->getDataFolder(). "blacklist.yml", Config::YAML, [
		    "players" => []
        ]);
	}
	
	public static function getBlacklistPlayers() : array {
		return self::$config->get("players");
	}

	
	public static function addPlayer(string $nick) : void {
		$nick = strtolower($nick);
		$players = self::$config->get("players");
		if(in_array($nick, $players))
		 return;
		$players[] = $nick;
		self::$config->set("players", $players);
		self::$config->save();
	}
	
	public static function removePlayer(string $nick) : void {
	    if(!self::inOnBlacklist($nick))
	        return;

		$nick = strtolower($nick);
		$players = self::$config->get("players");
		unset($players[array_search($nick, $players)]);
		
		$newArray = [];
		
		foreach($players as $player)
		 $newArray[] = $player;
		
		self::$config->set("players", $newArray);
		self::$config->save();
	}
	
	public static function inOnBlacklist(string $nick) : bool {
		$nick = strtolower($nick);
		$players = self::getBlacklistPlayers();
		return in_array($nick, $players);
	}
}