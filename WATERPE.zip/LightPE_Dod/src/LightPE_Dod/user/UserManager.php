<?php

declare(strict_types=1);

namespace LightPE_Dod\user;

use pocketmine\Player;

class UserManager {

    private static $users = [];

    private static $db = null;

    public static function init(\SQLite3 $db) : void {
        $db->exec("CREATE TABLE IF NOT EXISTS users (userName TEXT PRIMARY KEY NOT NULL, ".User::KIT_PLAYER." TEXT, ".User::KIT_VIP." TEXT, ".User::KIT_SVIP." TEXT, ".User::KIT_YOUTUBE." TEXT, ".User::KIT_YOUTUBE_PLUS." TEXT, ".User::IS_BANNED." INT, ".User::BAN_REASON." TEXT, ".User::BAN_ADMIN." TEXT, ".User::BAN_DATE." TEXT, ".User::IS_MUTED." INT, ".User::MUTE_REASON." TEXT, ".User::MUTE_ADMIN." TEXT, ".User::MUTE_DATE." TEXT, ".User::DROP_DIAMONDS." INT, ".User::DROP_GOLD." INT, ".User::DROP_IRON." INT, ".User::DROP_EMERALD." INT, ".User::DROP_LAPIS." INT, ".User::DROP_ENDERPEARL." INT, ".User::DROP_BOOKSHELF." INT, ".User::DROP_COAL." INT, ".User::DROP_GUNPOWER." INT, ".User::DROP_COBBLESTONE." INT)");
        self::$db = $db;
    }

    private static function isValidUser($user) : bool {
        return is_string($user) || $user instanceof Player;
    }

    public static function getUser($user) : ?User {
        if(!self::userExists($user))
            return null;

        $userName = $user instanceof Player ? $user->getName() : $user;

        if(isset(self::$users[$userName]))
            return self::$users[$userName];

        $user = new User(self::$db, $userName);
        self::$users[$userName] = $user;

        return $user;
    }

    public static function userExists($user) : bool {
        if(!self::isValidUser($user))
            return false;

        $userName = $user instanceof Player ? $user->getName() : $user;

        return !empty(self::$db->query("SELECT * FROM users WHERE userName = '$userName'")->fetchArray());
    }

    public static function createUser($user) : void {
        if(self::userExists($user))
            return;

        $userName = $user instanceof Player ? $user->getName() : $user;

        self::$db->query("REPLACE INTO users (userName, ".User::KIT_PLAYER.", ".User::KIT_VIP.", ".User::KIT_SVIP.", ".User::KIT_YOUTUBE.", ".User::KIT_YOUTUBE_PLUS.", ".User::IS_BANNED.", ".User::BAN_REASON.", ".User::BAN_ADMIN.", ".User::BAN_DATE.", ".User::IS_MUTED.", ".User::MUTE_REASON.", ".User::MUTE_ADMIN.", ".User::MUTE_DATE.", ".User::DROP_DIAMONDS.", ".User::DROP_GOLD.", ".User::DROP_IRON.", ".User::DROP_EMERALD.", ".User::DROP_LAPIS.", ".User::DROP_ENDERPEARL.", ".User::DROP_BOOKSHELF.", ".User::DROP_COAL.", ".User::DROP_GUNPOWER.", ".User::DROP_COBBLESTONE.") VALUES ('$userName', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1')");
    }
}