<?php

declare(strict_types=1);

namespace LightPE_Dod\user;

use LightPE_Dod\Main;
use pocketmine\scheduler\Task;

class User {

    private $db;

    private $userName;

    private $userData = [];

    private $tasks = [];

    public const KIT_PLAYER = "kit_player";
    public const KIT_VIP = "kit_vip";
    public const KIT_SVIP = "kit_svip";
    public const KIT_YOUTUBE = "kit_yt";
    public const KIT_YOUTUBE_PLUS = "kit_ytp";
    public const IS_BANNED = "is_banned";
    public const BAN_REASON = "ban_reason";
    public const BAN_DATE = "ban_date";
    public const BAN_ADMIN = "ban_admin";
    public const IS_MUTED = "is_muted";
    public const MUTE_REASON = "mute_reason";
    public const MUTE_DATE = "mute_date";
    public const MUTE_ADMIN = "mute_admin";
    public const DROP_DIAMONDS = "drop_diamonds";
    public const DROP_GOLD = "drop_gold";
    public const DROP_IRON = "drop_iron";
    public const DROP_EMERALD = "drop_emerald";
    public const DROP_LAPIS = "drop_lapis";
    public const DROP_ENDERPEARL = "drop_enderpearl";
    public const DROP_BOOKSHELF = "drop_bookshelf";
    public const DROP_COAL = "drop_coal";
    public const DROP_GUNPOWER = "drop_gunpower";
    public const DROP_COBBLESTONE = "drop_cobblestone";

    public const TASK_DELAYED = 0;
    public const TASK_REPEATING = 1;

    public function __construct(\SQLite3 $db, string $userName) {
        $this->db = $db;
        $this->userName = $userName;

        $this->initUser();
    }

    private function initUser() : void {
        $array = $this->db->query("SELECT * FROM users WHERE userName = '$this->userName'")->fetchArray(SQLITE3_ASSOC);

        $this->userData[self::KIT_PLAYER] = $array[self::KIT_PLAYER];
        $this->userData[self::KIT_VIP] = $array[self::KIT_VIP];
        $this->userData[self::KIT_SVIP] = $array[self::KIT_SVIP];
        $this->userData[self::KIT_YOUTUBE] = $array[self::KIT_YOUTUBE];
        $this->userData[self::KIT_YOUTUBE_PLUS] = $array[self::KIT_YOUTUBE_PLUS];
        $this->userData[self::IS_BANNED] = $array[self::IS_BANNED];
        $this->userData[self::BAN_REASON] = $array[self::BAN_REASON];
        $this->userData[self::BAN_DATE] = $array[self::BAN_DATE];
        $this->userData[self::BAN_ADMIN] = $array[self::BAN_ADMIN];
        $this->userData[self::IS_MUTED] = $array[self::IS_MUTED];
        $this->userData[self::MUTE_REASON] = $array[self::MUTE_REASON];
        $this->userData[self::MUTE_DATE] = $array[self::MUTE_DATE];
        $this->userData[self::MUTE_ADMIN] = $array[self::MUTE_ADMIN];
        $this->userData[self::DROP_DIAMONDS] = $array[self::DROP_DIAMONDS];
        $this->userData[self::DROP_GOLD] = $array[self::DROP_GOLD];
        $this->userData[self::DROP_IRON] = $array[self::DROP_IRON];
        $this->userData[self::DROP_EMERALD] = $array[self::DROP_EMERALD];
        $this->userData[self::DROP_LAPIS] = $array[self::DROP_LAPIS];
        $this->userData[self::DROP_ENDERPEARL] = $array[self::DROP_ENDERPEARL];
        $this->userData[self::DROP_BOOKSHELF] = $array[self::DROP_BOOKSHELF];
        $this->userData[self::DROP_COAL] = $array[self::DROP_COAL];
        $this->userData[self::DROP_GUNPOWER] = $array[self::DROP_GUNPOWER];
        $this->userData[self::DROP_COBBLESTONE] = $array[self::DROP_COBBLESTONE];
    }

    public function isKitCooldown(string $kit) : bool {
        if(!array_key_exists($kit, $this->userData))
            return false;

        $date = $this->userData[$kit];

        return $date == null ? false : time() < strtotime($date);
    }

    public function getKitCooldown(string $kit) : ?string {
        return array_key_exists($kit, $this->userData) ? $this->userData[$kit] : null;
    }

    public function setKitCooldown(string $kit, int $time) : void {
        if(!array_key_exists($kit, $this->userData))
            return;

        $date = date('d.m.Y H:i:s', time() + $time);
        $this->userData[$kit] = $date;

        $this->db->query("UPDATE users SET '$kit' = '$date' WHERE userName = '$this->userName'");
    }

    public function unsetKitCooldown(string $kit) : void {
        if(!array_key_exists($kit, $this->userData))
            return;

        $this->userData[$kit] = null;

        $this->db->query("UPDATE users SET '$kit' = NULL WHERE user = '$this->userName'");
    }

    public function ban(string $reason, string $adminName, ?int $time = null) : void {
        if(self::isBanned())
            return;
        
        $date = null;
        
        if($time !== null)
        	$date = date('d.m.Y H:i:s', time() + $time);

        $this->userData[self::IS_BANNED] = 1;
        $this->userData[self::BAN_REASON] = $reason;
        $this->userData[self::BAN_ADMIN] = $adminName;
        $this->userData[self::BAN_DATE] = $date;

        $this->db->query("UPDATE users SET ('".self::IS_BANNED."', '".self::BAN_REASON."', '".self::BAN_ADMIN."', '".self::BAN_DATE."') = ('1', '$reason', '$adminName', '$date') WHERE userName = '$this->userName'");
    }

    public function unban() : void {
        $this->userData[self::IS_BANNED] = 0;
        $this->userData[self::BAN_REASON] = null;
        $this->userData[self::BAN_ADMIN] = null;
        $this->userData[self::BAN_DATE] = null;

        $this->db->query("UPDATE users SET ('".self::IS_BANNED."', '".self::BAN_REASON."', '".self::BAN_ADMIN."', '".self::BAN_DATE."') = ('0', NULL, NULL, NULL) WHERE userName = '$this->userName'");
    }

    public function isBanned() : bool {
      	 if(!((bool)$this->userData[self::IS_BANNED]))
      	  return false;
      	  
    	   if($this->getBanDate() == null)
    	    return true;
    	    
    	    
    	   return time() < strtotime($this->getBanDate());
    }

    public function getBanReason() : ?string {
        return $this->userData[self::BAN_REASON];
    }

    public function getBanAdmin() : ?string {
        return $this->userData[self::BAN_ADMIN];
    }

    public function getBanDate() : ?string {
        return $this->userData[self::BAN_DATE];
    }

    public function mute(string $reason, string $adminName, ?int $time = null) : void {
        if(self::isBanned())
            return;

        $date = null;

        if($time !== null)
            $date = date('d.m.Y H:i:s', time() + $time);

        $this->userData[self::IS_MUTED] = 1;
        $this->userData[self::MUTE_REASON] = $reason;
        $this->userData[self::MUTE_ADMIN] = $adminName;
        $this->userData[self::MUTE_DATE] = $date;

        $this->db->query("UPDATE users SET ('".self::IS_MUTED."', '".self::MUTE_REASON."', '".self::MUTE_ADMIN."', '".self::MUTE_DATE."') = ('1', '$reason', '$adminName', '$date') WHERE userName = '$this->userName'");
    }

    public function unmute() : void {
        $this->userData[self::IS_MUTED] = 0;
        $this->userData[self::MUTE_REASON] = null;
        $this->userData[self::MUTE_ADMIN] = null;
        $this->userData[self::MUTE_DATE] = null;

        $this->db->query("UPDATE users SET ('".self::IS_MUTED."', '".self::MUTE_REASON."', '".self::MUTE_ADMIN."', '".self::MUTE_DATE."') = ('0', NULL, NULL, NULL) WHERE userName = '$this->userName'");
    }

    public function isMuted() : bool {
        if(!((bool)$this->userData[self::IS_MUTED]))
            return false;

        if($this->getMuteDate() == null)
            return true;


        return time() < strtotime($this->getMuteDate());
    }

    public function getMuteReason() : ?string {
        return $this->userData[self::MUTE_REASON];
    }

    public function getMuteAdmin() : ?string {
        return $this->userData[self::MUTE_ADMIN];
    }

    public function getMuteDate() : ?string {
        return $this->userData[self::MUTE_DATE];
    }

    public function addTask(Task $task, int $time, int $taskType) : void {
        $this->tasks[] = $task;

        switch($taskType) {
            case self::TASK_DELAYED:
                Main::getInstance()->getScheduler()->scheduleDelayedTask($task, $time);
            break;

            case self::TASK_REPEATING:
                Main::getInstance()->getScheduler()->scheduleRepeatingTask($task, $time);
            break;
        }
    }

    public function findTask(string $expectedClass) : ?Task {
        foreach($this->tasks as $task){
            if($task instanceof $expectedClass){
                return $task;
            }
        }

        return null;
    }

    public function removeTask(Task $task) : void {
        if($this->findTask(get_class($task)) === null)
            return;

        $this->findTask(get_class($task))->getHandler()->cancel();
        unset($this->tasks[array_search($task, $this->tasks)]);
    }

    public function isDropEnable(string $drop) : bool {
        if(substr($drop, 0, 5) != "drop_")
            return false;

        return (bool) $this->userData[$drop];
    }

    public function switchDrop(string $drop) : void {
        if(substr($drop, 0, 5) != "drop_")
            return;

        if($this->isDropEnable($drop)) {
            $this->userData[$drop] = 0;
            $this->db->query("UPDATE users SET '$drop' = '0' WHERE userName = '$this->userName'");
        } else {
            $this->userData[$drop] = 1;
            $this->db->query("UPDATE users SET '$drop' = '1' WHERE userName = '$this->userName'");
        }
    }

    public function turnOnAllDrops() : void {
        $drops = [
            self::DROP_DIAMONDS,
            self::DROP_GOLD,
            self::DROP_IRON,
            self::DROP_EMERALD,
            self::DROP_LAPIS,
            self::DROP_ENDERPEARL,
            self::DROP_BOOKSHELF,
            self::DROP_COAL,
            self::DROP_GUNPOWER,
            self::DROP_COBBLESTONE
        ];

        foreach($drops as $drop) {
            if(!$this->isDropEnable($drop))
                $this->switchDrop($drop);
        }
    }

    public function turnOffAllDrops() : void {
        $drops = [
            self::DROP_DIAMONDS,
            self::DROP_GOLD,
            self::DROP_IRON,
            self::DROP_EMERALD,
            self::DROP_LAPIS,
            self::DROP_ENDERPEARL,
            self::DROP_BOOKSHELF,
            self::DROP_COAL,
            self::DROP_GUNPOWER,
            self::DROP_COBBLESTONE
        ];

        foreach($drops as $drop) {
            if($this->isDropEnable($drop))
                $this->switchDrop($drop);
        }
    }
}