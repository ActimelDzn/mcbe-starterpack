<?php

declare(strict_types=1);

namespace LightPE_Dod\task;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ChatCodeTask extends Task {

    public function onRun(int $currentTick) : void {
        if(GlobalVariables::$chatCode !== null)
            return;

        $code = substr(md5(uniqid((string)mt_rand(), true)), 0, 8); //https://stackoverflow.com/questions/3954599/generate-random-string-from-4-to-8-characters-in-php
        GlobalVariables::$chatCode = $code;
    }
}
