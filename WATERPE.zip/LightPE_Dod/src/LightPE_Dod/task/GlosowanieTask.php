<?php

declare(strict_types=1);

namespace LightPE_Dod\task;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class GlosowanieTask extends Task {

    public function onRun(int $currentTick) : void {
        GlobalVariables::$vote = false;
        GlobalVariables::$votes = [];

        $yes = GlobalVariables::$voteYesCounter;
        $no = GlobalVariables::$voteNoCounter;

        GlobalVariables::$voteYesCounter = 0;
        GlobalVariables::$voteNoCounter = 0;

        Server::getInstance()->broadcastMessage("§8» §7Glosowanie sie zakonczylo");
        Server::getInstance()->broadcastMessage("§8» §2tak - $yes");
        Server::getInstance()->broadcastMessage("§8» §cnie - $no");
    }
}