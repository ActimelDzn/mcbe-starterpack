<?php

declare(strict_types=1);

namespace LightPE_Dod\task;

use LightPE_Dod\manager\WarpsManager;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class WarpTask extends Task {

    private $player;
    private $warpName;

    public function __construct(Player $player, string $warpName) {
        $this->player = $player;
        $this->warpName = $warpName;
    }

    public function onRun(int $currentTick) : void {
        $user = UserManager::getUser($this->player);
        $user->removeTask($this);

        if(!$this->player->isOnline())
            return;

        $this->player->teleport(WarpsManager::getWarpPosition($this->warpName));
        $this->player->sendMessage(FormatUtils::messageFormat("Przeteleportowano na warp §3{$this->warpName}"));
    }
}