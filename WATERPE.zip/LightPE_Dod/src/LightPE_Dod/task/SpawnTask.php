<?php

declare(strict_types=1);

namespace LightPE_Dod\task;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class SpawnTask extends Task {

    private $player;

    public function __construct(Player $player) {
        $this->player = $player;
    }

    public function onRun(int $currentTick) : void {
        $user = UserManager::getUser($this->player);
        $user->removeTask($this);

        if(!$this->player->isOnline())
            return;

        $this->player->teleport($this->player->getServer()->getDefaultLevel()->getSafeSpawn());
        $this->player->sendMessage(FormatUtils::messageFormat("Przeteleportowano na spawn"));
    }
}