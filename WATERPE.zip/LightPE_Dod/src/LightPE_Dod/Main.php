<?php

declare(strict_types=1);

namespace LightPE_Dod;

use LightPE_Dod\manager\BlacklistManager;
use LightPE_Dod\manager\ProtectManager;
use LightPE_Dod\manager\WarpsManager;
use LightPE_Dod\listener\ListenerManager;
use LightPE_Dod\task\ChatCodeTask;
use LightPE_Dod\utils\Settings;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use LightPE_Dod\command\CommandManager;
use LightPE_Dod\user\UserManager;

class Main extends PluginBase {

    private static $instance = null;

    private $db = null;

    public static function getInstance() : ?Main {
        return self::$instance;
    }

    public function onEnable() : void {
        $this->init();
        $this->executeTasks();
        $this->getLogger()->info("Plugin został włączony!");
    }

    private function init() : void {
        self::$instance = $this;

        $this->config = new Config($this->getDataFolder().'Config.yml', Config::YAML);

        $this->db = $db = new \SQLite3($this->getDataFolder(). 'DataBase.db');

        CommandManager::init();
        ListenerManager::init();
        UserManager::init($db);
        WarpsManager::init($db);
        ProtectManager::init();
    }

    private function executeTasks() : void {
        $this->getScheduler()->scheduleDelayedRepeatingTask(new ChatCodeTask(), 10*Settings::CHAT_CODE_COOLDOWN, 10*Settings::CHAT_CODE_COOLDOWN);
    }

    public function onDisable() : void {
        $this->getLogger()->info("Plugin został wyłączony!");
    }

    public function getDb() : ?\SQLite3 {
    	return $this->db;
    }
}
