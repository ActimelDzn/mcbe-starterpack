<?php

namespace LightPE_Dod\form;

use LightPE_Dod\manager\WarpsManager;
use LightPE_Dod\task\WarpTask;
use LightPE_Dod\user\User;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\Player;

class WarpsForm extends Form {

    public function __construct() {
        $data = [
            "type" => "form",
            "title" => "§l§2Warpy",
            "content" => "",
            "buttons" => []
        ];

        foreach(WarpsManager::getWarps() as $warpName)
            $data["buttons"][] = ["type" => "button", "text" => $warpName];

        if(empty($data["buttons"]))
            $data["content"] = "§l§3Brak warpow!";

        $this->data = $data;
    }


    public function handleResponse(Player $player, $data) : void {
        $formData = json_decode($data);

        if($formData === null) return;

        $warpName = WarpsManager::getWarpByIndex(intval($formData));

        if($warpName === null) {
            $player->sendMessage(FormatUtils::messageFormat("Ups, cos poszlo nie tak!"));
            return;
        }

        $player->sendMessage(FormatUtils::messageFormat("Teleportacja nastapi za §310 §7sekund, nie ruszaj sie!"));

        $user = UserManager::getUser($player);

        if(!$user->findTask(WarpTask::class))
            $user->addTask(new WarpTask($player, $warpName), 20*10, User::TASK_DELAYED);
    }
}