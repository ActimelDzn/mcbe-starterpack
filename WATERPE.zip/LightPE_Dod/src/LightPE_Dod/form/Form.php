<?php

declare(strict_types=1);

namespace LightPE_Dod\form;

use pocketmine\Player;
use pocketmine\form\Form as IForm;

class Form implements IForm {
	
	protected $data = [];
	
	public function handleResponse(Player $player, $data) : void {
		
	}
	
	public function jsonSerialize() : array {
		return $this->data;
	}
}