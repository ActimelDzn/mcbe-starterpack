<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\command\CoreCommand;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;

class PlayerCommandPreprocessListener implements Listener {

    public function unknownCommandMessage(PlayerCommandPreprocessEvent $e) : void {
        if($e->getMessage()[0] == '/') {
            $player = $e->getPlayer();
            $cmd = substr(explode(' ', $e->getMessage())[0], 1);

            $commandMap = $player->getServer()->getCommandMap();

            if($commandMap->getCommand($cmd) === null) {
                $e->setCancelled(true);
                $player->sendMessage(FormatUtils::messageFormat("Ta komenda nie istnieje! Uzyj polecenia: §3/pomoc"));
            }
        }
    }

    
    public function SprawdzanieKomendy(PlayerCommandPreprocessEvent $e) {
        if(!($e->getMessage()[0] == "/")) return;

        $player = $e->getPlayer();

        $cmd = explode(" ", $e->getMessage())[0];

        if(isset(GlobalVariables::$spr[$player->getName()])) {
            if($cmd != "/msg" && $cmd != "/r" && $cmd != "/przyznajesie") {
                $e->setCancelled(true);

                $player->sendMessage(FormatUtils::messageFormat("Jestes podczas sprawdzania, nie mozesz uzyc tej komendy!"));
            }
        }
    }
}