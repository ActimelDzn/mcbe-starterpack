<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\user\UserManager;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

class PlayerJoinListener implements Listener {

    public function registerUser(PlayerJoinEvent $e) : void {
        UserManager::createUser($e->getPlayer());
    }
}