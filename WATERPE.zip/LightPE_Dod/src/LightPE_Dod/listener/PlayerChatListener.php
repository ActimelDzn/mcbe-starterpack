<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\manager\ProtectManager;
use pocketmine\Item;
use pocketmine\inventory\Inventory;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use LightPE_Dod\utils\Settings;
use http\Client\Curl\User;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;

class PlayerChatListener implements Listener {

    private $lastChatMsg = [];

    /**
     * @param PlayerChatEvent $e
     *
     * @priority LOW
     * @ignoreCancelled true
     */

    /**
     * @param PlayerChatEvent $e
     *
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function ChatCode(PlayerChatEvent $e) : void {
        $player = $e->getPlayer();
        $message = $e->getMessage();

        if(GlobalVariables::$chatCode === $message) {
            $e->setCancelled(true);
            GlobalVariables::$chatCode = null;
              $player-getInventory()->addItem(Item::get(322, 0, 4));
              $player->getServer()->broadcastMessage(FormatUtils::messageFormat("Gracz §3{$player->getName()} §7jako pierwszy przepisal kod i otrzymal: 4 REFILE"));
        }
    }

    /**
     * @param PlayerChatEvent $e
     *
     * @priority LOWEST
     * @ignoreCancelled true
     */
    public function mute(PlayerChatEvent $e) {
        $player = $e->getPlayer();
        $nick = $player->getName();

        $user = UserManager::getUser($player);

        if($user->isMuted()) {
            $e->setCancelled(true);
            $player->sendMessage(FormatUtils::muteFormat($user->getMuteReason(), $user->getMuteAdmin(), $user->getMuteDate()));
        }
    }

    public function protectCreateTerrain(PlayerChatEvent $e) {
        $player = $e->getPlayer();
        $nick = $player->getName();

        $terrainName = $e->getMessage();

        if(isset(ProtectManager::$data[$nick])) {
            if(isset(ProtectManager::$data[$nick][0]) && isset(ProtectManager::$data[$nick][1])) {
                $e->setCancelled(true);
                if(ProtectManager::isTerrainExists($terrainName)) {
                    $player->sendMessage("§8» §7Teren o takiej nazwie juz istnieje, uzyj innej nazwy");
                    return;
                }

                ProtectManager::createTerrain($terrainName, ProtectManager::$data[$nick]);
                $player->sendMessage("§8» §7Teren o nazwie §3{$terrainName} §7zostal utworzony");
                unset(ProtectManager::$data[$nick]);
            }
        }
    }
}
