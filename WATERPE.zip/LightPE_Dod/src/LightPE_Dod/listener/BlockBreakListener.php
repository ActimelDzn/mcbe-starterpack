<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\manager\ProtectManager;
use LightPE_Dod\user\User;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use LightPE_Dod\utils\GlobalVariables;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;

class BlockBreakListener implements Listener {

    public function terrainBlockBreak(BlockBreakEvent $e) {
        $player = $e->getPlayer();
        $block = $e->getBlock();

        if(!ProtectManager::canBreak($player, $block))
            $e->setCancelled(true);
    }

    public function terrainWhiteBlocks(BlockBreakEvent $e) {
        $player = $e->getPlayer();
        $nick = $player->getName();

        $block = $e->getBlock();

        if(isset(GlobalVariables::$setWhiteBlock[$nick])) {
            $e->setCancelled(true);
            $terrainName = GlobalVariables::$setWhiteBlock[$nick];
            ProtectManager::addWhiteBlock($terrainName, $block);
            $player->sendMessage(Main::format("§7Dodano ten blok do listy bialych blokow"));
        } elseif(isset(GlobalVariables::$removeWhiteBlock[$nick])) {
            $e->setCancelled(true);
            $terrainName = GlobalVariables::$removeWhiteBlock[$nick];
            ProtectManager::removeWhiteBlock($terrainName, $block);
            $player->sendMessage(Main::format("§7Usunieto ten blok z listy bialych blokow"));
        }
    }

    public function protectPositionsChoose(BlockBreakEvent $e) {
        $player = $e->getPlayer();
        $nick = $player->getName();

        $block = $e->getBlock();

        if(isset(ProtectManager::$data[$nick])) {
            $e->setCancelled(true);
            if(!isset(ProtectManager::$data[$nick][0])) {
                ProtectManager::$data[$nick][0] = $block->asVector3();
                $player->sendMessage("§8» §7Wybierz §52 §7pozycje");
            } elseif(!isset(ProtectManager::$data[$nick][1])) {
                ProtectManager::$data[$nick][1] = $block->asVector3();
                $player->sendMessage("§8» §7Napisz na chacie nazwe terenu");
            }
        }
    }
 
}