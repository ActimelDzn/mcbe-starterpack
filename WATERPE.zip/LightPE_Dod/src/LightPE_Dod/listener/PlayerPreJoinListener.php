<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\manager\BlacklistManager;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerPreLoginEvent;

class PlayerPreJoinListener implements Listener {

    public function ban(PlayerPreLoginEvent $e) : void {
        $player = $e->getPlayer();
        $user = UserManager::getUser($player);

        if($user === null)
            return;

        if($user->isBanned()) {
            $e->setCancelled(true);

            $player->close("", FormatUtils::banFormat($user->getBanReason(), $user->getBanAdmin(), $user->getBanDate()));
        }
    }
}
