<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\manager\ProtectManager;
use LightPE_Dod\utils\GlobalVariables;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;

class EntityDamageListener implements Listener {

    public function terrainEntity(EntityDamageEvent $e) {
        $entity = $e->getEntity();

        if($e instanceof EntityDamageByEntityEvent)
            return;

        if(!ProtectManager::canDamage($entity))
            $e->setCancelled(true);
    }

    public function terrainEntityByEntity(EntityDamageEvent $e) {
        $entity = $e->getEntity();

        if($e instanceof EntityDamageByEntityEvent) {
            $damager = $e->getDamager();
            if(!ProtectManager::canDamageEntity($entity, $damager))
                $e->setCancelled(true);
        }
    }
}