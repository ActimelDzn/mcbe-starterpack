<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\GlobalVariables;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;

class PlayerQuitListener implements Listener {

    public function SprawdzanieBanOnQuit(PlayerQuitEvent $e) {
        $player = $e->getPlayer();
        $nick = $player->getName();

        if(isset(GlobalVariables::$spr[$nick])) {
        	$user = UserManager::getUser($player);
            $user->ban("cheaty", GlobalVariables::$spr[$nick][1]);

            unset(GlobalVariables::$spr[$nick]);

            $player->teleport($player->getLevel()->getSafeSpawn());

            $player->getServer()->broadcastMessage(FormatUtils::messageFormat("Gracz §3$nick §7wylogowal sie podczas sprawdzania!"));
        }
    }
}