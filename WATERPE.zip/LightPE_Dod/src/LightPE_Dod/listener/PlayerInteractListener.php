<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\manager\ProtectManager;
use LightPE_Dod\utils\Utils;
use pocketmine\block\Block;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;

class PlayerInteractListener implements Listener {

    public function terrainInteract(PlayerInteractEvent $e) {
        $player = $e->getPlayer();
        $block = $e->getBlock();

        if(!ProtectManager::canInteract($player, $block))
            $e->setCancelled(true);
    }
}
