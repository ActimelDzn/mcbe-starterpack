<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\manager\ProtectManager;
use LightPE_Dod\task\SpawnTask;
use LightPE_Dod\task\WarpTask;
use pocketmine\Player;
use LightPE_Dod\user\UserManager;
use LightPE_Dod\utils\FormatUtils;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;

class PlayerMoveListener implements Listener {

    public function cancelSpawnTaskOnMove(PlayerMoveEvent $e) : void {
        $player = $e->getPlayer();
        $user = UserManager::getUser($player);

        if($user->findTask(SpawnTask::class) !== null) {
            if(!$e->getFrom()->floor()->equals($e->getTo()->floor())) {
                $user->removeTask($user->findTask(SpawnTask::class));
                $player->sendMessage(FormatUtils::messageFormat("Teleportacja anulowana!"));
            }
        }
    }

    public function cancelWarpTaskOnMove(PlayerMoveEvent $e) : void {
        $player = $e->getPlayer();
        $user = UserManager::getUser($player);

        if($user->findTask(WarpTask::class) !== null) {
            if(!$e->getFrom()->floor()->equals($e->getTo()->floor())) {
                $user->removeTask($user->findTask(WarpTask::class));
                $player->sendMessage(FormatUtils::messageFormat("Teleportacja anulowana!"));
            }
        }
    }

    public function spawnFly(PlayerMoveEvent $e) {
        $player = $e->getPlayer();

        if($e->getTo()->equals($e->getFrom()))
            return;

        if($player->isOp() || !$player->hasPermission("spawn.fly"))
            return;

        $terrainName = ProtectManager::getTerrainNameFromPos($player);

        if($terrainName == "spawn-fly")
            $player->setAllowFlight(true);
        elseif($player->getAllowFlight() && $player->getGamemode() != Player::CREATIVE) {
            $player->setAllowFlight(false);
            $player->setFlying(false);
            $x = $player->getFloorX();
            $z = $player->getFloorZ();
            $y = $player->getLevel()->getHighestBlockAt($x, $z) + 1;
            $player->teleport($player->asPosition()->setComponents($x, $y, $z));
        }
    }
}
