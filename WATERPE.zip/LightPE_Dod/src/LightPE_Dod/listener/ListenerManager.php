<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\Main;
use pocketmine\Server;

class ListenerManager {

    public static function init() : void {
        $listeners = [
            new PlayerCommandPreprocessListener(),
            new PlayerJoinListener(),
            new PlayerPreJoinListener(),
            new PlayerMoveListener(),
            new PlayerChatListener(),
            new PlayerInteractListener(),
            new BlockPlaceListener(),
            new BlockBreakListener(),
            new EntityDamageListener(),
            new PlayerQuitListener()
        ];

        foreach($listeners as $listener)
            Server::getInstance()->getPluginManager()->registerEvents($listener, Main::getInstance());
    }
}