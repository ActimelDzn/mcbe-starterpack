<?php

declare(strict_types=1);

namespace LightPE_Dod\listener;

use LightPE_Dod\manager\ProtectManager;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;

class BlockPlaceListener implements Listener {

    public function terrainBlockPlace(BlockPlaceEvent $e) {
        $player = $e->getPlayer();
        $block = $e->getBlock();

        if(!ProtectManager::canPlace($player, $block))
            $e->setCancelled(true);
    }
}