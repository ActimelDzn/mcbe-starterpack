<?php

declare(strict_types=1);

namespace LightPE_Dod\utils;

class GlobalVariables {

    public static $vote = false;
    public static $votes = [];
    public static $voteYesCounter = 0;
    public static $voteNoCounter = 0;
    public static $chatCode = null;
    public static $setWhiteBlock = [];
    public static $removeWhiteBlock = [];
    public static $spr = [];
    public static $turbodrop = null;
}