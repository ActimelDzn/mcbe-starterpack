<?php

declare(strict_types=1);

namespace LightPE_Dod\utils;

class FormatUtils {

    public static function messageFormat(string $string) : string {
        return "§8[§3WaterPE§8] §7$string §8*";
    }

    public static function messageFormatLines(array $w) : string {
        return "§8» §7".implode("\n§8[§3WaterPE§8] §7", $w)."\n ";
    }

    public static function cooldownFormat(string $date) : string {
        $time = strtotime($date) - time();

        $hours = floor($time / 3600);
        $minutes = floor(($time / 60) % 60);
        $seconds = $time % 60;

        if($hours < 10)
            $hours = "0{$hours}";

        if($minutes < 10)
            $minutes = "0{$minutes}";

        if($seconds < 10)
            $seconds = "0{$seconds}";

        return "§3{$hours}§8:§3{$minutes}§8:§3{$seconds}";
    }

    public static function banFormat(string $reason, string $adminName, ?string $date) : string {
        if($date == null)
            $date = "NIGDY";

        return "§7Przez: §2".$adminName."\n".
        "§7Powód: §3".$reason."\n".
        "§7Wygasa: §3".$date;
    }

    public static function muteFormat(string $reason, string $adminName, ?string $date) : string {
        if($date == null)
            $date = "NIGDY";

        return self::messageFormatLines(["Zostales zmutowany przez: §3$adminName", "Data wygasniecia: §3$date", "Powod mute'a: §3$reason"]);
    }
}
