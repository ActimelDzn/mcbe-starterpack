<?php

declare(strict_types=1);

namespace LightPE_Dod\utils;

interface Settings {

    public const CHAT_MESSAGES_COOLDOWN = 0; // cooldown na pisanie na chacie (w sekundach)
    public const CHAT_CODE_COOLDOWN = 60*20; // co ile ma sie wyswietlac kod do przepisania (w sekundach)
}