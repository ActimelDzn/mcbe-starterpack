<?php

declare(strict_types=1);

namespace LightPE_Dod\utils;

use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\math\Vector3;

class Utils {

    public static function getBookshelfsCount(Vector3 $pos, Level $level) : int {
        $count = 0;

        if($level->getBlock($pos->add(2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(2, 0, 1))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(2, 0, -1))->getId() == Block::BOOKSHELF) $count++;

        if($level->getBlock($pos->add(-2, 0))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-2, 0, -1))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-2, 0, 1))->getId() == Block::BOOKSHELF) $count++;

        if($level->getBlock($pos->add(0, 0, 2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(1, 0, 2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-1, 0, 2))->getId() == Block::BOOKSHELF) $count++;

        if($level->getBlock($pos->add(0, 0, -2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-1, 0, -2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(1, 0, -2))->getId() == Block::BOOKSHELF) $count++;



        if($level->getBlock($pos->add(2, 1))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(2, 1, 1))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(2, 1, -1))->getId() == Block::BOOKSHELF) $count++;

        if($level->getBlock($pos->add(-2, 1))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-2, 1, -1))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-2, 1, 1))->getId() == Block::BOOKSHELF) $count++;

        if($level->getBlock($pos->add(0, 1, 2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(1, 1, 2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-1, 1, 2))->getId() == Block::BOOKSHELF) $count++;

        if($level->getBlock($pos->add(0, 1, -2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(-1, 1, -2))->getId() == Block::BOOKSHELF) $count++;
        if($level->getBlock($pos->add(1, 1, -2))->getId() == Block::BOOKSHELF) $count++;

        return (int) $count;
    }
}