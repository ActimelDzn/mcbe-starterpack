<?php

namespace LightPE_Core\commands;

use pocketmine\Server;

use LightPE_Core\Main;

use pocketmine\command\{
	Command, CommandSender
};

use LightPE_Core\api\Webhook;
use LightPE_Core\api\Message;
use LightPE_Core\api\Embed;

class HelpopCommand extends Command {
    
    public $cooldownList = [];
	
	public function __construct() {
		parent::__construct("helpop", "komenda helpop", false, ["zglos"]);
	}
	
	public function execute(CommandSender $sender, String $label, array $args) : void {
        $data = date("d/m/Y");
        $czas = date("H");
        $czasd = date("i");
        $czass = date("s");

        $test = new Webhook("https://discord.com/api/webhooks/829627324856139806/5PC5Jr02ZPm9prCJOHnFEyfBKdaaJlI7x2cgfa-jJxcyLHUsppDfViUI7_rNxXrHqVU5");
        $msg = new Message();
        $emb = new Embed();
        $emb->setTitle("(🔥)  » Wpisana komenda:");
        $emb->setDescription("**» __Gracz__: `{$sender->getName()}` \n » __probowal uzyc__: /helpop**");
        $emb->setFooter("LightPE | $data | {$czas}:{$czasd}:{$czass}");
        $msg->addEmbed($emb);
        $test->send($msg);
		if(!isset($this->cooldownList[$sender->getName()])) {
		    $this->cooldownList[$sender->getName()] = time() + 62;
		    
		if(empty($args)){
			$sender->sendMessage(Main::formatL(["Poprawne uzycie to §2/helpop §8(§2wiadomosc§8)"]));
			return;
		}
		
		$w = trim(implode(" ", $args));
		$data = date("d/m/Y");
		$czas = date("H");
		$czasd = date("i");
		$czass = date("s");
		
			$test = new Webhook("https://discord.com/api/webhooks/828906178766700564/B8LDxOom1L5X-U-oIego5PUYlhIB1oRpG3_9N1Z7WGZVAuSoQvGjSNduPOllm9tsJPku");
	        $msg = new Message();
	        $emb = new Embed();
	        $emb->setTitle("(🔥)  » Nowe Zgłoszenie:");
	        $emb->setDescription("**» __Gracz__: `{$sender->getName()}` \n » __Zgłoszenie__: {$w}**");
	        $emb->setFooter("LightPE | $data | {$czas}:{$czasd}:{$czass}");
	        $msg->addEmbed($emb);
	        $test->send($msg);
		
		foreach(Server::getInstance()->getOnlinePlayers() as $player) {
			if($player->hasPermission("LightPE.helpop.command"))
			$player->sendMessage("§8* (§bHelpOP§8) §7{$sender->getName()}§8: §b{$w} §8*");
		}
		
		$sender->sendMessage(Main::formatL(["Zgloszenie zostalo wyslane"]));
        
		} else {
		    if(time() < $this->cooldownList[$sender->getName()]){
		        $usze = $this->cooldownList[$sender->getName()] - time();
		        
		        $sender->sendMessage(Main::format("Nastepne zgloszenie mozesz wyslac za: §2$usze sekund"));
		    } else {
		        unset($this->cooldownList[$sender->getName()]);
		    }
		}
	}
}