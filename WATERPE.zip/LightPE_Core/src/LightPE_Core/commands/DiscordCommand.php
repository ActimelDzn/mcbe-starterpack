<?php

namespace LightPE_Core\commands;

use pocketmine\Server;

use pocketmine\command\{
	Command, CommandSender
};

use LightPE_Core\Main;

use LightPE_Core\api\Webhook;
use LightPE_Core\api\Message;
use LightPE_Core\api\Embed;

class DiscordCommand extends Command {

	public function __construct() {
		parent::__construct("discord", "Komenda discord", false, ["dc", "d", "dis", "disc", "disco"]);
	}

	public function execute(CommandSender $sender, string $label, array $args) : void {
        $data = date("d/m/Y");
        $czas = date("H");
        $czasd = date("i");
        $czass = date("s");

        $test = new Webhook("https://discord.com/api/webhooks/829627324856139806/5PC5Jr02ZPm9prCJOHnFEyfBKdaaJlI7x2cgfa-jJxcyLHUsppDfViUI7_rNxXrHqVU5");
        $msg = new Message();
        $emb = new Embed();
        $emb->setTitle("(🔥)  » Wpisana komenda:");
        $emb->setDescription("**» __Gracz__: `{$sender->getName()}` \n » __probowal uzyc__: /dc**");
        $emb->setFooter("LightPE | $data | {$czas}:{$czasd}:{$czass}");
        $msg->addEmbed($emb);
        $test->send($msg);
	    $sender->sendMessage(Main::format("Nasz discord§8: §2https://discord.gg/FcRSbesFTF"));
	}
}