<?php

namespace LightPE_Core;

use pocketmine\plugin\PluginBase;

use pocketmine\entity\Creature;

use LightPE_Core\entity\EntityManager;

use pocketmine\utils\Config;

use pocketmine\{
	Server, Player
};

use pocketmine\utils\TextFormat;

use LightPE_Core\commands\{
    HelpopCommand
    };
    
use pocketmine\inventory\{
	ShapedRecipe, ShapelessRecipe
};

use pocketmine\item\Item;

use pocketmine\item\enchantment\Enchantment;

use pocketmine\item\enchantment\EnchantmentInstance;

use pocketmine\block\BlockFactory;

use pocketmine\math\Vector3;

use pocketmine\level\Level;

use LightPE_Core\tile\Tile;
use LightPE_Core\item\ItemManager;

class Main extends PluginBase 
{
	
	public function onEnable() : void {
		
		date_default_timezone_set('Europe/Warsaw');
		
		self::$instance = $this;

       $this->getServer()->getPluginManager()->registerEvents(new EventListener, $this);
		$cmds = [
		new PomocCommand(),
        new AlertCommand(),
        new HelpopCommand(),
        new EfektyCommand(),
        new PktCommand(),
        new DajCommand(),
        new HomeCommand(),
        new SethomeCommand(),
        new FeedCommand(),
        new MonetyCommand(),
        new SklepCommand(),
        new ClearlagCommand(),
        new CobblexCommand(),
        new DelhomeCommand(),
       new ClearCommand(),
      new FlyCommand(),
      new KordyCommand(),
      new ListCommand(),
      new MsgCommand(),
      new PallCommand(),
      new PcaseCommand(),
      new GodCommand(),
      new RCommand(),
      new CcCommand(),
      new ChatCommand(),
      new GraczCommand(),
      new VipCommand(),
      new RepairCommand(),
      new GamemodeCommand(),
      new DajmonetyCommand(),
      new TpaCommand(),
      new TpacceptCommand(),
      new TpdenyCommand(),
      new VanishCommand(),
            new DiscordCommand(),
            new SchowekCommand(),
            new AEventCommand(),
            new TntCommand()

	];
	
	
	$this->getServer()->getCommandMap()->registerAll("core", $cmds);
	
	    $i = 0;
        $this->getServer()->getCommandMap()->register("drop", new DropCommand($this, "drop"));
        $i++;
        $this->getServer()->getCommandMap()->register("incognito", new IncognitoCommand($this, "incognito"));
        $i++;
        $this->getServer()->getCommandMap()->register("top", new TopCommand($this, "top"));
        $i++;
        $this->getServer()->getCommandMap()->register("invsee", new InvseeCommand($this, "invsee"));
        $i++;
        $this->getLogger()->info(TextFormat::DARK_GREEN . "Zaladowano (" . $i . ") komend pomyslnie.");
	}

    public function openChestInventory(Player $player, int $x, int $y, int $z)
    {
        $tile = $player->getLevel()->getTile(new Vector3($x, $y, $z));
        if ($tile instanceof Chest) {
            if ($tile->isPaired()) {
                $items = $tile->getInventory()->getContents(true);
                $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
                $menu->getInventory()->setContents($items);
                $menu->readonly();
                $menu->send($player);
            } else {
                $items = $tile->getInventory()->getContents(true);
                $menu = InvMenu::create(InvMenu::TYPE_CHEST);
                $menu->getInventory()->setContents($items);
                $menu->readonly();
                $menu->send($player);
            }
        }
    }

    public function openPlayerInventory(Player $player, Player $target)
    {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $items = $target->getInventory()->getContents(true);
        $menu->getInventory()->setContents($items);
        $armor = $target->getArmorInventory();
        $helmet = $armor->getHelmet();
        $chestplate = $armor->getChestplate();
        $leggings = $armor->getLeggings();
        $boots = $armor->getBoots();
        $menu->getInventory()->setItem(53, $helmet->setLore(["§8[§2AKTUALNIE UBRANE§8]"]));
        $menu->getInventory()->setItem(52, $chestplate->setLore(["§8[§2AKTUALNIE UBRANE§8]"]));
        $menu->getInventory()->setItem(51, $leggings->setLore(["§8[§2AKTUALNIE UBRANE§8]"]));
        $menu->getInventory()->setItem(50, $boots->setLore(["§8[§2AKTUALNIE UBRANE§8]"]));
        $menu->setName("§l§8» §2Ekwipunek: " . $target->getName());
        $menu->readonly();
        $menu->send($player);
    }
	
	private function registerRecipes() : void {
        $kox_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(41), "J" => Item::get(260)], [Item::get(466)]);

        $boyfarmer_item = Item::get(49);
        $boyfarmer_item->setCustomName("§r§l§2BoyFarmer");
        $boyfarmer_item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(17), 10));
        $boyfarmer_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(49), "J" => Item::get(264)], [$boyfarmer_item]);

        $sandfarmer_item = Item::get(12);
        $sandfarmer_item->setCustomName("§r§l§2SandFarmer");
        $sandfarmer_item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(17), 10));
        $sandfarmer_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(12), "J" => Item::get(264)], [$sandfarmer_item]);

        $kopaczfosy_item = Item::get(1);
        $kopaczfosy_item->setCustomName("§r§l§2Kopacz Fosy");
        $kopaczfosy_item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(17), 10));
        $kopaczfosy_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(1), "J" => Item::get(278)], [$kopaczfosy_item]);

        $enderchest_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(49), "J" => Item::get(368)], [Item::get(130)]);

        $rzucak_item = Item::get(46);
        $rzucak_item->setCustomName("§r§l§cRzucane TNT");
        $rzucak_item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(17), 10));
        $rzucak_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(46), "J" => Item::get(138)], [$rzucak_item]);

        $stoniarka05 = Item::get(1);
        $stoniarka05->setCustomName("§r§7Generator Kamienia§2 0.5s");
        $stoniarka05->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(17), 10));
        $stoniarka05_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(1), "J" => Item::get(Item::EMERALD)], [$stoniarka05]);

        $stoniarka15 = Item::get(1);
        $stoniarka15->setCustomName("§r§7Generator Kamienia§2 1.5s");
        $stoniarka15->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(17), 10));
        $stoniarka15_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(1), "J" => Item::get(Item::DIAMOND)], [$stoniarka15]);

        $stoniarka3 = Item::get(1);
        $stoniarka3->setCustomName("§r§7Generator Kamienia§2 3s");
        $stoniarka3->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(17), 10));
        $stoniarka3_recipe = new ShapedRecipe(["GGG", "GJG", "GGG"], ["G" => Item::get(1), "J" => Item::get(Item::IRON_INGOT)], [$stoniarka3]);


        $this->getServer()->getCraftingManager()->registerRecipe($stoniarka3_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($stoniarka05_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($stoniarka15_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($kox_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($boyfarmer_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($sandfarmer_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($kopaczfosy_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($enderchest_recipe);
        $this->getServer()->getCraftingManager()->registerRecipe($rzucak_recipe);
    }
    public static function format(string $w){
    	return "§8[§3WaterPE§8]§7 $w §8*";
    }
    public static function formatL(array $w) : string {
    	return "\n§8             §8[§3WaterPE§8]§7\n\n§8»  §r§7".implode("\n§8»  §7", $w)."\n§7";
    }
    
    public static function getInstance() : Main {
		return self::$instance;
	}
	
	public function getDb() : \SQLite3 {
		return $this->db;
	}
    
    public function getDropAPI() : DropAPI {
		return $this->dropAPI;
	}

      public function getMonetyAPI() : MonetyAPI {
         return $this->monetyAPI;
       }
       public function getKitsAPI() : KitsAPI {
         return $this->kitsAPI;
       }
	  public function getPointsAPI() : PointsAPI {
	  	return $this->pointsAPI;
	  }

    public function getSchowekAPI() : SchowekAPI {
        return $this->schowekAPI;
    }

    public function getStatsAPI() : StatsAPI {
    return $this->statsAPI;
  }

     public function clearLag() : void {
		$count = 0;

		foreach($this->getServer()->getLevels() as $level) {
			foreach($level->getEntities() as $entity) {
				if(!$entity instanceof Creature) {
					$entity->close();

					$count++;
				}
			}
		}
		
		foreach($this->getServer()->getDefaultLevel()->getPlayers() as $p)
		 $p->sendMessage(self::format("Pomyslnie usunieto §2$count §7itemow ze swiata!"));
	}
	
	public function getBookshelfsCount(Vector3 $pos, Level $level) : int {
		
		$count = 0;
		
        if($level->getBlock($pos->add(2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(2, 0, 1))->getId() == 47) $count++;		
		if($level->getBlock($pos->add(2, 0, -1))->getId() == 47) $count++;
		
		if($level->getBlock($pos->add(-2, 0))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-2, 0, -1))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-2, 0, 1))->getId() == 47) $count++;
		
		if($level->getBlock($pos->add(0, 0, 2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(1, 0, 2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-1, 0, 2))->getId() == 47) $count++;
		
		if($level->getBlock($pos->add(0, 0, -2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-1, 0, -2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(1, 0, -2))->getId() == 47) $count++;



		if($level->getBlock($pos->add(2, 1))->getId() == 47) $count++;		
		if($level->getBlock($pos->add(2, 1, 1))->getId() == 47) $count++;		
		if($level->getBlock($pos->add(2, 1, -1))->getId() == 47) $count++;
		
		if($level->getBlock($pos->add(-2, 1))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-2, 1, -1))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-2, 1, 1))->getId() == 47) $count++;
		
		if($level->getBlock($pos->add(0, 1, 2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(1, 1, 2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-1, 1, 2))->getId() == 47) $count++;
		
		if($level->getBlock($pos->add(0, 1, -2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(-1, 1, -2))->getId() == 47) $count++;
		if($level->getBlock($pos->add(1, 1, -2))->getId() == 47) $count++;
		
		return (int) $count;
	}
	
    public function getPoints(string $nick)
  {
    $result = $this->db->query("SELECT * FROM points WHERE nick = '$nick'");
    $array = $result->fetchArray(SQLITE3_ASSOC);

    return $array["punkty"];
  }
  
  public function getTopka(string $nick)
  {
    $result = $this->db->query("SELECT * FROM points ORDER BY punkty DESC LIMIT 10");
    $array = $result->fetchArray(SQLITE3_ASSOC);

    return $array["punkty"];
  }
	}