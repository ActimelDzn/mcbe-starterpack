<?php

declare(strict_types=1);

namespace Gildie\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use LightPE_Core\Main;

abstract class GuildCommand extends Command {

    private $seePermission;
    private $usePermission = null;

    public function __construct(string $name, string $description, bool $usePerm = false, array $aliases= []) {
        $this->seePermission = $seePerm = "LightPE.command.see";
        $this->setPermission($seePerm);

        if($usePerm)
            $this->usePermission = "LightPE.command.".$name;

        parent::__construct($name, $description, null, $aliases);
    }

    public function getSeePermission() : string {
        return $this->seePermission;
    }

    public function getUsePermission() : ?string {
        return $this->usePermission;
    }

    public function canUse(CommandSender $sender) : bool {
        if($this->usePermission == null)
            return true;
        else {
            if(!$sender->hasPermission($this->usePermission)) {
                $sender->sendMessage(Main::formatLines(["Nie posiadasz §2permisji§7, aby uzyc tej komendy!", "Wpisz §2/pomoc §7aby zobaczyc dostepne dla Ciebie komendy!"]));
                return false;
            }
            return true;
        }
    }
}