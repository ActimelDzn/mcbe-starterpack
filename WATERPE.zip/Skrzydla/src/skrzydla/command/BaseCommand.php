<?php

declare(strict_types=1);

namespace skrzydla\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use skrzydla\util\MessageUtil;

abstract class BaseCommand extends Command {

    private $playerCommand;

    public function __construct(string $name, string $description, array $aliases = [], bool $playerCommand = false, bool $permission = false) {
        parent::__construct($name, $description, null, $aliases);

        $this->playerCommand = $playerCommand;

        if($permission)
            $this->setPermission("skrzydla." . $name . ".command");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		if(!$this->testPermission($sender))
			return;
			
        if($this->playerCommand && !$sender instanceof Player) {
            $sender->sendMessage(MessageUtil::format("Blad! Tej komendy możesz użyć tylko w grze!", false));
            return;
        }

        $this->onCommand($sender, $args);
    }

    abstract public function onCommand(CommandSender $sender, array $args) : void;
}