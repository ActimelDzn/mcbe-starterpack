<?php

declare(strict_types=1);

namespace skrzydla\command;

use skrzydla\command\commands\SkrzydlaCommand;
use pocketmine\Server;

class CommandManager {

    public static function init() : void {
        $commands = [
            new SkrzydlaCommand()
        ];

        Server::getInstance()->getCommandMap()->registerAll("template", $commands);
    }
}