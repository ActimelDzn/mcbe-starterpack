<?php

declare(strict_types=1);

namespace skrzydla;

use pocketmine\plugin\PluginBase;
use skrzydla\command\CommandManager;
use skrzydla\listener\ListenerManager;
use skrzydla\manager\SkinManager;
use skrzydla\wings\WingsManager;

class Main extends PluginBase {

    private static $instance;

    public static function getInstance() : Main {
        return self::$instance;
    }

    public function onEnable() : void {
        self::$instance = $this;

        @mkdir($this->getDataFolder() . "wings");
        @mkdir($this->getDataFolder() . "playersSkins");

        CommandManager::init();
        ListenerManager::init($this);
        SkinManager::init($this);
        WingsManager::init($this);

        $this->getLogger()->info("Włączono!");
    }

    public function onDisable() : void {
        $this->getLogger()->info("Wyłączono!");
    }
}