<?php

declare(strict_types=1);

namespace skrzydla\listener;

use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\LoginPacket;
use skrzydla\manager\SkinManager;
use skrzydla\util\SkinUtil;

class DataPacketReceiveListener implements Listener {

    public function onLogin(DataPacketReceiveEvent $event) : void {
        $packet = $event->getPacket();

        if($packet instanceof LoginPacket) {
            $data = $packet->clientData;
            $name = $data["ThirdPartyName"];

            if($data["PersonaSkin"]) {
                SkinManager::setPlayerDefaultSkin($name);
                return;
            }

            $image = SkinUtil::skinDataToImage(base64_decode($data["SkinData"], true));

            // DOPUSZCZALNE SĄ TYLKO SKINY 64x64
            if($image === null || imagesx($image) * imagesy($image) * 4 !== 16384) {
                SkinManager::setPlayerDefaultSkin($name);
                return;
            }

            SkinManager::setPlayerSkinImage($name, $image);
        }
    }
}