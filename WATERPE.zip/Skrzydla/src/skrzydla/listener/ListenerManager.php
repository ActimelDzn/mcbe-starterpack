<?php

declare(strict_types=1);

namespace skrzydla\listener;

use skrzydla\Main;

class ListenerManager {

    public static function init(Main $main) : void {
        $listeners = [
            new PlayerJoinListener(),
            new DataPacketReceiveListener(),
            new PlayerQuitListener()
        ];

        foreach($listeners as $listener)
            $main->getServer()->getPluginManager()->registerEvents($listener, $main);
    }
}