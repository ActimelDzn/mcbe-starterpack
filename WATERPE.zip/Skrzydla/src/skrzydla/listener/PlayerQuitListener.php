<?php

declare(strict_types=1);

namespace skrzydla\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use skrzydla\manager\SkinManager;

class PlayerQuitListener implements Listener {

    public function onQuit(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
        SkinManager::removePlayerSkin($player);
    }
}