<?php

declare(strict_types=1);

namespace skrzydla\listener;

use pocketmine\entity\Skin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use skrzydla\manager\SkinManager;
use skrzydla\util\SkinUtil;
use skrzydla\wings\WingsManager;

class PlayerJoinListener implements Listener {

    public function onJoin(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $skin = $player->getSkin();

        $newSkin = new Skin($skin->getSkinId(), SkinUtil::skinImageToBytes(SkinManager::getPlayerSkinImage($player->getName())), "", SkinManager::getDefaultGeometryName(), SkinManager::getDefaultGeometryData());

        $wings = WingsManager::getPlayerWings($player->getName());

        if($wings !== null)
            WingsManager::setWings($player, $wings);
         else {
            $player->setSkin($newSkin);
            $player->sendSkin();
        }

        SkinManager::setPlayerSkin($player, $newSkin);
    }
}