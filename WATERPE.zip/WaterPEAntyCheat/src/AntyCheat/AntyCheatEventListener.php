<?php

namespace AntyCheat;

use AntyCheat\Tasks\AntyCheatClicksTask;
use pocketmine\entity\Effect;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerMoveEvent;

class AntyCheatEventListener implements Listener
{

    public $plugin;

    public function __construct(AntyCheat $pg)
    {
        $this->plugin = $pg;
    }

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        $this->plugin->clicks[$player->getName()] = 0;
        $this->plugin->cooldown[$player->getName()] = 0;
        $task = new AntyCheatClicksTask($this->plugin, $player);
        $this->plugin->getScheduler()->scheduleDelayedRepeatingTask($task, 20, 20);
    }

    public function onQuit(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer();
        unset($this->plugin->breakTimes[$player->getRawUniqueId()]);
    }

    /**
     * @priority MONITOR
     * @param EntityDamageEvent $event
     */

    public function onEntityDamage(EntityDamageEvent $event)
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $player = $event->getDamager();
            if ($player instanceof Player) {
                $this->plugin->clicks[$player->getName()]++;
                if (!isset($this->plugin->cooldown[$player->getName()])) {
                    $this->plugin->cooldown[$player->getName()] = time();
                    $event->setCancelled();
                } else {
                    if (!$event->isCancelled()) {
                        if (time() - $this->plugin->cooldown[$player->getName()] <= 1) {
                            if ($this->plugin->clicks[$player->getName()] > $this->plugin->getConfig()->get("AntiAutoClickerMaxCps")) {
                                if (!isset($this->plugin->cpscooldown[$player->getName()])) {
                                    $player->sendMessage($this->plugin->formatMessage("Przekroczyles limit CPS (" . $this->plugin->getConfig()->get("AntiAutoClickerMaxCps") . "). Przez nastepne " . $this->plugin->getConfig()->get("AntiAutoClickerMaxCpsCooldown") . " sekund nie mozesz nikogo atakowac!", true));
                                    $this->plugin->cpscooldown[$player->getName()] = time();
                                    $event->setCancelled();
                                }
                            }
                        } else {
                            $this->plugin->cooldown[$player->getName()] = time();
                        }
                    }
                    if ($this->plugin->clicks[$player->getName()] > 40) {
                        $player->kick("Zmniejsz CPSY!");
                    }
                    if (isset($this->plugin->cpscooldown[$player->getName()])) {
                        if (time() - $this->plugin->cpscooldown[$player->getName()] <= $this->plugin->getConfig()->get("AntiAutoClickerMaxCpsCooldown")) {
                            $event->setCancelled();
                        } else {
                            unset($this->plugin->cpscooldown[$player->getName()]);
                        }
                    }
                }
            }
        }
    }

    public
    function onTouch(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        if ($event->getAction() == PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            if ($block->getId() == Item::LEVER or $block->getId() == Item::STONE_BUTTON or $block->getId() == Item::WOODEN_BUTTON) {
                if (!isset($this->plugin->spamItem[$player->getName()])) {
                    $this->plugin->spamItem[$player->getName()] = time();
                } else {
                    if (time() - $this->plugin->spamItem[$player->getName()] <= 5) {
                        $event->setCancelled();
                    } else {
                        $this->plugin->spamItem[$player->getName()] = time();
                    }
                }
            }
        }
    }

    public function onMove(PlayerMoveEvent $event)
    {
        $player = $event->getPlayer();
        if (!$player->hasPermission("antycheat.notify")) {
            if (floor($event->getTo()->getX()) != floor($event->getFrom()->getX()) || floor($event->getTo()->getZ()) != floor($event->getFrom()->getZ()) || floor($event->getTo()->getY()) != floor($event->getFrom()->getY())) {
                $level = $player->getLevel();
                $pos = new Vector3($event->getTo()->getX(), $event->getTo()->getY(), $event->getTo()->getZ());
                $BlockID = $level->getBlock($pos)->getId();
                $pos2 = new Vector3($event->getTo()->getX(), $event->getTo()->getY() + 1, $event->getTo()->getZ());
                $BlockID2 = $level->getBlock($pos2)->getId();
                if (($BlockID == 1
                        or $BlockID == 2
                        or $BlockID == 3
                        or $BlockID == 4
                        or $BlockID == 5
                        or $BlockID == 7
                        or $BlockID == 12
                        or $BlockID == 17
                        or $BlockID == 18
                        or $BlockID == 20
                        or $BlockID == 24
                        or $BlockID == 43
                        or $BlockID == 45
                        or $BlockID == 47
                        or $BlockID == 48
                        or $BlockID == 49
                        or $BlockID == 79
                        or $BlockID == 80
                        or $BlockID == 87
                        or $BlockID == 89
                        or $BlockID == 97
                        or $BlockID == 98
                        or $BlockID == 110
                        or $BlockID == 112
                        or $BlockID == 121
                        or $BlockID == 155
                        or $BlockID == 157
                        or $BlockID == 159
                        or $BlockID == 161
                        or $BlockID == 162
                        or $BlockID == 170
                        or $BlockID == 172
                        or $BlockID == 174
                        or $BlockID == 243
                        or $BlockID == 14
                        or $BlockID == 15
                        or $BlockID == 16
                        or $BlockID == 21
                        or $BlockID == 56
                        or $BlockID == 73
                        or $BlockID == 73
                        or $BlockID == 129) && ($BlockID2 == 1
                        or $BlockID2 == 2
                        or $BlockID2 == 3
                        or $BlockID2 == 4
                        or $BlockID2 == 5
                        or $BlockID2 == 7
                        or $BlockID2 == 12
                        or $BlockID2 == 17
                        or $BlockID2 == 18
                        or $BlockID2 == 20
                        or $BlockID2 == 24
                        or $BlockID2 == 43
                        or $BlockID2 == 45
                        or $BlockID2 == 47
                        or $BlockID2 == 48
                        or $BlockID2 == 49
                        or $BlockID2 == 79
                        or $BlockID2 == 80
                        or $BlockID2 == 87
                        or $BlockID2 == 89
                        or $BlockID2 == 97
                        or $BlockID2 == 98
                        or $BlockID2 == 110
                        or $BlockID2 == 112
                        or $BlockID2 == 121
                        or $BlockID2 == 155
                        or $BlockID2 == 157
                        or $BlockID2 == 159
                        or $BlockID2 == 161
                        or $BlockID2 == 162
                        or $BlockID2 == 170
                        or $BlockID2 == 172
                        or $BlockID2 == 174
                        or $BlockID2 == 243
                        or $BlockID2 == 14
                        or $BlockID2 == 15
                        or $BlockID2 == 16
                        or $BlockID2 == 21
                        or $BlockID2 == 56
                        or $BlockID2 == 73
                        or $BlockID2 == 73
                        or $BlockID2 == 129)) {
                    $event->setCancelled();
                }
            }
        }
    }
}