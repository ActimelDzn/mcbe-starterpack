<?php

namespace AntyCheat;

use pocketmine\event\Listener;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class AntyCheat extends PluginBase implements Listener
{

    public $clicks, $cooldown, $cpscooldown, $cps, $spamItem, $breakTimes = [];

    public function onEnable()
    {
        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents(new AntyCheatEventListener($this), $this);
    }

    public function api($plugin)
    {
        return $this->getServer()->getPluginManager()->getPlugin($plugin);
    }

    public function formatMessage($string, $confirm = false)
    {
        $success = $this->getConfig()->get("PrefixSuccess");
        $failure = $this->getConfig()->get("PrefixFailure");
        if ($confirm) {
            return str_replace('{STRING}', $string, $success);
        } else {
            return str_replace('{STRING}', $string, $failure);
        }
    }
}