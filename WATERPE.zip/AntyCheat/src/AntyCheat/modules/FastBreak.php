<?php
namespace AntyCheat\modules;

use pocketmine\entity\Effect;
use pocketmine\Server;
use AntyCheat\Main;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;

class FastBreak implements Listener{
    
    private $breakTimes = [];
    private $notify;
    private $plugin;
    private $counter;

    public function __construct(Main $plugin){
        $this->plugin = $plugin;
        $this->notify = [];
    }
    
    public function onPlayerInteract(PlayerInteractEvent $event){

        $player = $event->getPlayer();

        if($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK){
            $this->breakTimes[$player->getName()] = floor(microtime(true) * 20);
        }
    }

    /**
     * @param BlockBreakEvent $e
     * @priority HIGHEST
     * @ignoreCancelled true
     */

    public function AntiSpeedMineBlockBreak(BlockBreakEvent $e) : void{

        if($e->isCancelled())
            return;

        if($e->getInstaBreak())
            return;

        $player = $e->getPlayer();

        
        $name = $player->getName();

        if(!isset($this->counter[$name])) {
            $this->counter[$name] = 1;
            return;
        }

        if(!isset($this->breakTimes[$name])){

            $e->setCancelled(true);

            if($this->counter[$name] >= 6) {
                foreach($this->plugin->getServer()->getOnlinePlayers() as $ops){
                    if($ops->getPlayer()->isOp()){
                        $ops->getPlayer()->sendMessage($this->plugin->format("&cGracz &4{$player->getName()} &cmoze uzywac &4FASTBREAK"));
                    }
                }
                Server::getInstance()->getLogger()->error("[ANTYCHEAT] §r§8(§7".$player->getName()."§8) §7 Prawdopodobnie korzysta z fastbreaka!");
                $this->counter[$name] = 0;
                return;
            }else
                $this->counter[$name]++;

            return;
        }

        $target = $e->getBlock();
        $item = $e->getItem();

        $expectedTime = ceil($target->getBreakTime($item) * 20);

        if($player->hasEffect(Effect::HASTE)){
            $expectedTime *= 1 - (0.2 * $player->getEffect(Effect::HASTE)->getEffectLevel());
        }

        if($player->hasEffect(Effect::MINING_FATIGUE)){
            $expectedTime *= 1 + (0.3 * $player->getEffect(Effect::MINING_FATIGUE)->getEffectLevel());
        }

        $expectedTime -= 1;

        $actualTime = ceil(microtime(true) * 20) - $this->breakTimes[$name];

        if($actualTime < $expectedTime){

            $e->setCancelled(true);

            if($this->counter[$name] >= 5) {
                foreach($this->plugin->getServer()->getOnlinePlayers() as $ops){
                    if($ops->getPlayer()->isOp()){
                        $ops->getPlayer()->sendMessage($this->plugin->format("&cGracz &4{$player->getName()} &cmoze uzywac &4FASTBREAK"));
                    }
                }
                Server::getInstance()->getLogger()->error("[ANTYCHEAT] §r§8(§7".$player->getName()."§8) §7 Prawdopodobnie korzysta z fastbreaka! §8(§4".$actualTime."§7/§4".$expectedTime."§8)");
                $this->counter[$name] = 0;
                return;
            }else
                $this->counter[$name]++;

            return;
        }

        $this->counter[$name]--;
        unset($this->breakTimes[$name]);
    }
    
    public function onPlayerQuit(PlayerQuitEvent $event){
        unset($this->breakTimes[$event->getPlayer()->getName()]);
        unset($this->counter[$event->getPlayer()->getName()]);
    }
}

