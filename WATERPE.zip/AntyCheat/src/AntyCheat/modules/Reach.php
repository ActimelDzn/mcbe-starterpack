<?php
namespace AntyCheat\modules;

use AntyCheat\Main;
use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\Item;

class Reach implements Listener{
    
    private $plugin;
    private $notify;
    private $distance;
    
    public function __construct(Main $plugin){
        $this->plugin = $plugin;
        $this->notify = [];
        $this->distance = [];
    }
    
    public function onEntityDamageEvent(EntityDamageEvent $e){
        if($e instanceof EntityDamageByEntityEvent){
            $attacker = $e->getDamager();

            if(!($attacker instanceof Player)) return;

            

            if($attacker->isOp() || $attacker->hasPermission("antycheat.bypass")) return;
            if($attacker->isCreative(true)) return;
            if($attacker->getInventory()->getItemInHand()->getId() == Item::BOW ||
                $attacker->getInventory()->getItemInHand()->getId() == Item::ENDER_PEARL ||
                $attacker->getInventory()->getItemInHand()->getId() == Item::EGG ||
                $attacker->getInventory()->getItemInHand()->getId() == Item::SNOWBALL) {
                return;
            }
            $victim = $e->getEntity();
            $player = $e->getEntity();
            $distance = $attacker->distance($victim->getPosition());
            if($distance > 5){
                if(!isset($this->notify[$attacker->getName()])){
                    $this->notify[$attacker->getName()] = 0;
                }
                $this->notify[$attacker->getName()]++;
                $this->distance[$attacker->getName()][] = $distance;
                if($this->notify[$attacker->getName()] >= 5){
                    foreach($this->plugin->getServer()->getOnlinePlayers() as $ops){
                        if($ops->getPlayer()->isOp()){
                            $dist = array_sum($this->distance[$attacker->getName()]) / count($this->distance[$attacker->getName()]);
                             $ops->getPlayer()->sendMessage($this->plugin->format("&cGracz &4{$player->getName()} &cmoze uzywac &4REACH"));
                            $this->plugin->getServer()->getLogger()->warning($attacker->getName(). " -> Reach( ".$dist." )");
                        }
                    }
                    $this->distance[$attacker->getName()] = null;
                    $this->notify[$attacker->getName()] = 0;
                }
            }
        }
    }
}

