<?php
namespace AntyCheat\modules;

use pocketmine\event\block\BlockPlaceEvent;
use AntyCheat\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

class FlyHack implements Listener{
    
    private $plugin;
    private $player;
    private $notify;
    private $bugowanie;

    public function __construct(Main $plugin){
        $this->plugin = $plugin;
        $this->player = [];
        $this->notify = [];
        $this->bugowanie = [];
    }

    public function blockPlace(BlockPlaceEvent $e) : void{
        $this->bugowanie[$e->getPlayer()->getName()] = time() + 5;
    }

    public function on(PlayerJoinEvent $e){
        $this->notify[$e->getPlayer()->getName()] = 0;
        $this->bugowanie[$e->getPlayer()->getName()] = 0;
    }
    
    public function onPlayerMoveEvent(PlayerMoveEvent $e){

        if($e->getFrom()->floor()->equals($e->getTo()->floor()))
            return;

        $player = $e->getPlayer();

        if(isset($this->bugowanie[$e->getPlayer()->getName()])) {
            if(time() < $this->bugowanie[$e->getPlayer()->getName()])
                return;
        }


        if($player->isOp() || $player->hasPermission("antycheat.bypass")) return;
        if($player->isCreative(true) || $player->isSpectator()) return;
       // if($player->canFly()) return;
        if($player->getInAirTicks() > 15){
            $this->player[$e->getPlayer()->getName()][time()]["y"] = $player->getY();
            if(!isset($this->player[$e->getPlayer()->getName()][time()-1]["y"])) return;
            if($player->getY() > $this->player[$e->getPlayer()->getName()][time()-1]["y"]){
                $this->notify[$player->getName()]++;
                if($this->notify[$player->getName()] >= 5){
                    foreach($this->plugin->getServer()->getOnlinePlayers() as $ops){
                        if($ops->getPlayer()->isOp()){
                             $ops->getPlayer()->sendMessage($this->plugin->format("&cGracz &4{$player->getName()} &cmoze uzywac &4FLY"));
                        }
                    }
                    $this->plugin->getServer()->getLogger()->warning($player->getName(). " -> FLY");
                    $this->notify[$player->getName()] = 0;
                }
            }
        }
    }
    
    public function onPlayerQuitEvent(PlayerQuitEvent $e){
        $this->notify[$e->getPlayer()->getName()] = null;
        $this->player[$e->getPlayer()->getName()] = null;
    }
    
}

