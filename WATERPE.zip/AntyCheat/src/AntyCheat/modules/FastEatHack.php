<?php


namespace AntyCheat\modules;


use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerQuitEvent;
use AntyCheat\Main;

class FastEatHack implements Listener
{

    private $eatTimes = [];
    private $notify;
    private $plugin;

    public function __construct(Main $plugin){
        $this->plugin = $plugin;
        $this->notify = [];
    }

    public function onPlayerInteract(PlayerInteractEvent $event){

        $player = $event->getPlayer();
        

        if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR || $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
            $this->eatTimes[$player->getRawUniqueId()] = floor(microtime(true) * 20);
        }
    }

    public function onPlayerItemConsumeEvent(PlayerItemConsumeEvent $event){
        $player = $event->getPlayer();

 

        if(isset($this->eatTimes[$uuid = $player->getRawUniqueId()])){
            $time = floor(microtime(true) * 20);
            $diff = $time - $this->eatTimes[$player->getRawUniqueId()];
            if($diff < 30){
                $event->setCancelled();

                if(!isset($this->notify[$player->getRawUniqueId()])){
                    $this->notify[$player->getRawUniqueId()] = 0;
                }

                $this->notify[$player->getRawUniqueId()]++;
                if($this->notify[$player->getRawUniqueId()] >= 3){
                    $this->plugin->getServer()->getLogger()->warning($player->getName() . " -> FastEat");
                    foreach($this->plugin->getServer()->getOnlinePlayers() as $ops){
                        if($ops->getPlayer()->hasPermission("ac.notify")){
                             $ops->getPlayer()->sendMessage($this->plugin->format("&cGracz &4{$player->getName()} &cmoze uzywac &4FASTEAT"));
                        }
                    }
                }

                if($this->notify[$player->getRawUniqueId()] >= 3){
                    $this->notify[$player->getRawUniqueId()] = 0;
                }
            }
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event){
        unset($this->eatTimes[$event->getPlayer()->getRawUniqueId()]);
    }
}