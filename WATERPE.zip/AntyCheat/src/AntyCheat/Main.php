<?php
namespace AntyCheat;

use AntyCheat\modules\FastBreak;
use AntyCheat\modules\FastEatHack;
use AntyCheat\modules\FlyHack;
use AntyCheat\modules\Noclip;
use AntyCheat\modules\Reach;
use AntyCheat\modules\SpeedHack;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{

    private static $instance;
    public static $noclipWhitelist = [];

    public function onEnable(){
        self::$instance = $this;
        $this->getLogger()->info($this->format("&aAntyCheat Zostal Wlaczony"));
        $this->loadModules();
    }
    
    public function loadModules(){
        $this->getServer()->getPluginManager()->registerEvents(new FastBreak($this), $this);
        $this->getServer()->getPluginManager()->registerEvents(new SpeedHack($this), $this);
        $this->getServer()->getPluginManager()->registerEvents(new Reach($this), $this);
        $this->getServer()->getPluginManager()->registerEvents(new Noclip($this), $this);
        $this->getServer()->getPluginManager()->registerEvents(new FlyHack($this), $this);
        $this->getServer()->getPluginManager()->registerEvents(new FastEatHack($this), $this);
    }

    public static function getInstance() : self{
        return self::$instance;
    }
    
    public function format($string){
        return str_replace("&", "§", $string);
    }
}



